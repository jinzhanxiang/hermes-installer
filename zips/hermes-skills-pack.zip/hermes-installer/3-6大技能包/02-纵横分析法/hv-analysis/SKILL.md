---
name: hv-analysis
description: |
  横纵分析法（Horizontal-Vertical Analysis）深度研究Skill。由数字生命卡兹克提出，融合历时-共时分析、纵向-横截面研究设计、案例研究法与竞争战略分析。
  当用户想要系统性研究一个产品、公司、概念、技术或人物时使用。纵轴追踪完整生命历程，横轴与竞品系统性横向对比，交叉产出洞察。

  [V3.45.2 输出规范强化]
  - V3.45.0 架构重构基线
  - V3.45.1 新增 §1.4 决策轴（分析→决策桥接）+ Phase 4 决策支持（4章）
  - V3.45.2 Chapter 18 双口径强制联动 + Chapter 20 5模块内嵌规则强化 + Chapter 25 IRR分级输出模板
  - 新增 SOTP 分部估值 + 双口径估值（domains/financial-dd.md）
  - 新增「投资人沟通会纪要」信源类型（_shared/data-sources.md）
  - 新增 3 个决策偏差警醒信号（S5-S7）+ 第20章结构化输出模板
  - 新增 §五 决策模式路由 + Phase 4 执行流程
  - 核心原则：每一步增强不破坏 Agent 自适应闭环。数据源是 Agent 的工具，不是流水线的固定输入。

  最终输出：学术研究级研究报告（.md）+ 商务尽调级 HTML（含可执行交易建议）。
---

# 横纵分析法（HV Analysis）

> **方法论溯源（四源融合）**
>
> | # | 理论源 | 提出者 | 核心概念 | 在 hv-analysis 中的映射 |
> |---|--------|--------|----------|------------------------|
> | 1 | **历时语言学** | Saussure（1916）| Diachronic vs Synchronic | 纵向轴 = 沿时间轴还原对象演变；横向轴 = 当下时间切片的系统对比 |
> | 2 | **纵横向研究设计** | Cook & Campbell（1979）| Longitudinal vs Cross-sectional | 纵向 = 同一公司 N 年时间序列；横向 = 同业 N 家公司同一时点对比 |
> | 3 | **案例研究法** | Robert Yin（1984）| 单一案例深度 + 多案例对比 | 纵向 = 单一公司深度演变；横向 = 多公司多维度对比 |
> | 4 | **竞争战略五力** | Michael Porter（1979）| 供应商/买方/替代品/新进入者/现有竞争 | 横向对标必含五力维度延伸 |
>
> 横纵分析法首次将语言学+社会科学+商学+战略学的纵横向思想整合为可操作的报告框架。

---

## §一 核心定义

### 1.1 三个分析轴

```
纵向轴（Vertical）   = 沿时间轴还原研究对象完整生命历程
横向轴（Horizontal） = 同一时间切片下与竞品的系统性多维度对比
交叉轴（Cross）      = 纵横向数据交汇 → 矛盾检测 → 投资洞察
```

### 1.2 自适应闭环（不可破坏）

```
Agent 读本地文件 → 识别数据缺口 → 按需选择工具 → 读结果 → 补充搜索 → 循环
                                                       ↑__________________|
```

**核心原则**：数据源是 Agent 的工具，不是流水线的固定输入。Agent 在每个阶段自主判断：
- 需要什么数据
- 用哪个工具获取
- 结果是否填补了缺口
- 是否需要补充搜索

### 1.3 适用场景

| 任务类型 | 加载的领域增强 | 说明 |
|---------|-------------|------|
| 商业尽调 / 投资分析 | `domains/commercial-dd.md` | 全量加载 |
| 财务尽调 / 投资价值分析 | `domains/financial-dd.md` | 全量加载 |
| 法律尽调 / 并购尽调（法律部分）| `domains/legal-dd.md` | 全量加载 |
| 并购尽调（综合）| 三个领域文件全部加载 | 按 Phase 需要交叉引用 |
| 概念/技术/人物研究 | 无领域增强 | 仅核心框架 |

### 1.4 决策轴（分析→决策桥接）

> **设计目的**：横纵分析法的三层轴（纵向/横向/交叉）产出的是「对公司的理解」。但投资/并购场景需要「可执行的交易建议」。决策轴将分析结论转化为交易决策，是方法从「研究」升级为「决策支持」的关键桥接。

```
分析层的输出（Phase 1-3 产出）
        ↓
决策轴（Decision Axis）：   交易结构 ← 约束条件 ← 退出路径
                              ↓
决策层（Phase 4 产出）：     情景推演 → 行动建议
```

**四个决策维度**：

| # | 维度 | 核心问题 | 章 |
|:--:|------|---------|:--:|
| D1 | **交易结构设计** | 最优交易形式是什么？换股/现金/混合？ | 22 |
| D2 | **退出路径分析** | 有哪些退出通道？各自的可行性/时间窗口/回报？ | 23 |
| D3 | **约束条件建模** | 监管/法律/平台层面的约束如何影响可选方案？ | 24 |
| D4 | **情景推演** | 不同情景下的估值/回报/风险区间？ | 25 |

**决策轴 vs 分析轴的本质差异**：

| 维度 | 分析轴（Phase 1-3） | 决策轴（Phase 4） |
|------|-------------------|------------------|
| 目标 | 理解公司（what/why） | 建议行动（what to do） |
| 输出 | 数据/对比/矛盾 | 方案/可行性/建议 |
| 时间方向 | 历史→现状 | 现状→未来 |
| 不确定性处理 | 标注「待核实」 | 情景概率化 |
| 用户期望 | 全面客观 | 清晰可执行 |

**加载条件**：任务类型含「尽调/投资/并购/退出/交易」时，Phase 4 自动激活。

---

## §二 禁止事项

### 2.1 强制路由规则

> **黄金法则**：结构化数据（数字/表格/指标）→ iFind Finance / MX Data / Tushare / AKShare。文本内容（新闻/公告/研报）→ MX Search / iFind News / iFind Announcement。**绝不**用文本工具查结构化数据。

| 数据需求 | 必须使用 | 禁止使用 |
|---------|---------|---------|
| 上市公司财务数据 | iFind Finance 或 MX Data D1 | iFind News / SearXNG |
| 法律合规/处罚/诉讼 | iFind Announcement 或 MX Data D5 | iFind News / SearXNG |
| 公告/年报/季报原文 | iFind Announcement | MX Search / iFind News |
| 行业/政策/趋势（定性）| iFind News 或 MX Search | iFind Finance |
| 竞品财务对比 | iFind Finance + MX Data D7 | iFind News / SearXNG |
| 宏观数据（GDP/CPI/PMI）| AKShare 或 iFind Finance | MX Search / iFind News |
| 学术/技术论文 | arXiv API | SearXNG |

### 2.2 SearXNG 定位

**SearXNG 是最后选择**，仅当 MX Search、iFind Finance、iFind Announcement、iFind News 全部不可用时使用。正常流程不应出现。

降级链：`MX/iFind 全链路失败 → SearXNG → 百度 HTML → ddgs`

### 2.3 搜索纪律

1. **不重复调用**：同一个工具同一个查询，结果缓存 15 分钟
2. **先精后宽**：第一轮精确名，命中率低再放宽
3. **竞品名从本地文件提取**：不 hardcode
4. **arXiv 仅硬科技领域**：半导体/LED/新能源/医药/新材料，其他领域跳过
5. **异步工具优先提交**：session 开始就 submit（iFind Chain/Investment）

---

## §三 执行流程

### Phase 0：前置准备（并行执行）

```
□ 1. 确认研究对象（名称/类型/股票代码/竞品列表）
□ 2. 读取本地文件（Read 工具，优先关键章节）
□ 3. 识别公司类型（上市/非上市 → 决定数据源策略）
□ 4. 异步工具提前提交（不阻塞，后台运行）：
     - iFind Chain submit → 行业产业链分析
     - iFind Investment submit → 投研报告
     - MX Search → 目标公司概览
     - arXiv API → 技术论文预取（仅硬科技）
□ 5. 本地文件读完后 poll 异步结果
```

### Phase 1：纵向分析（沿时间轴）

**目标**：还原研究对象的完整生命历程，捕捉关键转折点。

**执行步骤**：
1. 读取本地文件中的历史章节（财务DD/法律DD/项目报告）
2. 识别数据缺口 → 选择纵向列工具（参考 `_shared/data-sources.md` §四阶段映射）
3. Bash 调用工具（后台并行）
4. 读取工具输出，提取关键信息
5. 撰写纵向报告正文（8 章，参考 §三之一 模板）
6. 输出 Phase 1 审计表（参考 §八）

**查询策略**：
- 公司历史沿革/事件 → iFind News + MX Search
- 财务时间序列（上市）→ iFind Finance + Tushare
- 财务数据（非上市）→ MX Data D1 + 天眼查
- 技术里程碑 → arXiv API + MX Search
- 行业背景 → MX Data D4 + iFind Chain
- 深度研报 → iFind Investment ★async + MX Search

### Phase 2：横向分析（截面对标）

**目标**：在当下时间切片，将目标公司与竞品进行系统性多维度对比。

**执行步骤**：
1. Poll 异步工具结果（iFind Chain/Investment，如未完成等至 180s）
2. 识别竞品对标数据缺口 → 选择横向列工具
3. Bash 调用补充工具（iFind Finance/AKShare/天眼查）
4. 使用 6 维度对标模板（参考 `domains/commercial-dd.md` §二）
5. 撰写横向报告正文（6 章，参考 §三之一 模板）
6. 输出 Phase 2 审计表

**查询策略**：
- 行业规模/增速/格局 → MX Data D4 + iFind Chain ★async
- 竞品对标（上市）→ MX Data D7 + iFind Finance
- 竞品动态（非上市）→ MX Search + iFind News + 天眼查
- 产业链分析 → iFind Chain ★async
- 技术路线对比 → arXiv API + MX Search

### Phase 3：交叉洞察（纵横交汇）

**目标**：将纵向和横向数据交叉验证，揭示矛盾、生成投资洞察。

**执行步骤**：
1. 多源交叉验证（≥2 源比对关键数据，优先 MX + iFind）
2. **【并行融合 V1.0+】触发 Hermes 独立研究**（见下 §3.1-bis）
3. 矛盾检测与处理（参考 `references/quality-protocols.md` §一）
4. 领域交叉增强（参考 `domains/*.md` §三交叉增强）
5. 撰写交叉报告正文（7 章，参考 §三之一 模板）
6. 输出 Phase 3 审计表

#### §3.1-bis 并行融合 Hermes（V3.48.0+ 固化，2026-07-12）

**背景**：研究质量提升需求——主公 2026-07-12 明确要求：**以后所有使用增强版纵横分析法的研究任务都要同时分发给 Hermes 进行同步研究，结果进行比对融合**（详见 `~/.openclaw/shared/parallel-fusion-architecture.md`）。

**触发条件（V3.48.0 默认必须触发，不需主公点名）**：
- ✅ **【默认】任务使用本 SKILL 纵横分析法**：必触发 Hermes 融合（**不可跳过**）
- 【补动】任务类型含「估值」「DCF」「可比」「并购」「投资建议」「财务尽调」：强制触发 Hermes
- 【补动】项目有财务模型 / 估值模型：强制触发 Hermes
- 【补动】主公明确要求"双代理对比"或类似表述：强制触发 Hermes

**【硬规则】什么时候可以跳过 Hermes？**
- ❌ **默认不允许跳过**——Phase 3 必须执行 Herme 并行融合
- ✅ **唯一可跳过场景**：研究者认为「本次任务无任何量化/估值」内容（例如纯资料整理、纯架构探讨、纯工具设计）——必须明确理由并写到报告《Phase 审计记录》》一节
- ❌ **V1 教训**（2026-07-12）：主公问「是否启动了 Hermes 双重融合」，我因【未追溯半成品任务】让晶能 v3.43.1 deep 错过 Herme 导致主公不满意。**从今以后：半成品+已完成+半成品任务都要检查是否需要补派 Herme。**

【派发渠径】**双轨制**（不需选，双路同时走）：
- **A 径**：文件系统握手——手写 `~/.openclaw/shared/handoffs/outgoing/{task_id}.task.json`
- **B 径**：Hermes kanban——`hermes kanban create ... && hermes kanban assign <id> default && hermes kanban claim --ttl 1800 <id>`

**关键细节**：
1. Hermes 默认 assignee 必须是实际 profile（**`default`，不能用 `kanban-worker`**）
2. dispatcher tick 间隔 60 秒，但 claim 后会立刻 pick up

**执行步骤**：

1. **构造 .task.json**（Phase 3 步骤 1 完成后立即执行）：
   ```python
   task_id = f"{project_name}-P3-{phase3_seq:03d}"
   task_data = {
       "task_id": task_id,
       "created_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
       "created_by": "research",
       "target": target_company,
       "data_sources": [各信源路径],
       "key_questions": ["Q1公司定位", "Q2财务健康", "Q3 DCF估值", 
                         "Q4可比估值", "Q5风险", "Q6投资建议"],
       "requested_output": "full_report",
       "fusion_contract": {
           "deadline_minutes": 30,
           "must_include": ["DCF结果", "可比估值", "敏感性分析", "风险清单"],
           "output_format": "natural_language_markdown"
       }
   }
   out_path = Path.home() / ".openclaw/shared/handoffs/outgoing" / f"{task_id}.task.json"
   out_path.write_text(json.dumps(task_data, ensure_ascii=False, indent=2))
   ```

2. **轮询 Hermes 报告**（最多 30 分钟）：
   ```python
   report_path = Path.home() / ".openclaw/shared/handoffs/incoming" / f"{task_id}.report.md"
   for _ in range(30):
       if report_path.exists():
           log("✅ Hermes 报告已返回")
           break
       time.sleep(60)
   else:
       log("⚠️ Hermes 超时未返，继续自己的分析（Hermes 是 bonus）")
   ```

3. **LLM 融合双源报告**（用 LLM 能力读 .report.md，与自己的分析对比）：
   - 估值分歧（DCF Δ > 10% 显式标注）
   - 风险清单对比（Top3 重叠率）
   - 投资建议对比（同/异）

4. **在 Phase 3 末尾插入"双源对比段"**（报告 §3.7）：
   ```markdown
   ## Phase 3.7 双源对比（OpenClaw vs Hermes）
   
   | 维度 | OpenClaw（我） | Hermes（独立） | 分歧 | 采纳 |
   |------|---------------|---------------|------|------|
   | DCF 估值 | X.X 亿 | Y.Y 亿 | Z% | 取均值/保守 |
   | ... | ... | ... | ... | ... |
   ```

**关键原则**：
- **自然语言优先**：LLM 直接读 .report.md，自己理解、融合
- **Hermes 是 bonus**：超时（30 min）不阻塞主流程
- **分歧显式化**：Δ > 10% 必须在最终报告标记
- **降级优雅**：Hermes daemon 离线/超时 → 继续自己分析，标"Hermes 未返回"

**参考文件**：
- 完整协议：`~/.openclaw/shared/parallel-fusion-architecture.md`
- DCF 引擎：`~/.openclaw/shared/scripts/dcf_valuation_engine.py`（Hermes worker 调用）

#### §3.1-ter 非上市公司三源融合尽调（V3.49.0+ 固化，2026-07-12）

**背景**：主公 2026-07-12 下发 Hermes 推送的「三源融合非上市公司尽调」能力（opencli-integration skill v1.11.0），覆盖 16 维度工商数据（天眼查 + 企业预警通 + 企查查）。**非上市公司没有公开财报/公告/研报，web_search 代替不了**。

**触发条件（V3.49.0+ 默认触发，与 Hermes 并行融合共存）**：
- ✅ **【默认】研究目标是非上市公司**：必触发三源融合（**不可跳过**）
- 【补动】研究目标含子公司/关联方/原股东/历史股东/被投企业等非上市实体
- 【补动】任务含「股权穿透」「实控人」「诉讼风险」「行政处罚」关键词
- 【补动】本地 input/ 有法律 DD 报告但缺工商维度验证

**与 §3.1-bis Hermes 并行融合的关系**：
| 维度 | §3.1-bis（Hermes 独立研究）| §3.1-ter（三源融合尽调）|
|:-----|:-----|:-----|
| 目标 | 任何任务（分析报告级别）| **非上市公司**（数据采集级别）|
| 输出 | 自然语言研究分析 | 自然语言尽调数据 |
| 维度 | 6 个 Q（公司/财务/估值/可比/风险/建议）| 16 维度（工商/股权/穿透/管理/投资/诉讼/处罚/历史/IP/资质/财务/融资/招投标/舆情/关联/信用评分）|
| 触发 | hv_fusion_trigger.py | **hv_three_source.py**（V3.49.0+ 新增）|
| Phase | Phase 3（与主研究并行）| **Phase 2（数据收集阶段并行）**|

**【硬规则】**：
- ❌ **不允许用通用 web_search 替代三源融合**（数据维度差 90%）
- ❌ **不允许跳过**——非上市公司默认必须触发
- ✅ **Hermes 报告未及时返回继续主流程**（30-90s bonus，不阻塞）
- ✅ **必须双轨**：A 径 `outgoing/{task_id}.task.json` + B 径 `hermes kanban create`

**执行步骤**：

1. **Phase 2 数据收集阶段：检测非上市公司并并行触发**：
   ```bash
   python3 ~/.openclaw/workspace-research/skills/hv-analysis/scripts/hv_three_source.py trigger \
     --target "汇天网络科技有限公司" \
     --project-path "~/Documents/.../汇天网络科技" \
     --related-entities "汇天智算（北京）科技有限公司,北京瀚瑞德网络科技有限公司"
   ```

2. **轮询报告**（最多 4 分钟，可与 Phase 2/3 主流程并行）：
   ```bash
   python3 ~/.openclaw/workspace-research/skills/hv-analysis/scripts/hv_three_source.py poll \
     --task-id 汇天网络-三源查询-MMDDHHMMSS --deadline-minutes 4
   ```

3. **报告路径**：`~/.openclaw/shared/handoffs/incoming/{task_id}.report.md`

4. **在 Phase 2 末尾插入「三源融合尽调段」**（报告 §2.6 或类似位置）：
   ```markdown
   ## Phase 2.6 三源融合尽调（Hermes · 三源融合）

   **任务ID**: {task_id}
   **报告大小**: XXXX bytes
   **16 维度覆盖**: ✅ 工商/股权/穿透/管理/投资/诉讼/处罚/历史/IP/资质/财务/融资/招投标/舆情/关联/信用评分

   ### 关键发现（Top 5）
   1. 风险触发：{如行政处罚 N 条、诉讼 M 条}
   2. 股权穿透：{实控人/最终受益人}
   3. 信用评分：{三平台评分}
   4. 关联实体：{风险实体清单}
   5. 资质/牌照：{如 IDC 牌照 / 高新认证}

   ### 与本地项目数据交叉验证
   | 维度 | 本地项目 | 三源融合 | 分歧 |
   |------|---------|---------|------|
   | 法人 | X | Y | 同/异 |
   | 注册资本 | X | Y | 同/异 |
   ```

**自动深度展开触发（来自协议 §3）**：
- 开庭公告 ≥ 5 条 → 自动展开法律诉讼明细
- 行政处罚 > 0 → 自动提取处罚详情（文号/机关/罚金）
- 预警提醒 > 100 → 自动分析预警类型
- 公司解散纠纷 → 🔴🔴 最高风险自动标记
- 裁判文书金额 > 100万 → 自动提取案件详情

**已知限制**（来自协议 §6）：
- 企查查全站强制登录（OpenCLI 共享主 Chrome 远程调试端口）
- 企业预警通非全量（无金融关联企业可能未收录）
- 三家平台数据差异是常态（如实展示差异，标注来源）

**V3.49.0+ 验收测试**（2026-07-12 汇天网络）：
- 派单延迟：~30 秒
- worker 启动命令：`hermes -p default --accept-hooks --skills kanban-worker --skills opencli-integration chat -q work kanban task t_xxx`
- 实际行为：`opencli browser tyc open "https://www.tianyancha.com/" --window background` 真实打开天眼查
- 报告输出：`~/.openclaw/shared/handoffs/incoming/{task_id}.report.md`

**参考文件**：
- 三源协议：`~/.openclaw/shared/three-source-fusion-protocol.md`
- 触发脚本：`skills/hv-analysis/scripts/hv_three_source.py`（V3.49.0 新增）
- Hermes 任务通知：`~/.openclaw/shared/handoffs/outgoing/三源融合能力上线通知-20260712.task.json`

### Phase 4：决策支持（纵横→决策桥接）

**目标**：将分析结论转化为可执行的交易建议。

**加载条件**：任务类型含「尽调/投资/并购/退出/交易」时激活。研究/学术类任务跳过。

**执行步骤**：
1. 读 Phase 1-3 小结章（第 8/14/21 章），提取核心发现和风险项
2. 读本地文件中的交易条款/对赌/回购/退出计划章节
3. 如有投资人沟通会纪要等最新信源，优先采用最新交易条件
4. 撰写决策报告正文（4 章，参考 §三之一 Phase 4 模板）：
   - **第 22 章 交易结构分析**：对比换股/现金/混合方案，计算换股比例，识别障碍项
   - **第 23 章 退出路径分析**：枚举所有可行退出通道，量化时间窗口和回报区间
   - **第 24 章 约束条件建模**：监管约束（IPO 禁令）+ 平台约束（新收上限）+ 谈判约束
   - **第 25 章 情景推演与行动建议**：3 情景 × 多维度 + 优先级标注 + 行动清单
5. 输出 Phase 4 审计表

**查询策略**：
- 最新交易条件 → 本地文件「投资人沟通会纪要」章节 + iFind News
- 监管约束 → iFind Announcement + MX Data D5
- 可比交易 → iFind Finance + MX Search
- 行业退出路径 → iFind Investment ★async

---

### §三内嵌 分析深度原则

> **来源**：P0+P1 回测发现 Agent 存在「默认正面归因」倾向——将变化自动解读为利好，而非生成竞争性假设后择优选。以下原则在**所有分析阶段**适用，不是事后检查项。

#### 四大警醒信号

当遇到以下信号时，Agent **必须**自动生成至少一条竞争性假设（alternative explanation），再选择最符合证据的解释：

**信号 1：费用率大幅下降（>5pp 变动）**
- 默认归因：效率提升 → 竞争性假设：压缩费用美化报表（尤其在 IPO 辅导期）
- 判别方法：检查费用的**绝对值**是否同步下降（绝对值下降 = 真压缩，仅占比下降 = 稀释效应）

**信号 2：估值大幅低于同行（>50% 折价）**
- 默认归因：市场定价错误/认知差套利 → 竞争性假设：市场定价合理（折价反映实质性障碍）
- 判别方法：拆解折价来源——流动性折价 vs IPO 障碍折价 vs 行业周期折价

**信号 3：增速远超行业（>行业 3×）**
- 默认归因：竞争优势/份额提升 → 竞争性假设：低基数效应/一次性订单/统计口径变化
- 判别方法：检查增速的**绝对基数**（+932% 从 300 万到 3,097 万 vs +932% 从 3 亿到 31 亿，含义完全不同）

**信号 4：结构优势被描述为「永久性」**
- 默认归因：这是公司护城河的一部分 → 竞争性假设：优势有时间窗口（如折旧低谷仅 3-5 年）
- 判别方法：量化优势的剩余时间窗口（如固定资产成新率 40% → 预计设备更新时点）

#### 竞争性假设信号表

| 信号 | 触发条件 | 默认归因 | 竞争性假设 | 判别方法 |
|------|---------|---------|-----------|---------|
| S1 费用率骤降 | 费用率下降 >5pp | 效率提升 | 压缩费用美化报表 | 检查绝对值是否同步下降 |
| S2 估值折价 | 估值低于同行 >50% | 市场错误定价 | 折价反映实质障碍 | 拆解折价来源 |
| S3 增速异常 | 增速 >行业 3× | 竞争优势 | 低基数/一次性/口径变化 | 检查绝对基数 |
| S4 优势永久化 | 优势被描述为结构性 | 永久护城河 | 优势有期限 | 量化剩余时间窗口 |

**信号 5：退出路径单一化（决策偏差，Phase 4 专用）**
- 触发条件：报告中仅呈现一种退出路径，或默认接受管理团队提出的唯一退出方案
- 默认归因：这是当前条件下唯一可行的路径 → 竞争性假设：存在替代退出路径但被交易参与方排除（如管理层偏好换股 vs 独立上市 vs 基金退出）
- 判别方法：枚举所有理论可行退出通道，逐一分析被排除的原因（商业原因 vs 谈判原因），标注哪些排除是可逆的

**信号 6：估值锚定偏差（决策偏差，Phase 4 专用）**
- 触发条件：直接采纳最新报价（如"整体估值约40亿"）作为估值锚，未回溯到历史口径
- 默认归因：最新报价反映最新信息/最新谈判结果 → 竞争性假设：报价受谈判地位/时间压力/退出紧迫性扭曲
- 判别方法：列出≥2个估值锚点（历史投前估值 vs 当前交易估值），比对业绩变化幅度和估值变化幅度的匹配度

**信号 7：约束条件静态化（决策偏差，Phase 4 专用）**
- 触发条件：将某个约束（如「3 年 IPO 禁令」「新收仅 1 家」）视为不可变的绝对限制
- 默认归因：约束不可变，必须在此框架下寻找方案 → 竞争性假设：约束可被交易结构设计绕开或缓解
- 判别方法：逐项分析约束的「可规避性」（完全不可规避 / 可通过交易条款绕开 / 可随时间自动解除）

#### 竞争性假设信号表（决策偏差扩展）

| 信号 | 触发条件 | 默认归因 | 竞争性假设 | 判别方法 |
|------|---------|---------|-----------|---------|
| S5 退出单一化 | 仅 1 种退出路径 | 唯一可行路径 | 替代路径被排除（可逆） | 枚举所有退出通道+排除原因 |
| S6 估值锚定 | 直接采纳最新报价 | 最新报价=公允价值 | 报价被谈判压力扭曲 | ≥2个估值锚点+业绩-估值匹配度 |
| S7 约束静态化 | 约束被视为绝对限制 | 约束不可变 | 交易结构可绕开或时间可解除 | 逐项评估「可规避性」 |

#### 每章完成后自问 4 题

每写完一章，Agent 必须自问：

```
Q1: 本章的核心结论是否有 ≥2 个独立数据源支撑？
Q2: 本章是否触发了七大警醒信号中的任何一条？（如触发 → 生成竞争性假设后再写结论）
Q3: 本章是否遗漏了该领域公认的关键分析维度？（对照领域 Checklist）
Q4: 本章的最低字数要求是否满足？（对照 §三之一 各章字数下限）
```

---

### §三之一 报告结构模板

> **强制要求**：以下 21 章（分析模式）或 25 章（决策模式）为报告最低标准。Agent 可根据研究对象类型调整章节名称，但不得减少章数或合并章节。决策模式下 Phase 4（第 22-25 章）强制激活。

#### Phase 1 纵向分析（8 章，总字符 ≥ 8,000）

> **逐章字数为引导线**：Agent 应根据数据可得性自主分配篇幅。强章（有丰富本地文件支撑）可远超最低线，轻章（外部数据有限）可低于最低线。**总字符 ≥8,000 为硬性约束**，由 §十二 自检命令强制执行。

| 章 | 标题 | 核心内容 | 引导字数 | 内容密度要求 |
|:--:|------|---------|:------:|-------------|
| 1 | 公司概况与发展历程 | 成立背景/股权演变/关键里程碑/实际控制人 | 1,000 | ≥3 个关键时间节点 + 股权结构表 |
| 2 | 业务结构与收入演变 | 产品线拆分/量价驱动/地区分布/客户结构 | 1,000 | ≥3 年数据 + 按产品线×地区拆分 |
| 3 | 财务表现与盈利质量 | 营收/净利/毛利率/ROE 趋势 + QoE 调整 | 1,000 | ≥3 年三表核心指标 + 扣非 vs GAAP |
| 4 | 技术与知识产权 | 技术路线/专利布局/研发投入/技术里程碑 | 600 | 专利数量+类型+法律状态 |
| 5 | 公司治理与团队 | 董事会/核心团队/股权激励/历史合规 | 600 | 实控人控制路径 + ESOP 详情 |
| 6 | 产业链定位 | 上下游结构/议价力/利润池分布/垂直整合 | 500 | 供应商CR3 + 客户CR3 |
| 7 | 盈利预测与假设检验 | 预测假设逐项验证/敏感性分析 | 600 | 收入增速/毛利率/费用率 3 项假设检验 |
| 8 | 纵向分析小结 | 核心发现/关键转折点/待验证问题 | 500 | ≥3 个核心发现 |

**Phase 1 硬性约束：总字符 ≥ 8,000**

#### Phase 2 横向分析（6 章，总字符 ≥ 6,000）

> 同 Phase 1，逐章字数为引导线，**总字符 ≥6,000 为硬性约束**。

| 章 | 标题 | 核心内容 | 引导字数 | 内容密度要求 |
|:--:|------|---------|:------:|-------------|
| 9 | 行业规模与竞争格局 | 市场规模/CAGR/CR5/波特五力/政策环境 | 1,000 | TAM/SAM/SOM + CR5 趋势 |
| 10 | 竞品对标矩阵 | 6维度对标（技术/产品/用户/优劣势/定价/规模）| 1,000 | ≥3 家竞品 + 完整6维度 |
| 11 | 技术路线对比 | 技术路径差异/性能指标/专利布局/研发投入对比 | 600 | ≥2 条技术路线量化对比 |
| 12 | 商业模式对比 | 收入模式/成本结构/盈利质量/增长驱动 | 600 | 至少覆盖收入模式+成本结构 |
| 13 | 估值横向对比 | PE/PB/PS/EV-EBITDA/非上市流动性折价 | 800 | ≥3 个估值指标 + 竞品对比 |
| 14 | 横向分析小结 | 相对定位/差异化优势/竞争劣势/待验证问题 | 500 | ≥3 个核心发现 |

**Phase 2 硬性约束：总字符 ≥ 6,000**

#### Phase 3 交叉洞察（7 章，≥ 4,000 字符）

| 章 | 标题 | 核心内容 | 最低字符 | 内容密度要求 |
|:--:|------|---------|:------:|-------------|
| 15 | 核心矛盾揭示 | 纵横向数据矛盾/财务×法律交叉/竞争×合规交叉 | 800 | ≥2 个矛盾点 |
| 16 | 竞争优势持续性评估 | 护城河评分/时间窗口量化/替代威胁 | 600 | 5 类护城河逐项评分 |
| 17 | 风险交叉验证 | 财务风险×法律风险×商业风险关联 | 600 | ≥3 个交叉风险 |
| 18 | 估值三锚校验 | 交易价格/PE对标/SOTP 三重锚定 + 双口径并列对照（当≥2个估值时点，触发 financial-dd.md §3.5 强制输出） | 600 | 三锚估值区间表 + 双口径P/S/P/E/P/B对照表 |
| 19 | 成长空间量化 | TAM/SAM/SOM + 新市场可行性 | 500 | 三层市场空间测算 |
| 20 | 投资结论与建议 | 核心投资逻辑/7维星级评分/风险收益比/优先级/行动建议/数据置信度表 | 600 | ≥3 条明确建议 + 7 维评分 + 置信度表 |
| 21 | 交叉分析总结 | 全文核心洞察汇总 | 400 | ≥5 个关键洞察 |

**第 20 章 结构化输出模板（强制）**：

> 第 20 章是报告的「决策摘要」，必须包含以下 5 个模块，不得遗漏。**5 个模块必须内嵌在第 20 章中，不得分散到其他章节。** 即使其他章节已做详细分析（如第 23 章退出路径、第 25 章情景推演），第 20 章仍需包含各模块的结论快照。

**模块 1：7 维星级评分（强制）**

| 维度 | 评分 | 说明 |
|------|:----:|------|
| 行业前景 | ⭐(1-5) | 行业增速/景气度/政策方向 |
| 商业模式 | ⭐(1-5) | IDM/轻资产/平台/差异化 |
| 盈利能力 | ⭐(1-5) | 净利率/ROE/现金流 vs 同行 |
| 成长性 | ⭐(1-5) | 历史增速 + 预测增速 + 新业务 |
| 财务健康 | ⭐(1-5) | 资产负债率/流动性/融资能力 |
| 估值合理性 | ⭐(1-5) | PE/PB/PS vs 同行 + 流动性折价 |
| 投资性价比 | ⭐(1-5) | 综合风险收益判断 |

**模块 2：优先级标注规则（强制）**

| 优先级 | 触发条件（至少满足 2 条） | 标签 |
|:------:|--------------------------|------|
| **P1** | 高综合评分(≥4星×5) + 明确退出约束 + 时间窗口紧迫 | 🔴 优先推进 |
| **P2** | 中等评分(3-4星) 或 评分高但退出路径不确定 | 🟡 持续跟踪 |
| **P3** | 低评分 或 存在不可规避的重大障碍 | 🟢 观察 |

**模块 3：投资建议（强制）**

```
核心投资逻辑（1-2句）：为什么投/为什么不投？
投资亮点（≥3条，每条不超过2行）
主要风险（≥3条，每条标注严重程度：🔴高 / 🟡中 / 🟢低）
行动建议（≥3条，每条含时间节点和前置条件）
```

**模块 4：退出路径快照**

| 退出路径 | 可行性 | 时间窗口 | 预期回报 | 关键前置条件 |
|---------|:------:|:------:|:------:|-------------|
| 路径1 | — | — | — | — |
| 路径2 | — | — | — | — |

**模块 5：数据置信度表（强制）**

| 数据来源 | 文件 | 可信度 |
|---------|------|:------:|
| 财务尽调报告 | {文件名} | ⭐⭐⭐⭐⭐ A级（审计级） |
| 法律尽调报告 | {文件名} | ⭐⭐⭐⭐ A级（法律尽调） |
| 项目报告 | {文件名} | ⭐⭐⭐⭐ B级（内部尽调） |
| 投资人沟通会纪要 | {日期} | ⭐⭐⭐ C级（非正式，需交叉验证） |
| 外部数据（iFind/MX） | — | ⭐⭐⭐⭐⭐ A+级（交易所监管数据） |

**Phase 3 最低总字符：4,000**

**第 18 章 双口径并列对照补充（强制触发）**：

> 当项目存在 ≥2 个不同时点的估值锚（如 MBO 价格 + 本轮投前 + 当前交易估值），第 18 章必须包含以下双口径对照表，与三锚校验并列输出。模板详见 financial-dd.md §3.5。

| 口径 | 数据基期 | 估值锚点 | P/S | P/E | P/B | 说明 |
|------|---------|---------|:---:|:---:|:---:|------|
| 历史口径 | {最早审计年度} | {原始入场估值} | — | — | — | 原始入场成本/安全垫计算 |
| 当期口径 | {最新数据年度} | {当前交易估值} | — | — | — | 当前交易性价比/退出回报 |

**强制规则**：
- 双口径输出与 financial-dd.md §3.5 联动，财务DD 领域激活时自动触发
- 当期口径若来自 C 级数据源（如沟通会纪要），必须标注 `[C级-待验证]`
- 两个口径的估值倍数差异 ≥20% 时，必须给出解释（业绩增长 vs 估值下调 vs 市场环境）

#### Phase 4 决策支持（4 章，≥ 3,000 字符）

> **加载条件**：任务类型含「尽调/投资/并购/退出/交易」时激活。研究类任务跳过，不强制。

| 章 | 标题 | 核心内容 | 引导字数 | 内容密度要求 |
|:--:|------|---------|:------:|-------------|
| 22 | 交易结构分析 | 换股/现金/混合方案对比、换股比例计算、支付节奏、障碍项（基金亏损/合规缺口）| 800 | ≥2 种交易结构方案量化对比 |
| 23 | 退出路径分析 | 独立上市/被并购/注入平台的可行性矩阵、时间窗口、回报区间、约束条件传导 | 800 | 至少覆盖 3 种退出路径 + 可行性评分 |
| 24 | 约束条件建模 | 监管约束（IPO 禁令/股东处罚）、平台约束（新收上限）、谈判约束（对方诉求）的量化影响 | 600 | 每项约束标注「确定性/影响程度/可规避性」 |
| 25 | 情景推演与行动建议 | 保守/中性/乐观 3 情景 × 估值/回报维度、优先级标注、下一步行动清单 | 800 | ≥3 情景 + 每情景含：隐含市值/PE倍数/基金IRR/MOIC + 行动建议 |

**Phase 4 硬性约束**：总字符 ≥ 3,000（激活时）

**第 25 章 IRR 分级输出模板（强制）**：

> 情景推演中每个情景必须计算基金层面回报指标，不得仅给出定性描述。

| 情景 | 概率 | 隐含市值 | PE倍数 | 基金IRR | MOIC | 关键前提 |
|------|:--:|:------:|:-----:|:-----:|:---:|---------|
| 保守 | 25% | — | — | — | — | — |
| 中性 | 50% | — | — | — | — | — |
| 乐观 | 25% | — | — | — | — | — |

**IRR 计算说明**：
- 基金IRR = 基于投资金额、退出市值、持有期限的年化内部收益率
- MOIC = 退出价值 / 投资成本（倍数）
- 持有期默认：3年（若退出路径为换股并购）或 5年（若退出路径为 IPO）
- 概率加权IRR = Σ(情景IRR × 概率)

**强制规则**：
- 决策模式下 IRR 分级表为强制输出，不得省略
- 保守情景的 IRR 不得低于回购条款保底回报（如年化 6%）
- 若某个情景的 MOIC < 1.0x，必须标注为 🔴 亏损情景

#### 报告总字数要求

| 模式 | 最低总字符 | Phase 1 | Phase 2 | Phase 3 | Phase 4 |
|------|:------:|:------:|:------:|:------:|:------:|
| **标准模式（决策）** | 21,000 | 35-45% | 25-35% | 12-20% | 10-18% |
| **标准模式（研究）** | 18,000 | 35-50% | 25-40% | 15-35% | — |
| **快速模式**（仅 1 个领域）| 10,000 | 45-60% | 20-35% | 15-30% | — |

#### 来源标注格式（强制）

报告中每个数据点必须标注来源，使用方括号。支持以下标注层级：

**基础格式（单一来源）**：
```
[本地财务DD]  [本地法律DD]  [本地项目报告]
[iFind Finance]  [iFind News]  [iFind Announcement]  [iFind Investment]
[MX Data D1-D7]  [MX Search: YYYY-MM-DD]
[Tushare]  [AKShare]  [arXiv: paper_id]  [天眼查]
```

**组合格式（多源 + 验证层级 + 假设条件）**：
```
[本地项目报告 + 法律DD]                              ← 多源组合
[财务DD + iFind Finance]                              ← 本地+外部组合
[T1, 双源验证: 本地法律DD + iFind Announcement]        ← 关键数据带验证层级
[T2, 本地+iFind]                                      ← 重要数据带层级
[iFind Announcement — 双源验证]                        ← 带验证状态
[项目报告；假设前提：净利率17-18%，补贴稳定在3,500万元]  ← 带假设条件
[数据来源：财务DD（信永中和）]                          ← 带审计机构名
```

**强制规则**：
- T1 数据点必须使用带 `T1, 双源验证:` 前缀的组合格式
- 有明确假设条件的数据点必须在标注中注明
- 审计/评估数据应注明出具机构名称

---

## §四 数据源选择原则

> 完整的数据源能力矩阵、工具速查表、逐工具详解、MX-iFind 互补关系、强制路由规则、定向降级链、MX 配额预算、工具预热协议，见 **`_shared/data-sources.md`**。

Agent 在每次分析中遵循以下原则：

1. **本地文件优先**：所有 DD 模式的首要数据源，最权威的一手来源
2. **结构化数据用结构化工具**：绝不交叉使用（详见 §二 强制路由规则）
3. **MX + iFind 双源互补**：来自不同数据生态，同时使用实现独立双源交叉验证
4. **异步工具优先提交**：iFind Chain/Investment 需要 180s，session 开始就 submit
5. **MX 配额预算管理**：日配额 10 次（MX Search），分 Phase 配给（P0≤1/P1≤2/P2≤5/P3≤2）
6. **SearXNG 是最后选择**：仅当 MX/iFind 全链路失败时使用
7. **工具失败时按降级链降级**：不阻塞流程，标注降级路径

---

## §五 领域路由规则

Agent 根据任务类型自动加载对应的领域增强文件：

| 任务关键词 | 加载文件 | 触发条件 |
|-----------|---------|---------|
| 商业尽调 / 投资分析 / 行业研究 | `domains/commercial-dd.md` | 默认加载 |
| 财务尽调 / 估值分析 / 盈利质量 | `domains/financial-dd.md` | 任务含"财务/估值/盈利" |
| 法律尽调 / 合规审查 / IP核查 | `domains/legal-dd.md` | 任务含"法律/合规/诉讼/IP" |
| 并购尽调（综合）| 三个文件全部加载 | 任务含"并购/收购/尽调" |
| **决策支持 / 退出分析 / 交易设计** | 三个文件全部 + Phase 4 激活 | 任务含"退出/交易/换股/IPO/并购方案" |

**加载方式**：Agent 在 Phase 0 前置准备阶段，根据任务类型读取对应领域文件。领域文件提供：
- 纵向分析增强（嵌入 Phase 1 特定章节）
- 横向分析增强（嵌入 Phase 2 对标模板）
- 交叉增强（嵌入 Phase 3 交叉验证）
- 领域专用数据源偏好

**决策模式 vs 分析模式**：

| 维度 | 分析模式 | 决策模式 |
|------|---------|---------|
| 触发词 | 研究/分析/了解/评估 | 尽调/投资/并购/退出/交易/换股 |
| Phase | 1-3（研究） | 1-4（研究+决策） |
| 章节数 | 21 章 | 25 章 |
| 最低总字符 | 18,000 | 21,000 |
| 必需数据源 | 本地文件 + iFind | 本地文件 + iFind + 投资人沟通会纪要 |
| 输出 | 公司分析报告 | 公司分析报告 + 可执行交易建议 |

**自动检测规则**：Agent 在 Phase 0 根据用户任务描述自动选择模式：
- 含「退出/交易/换股/并购方案」→ 决策模式
- 含「尽调/投资」→ 默认决策模式（内嵌交易判断）
- 含「研究/学术/技术分析」→ 分析模式
- 无法判断 → 默认分析模式

---

## §六 质控协议

> 完整的质量控制标准（多源交叉验证协议、数据源权威性矩阵、矛盾处理规则、幻觉防御四步法、来源权威性六等级标注体系），见 **`references/quality-protocols.md`**。

### 关键检查点（Phase 结束时强制执行）

1. **多源验证**：T1 关键数据（估值/净利/对赌/实控人风险）必须 ≥2 个独立源
2. **来源标注**：报告中每个数据点强制标注来源（方括号格式）
3. **Phase 审计表**：每个 Phase 结束后追加数据源调用审计表（格式见 §八）
4. **幻觉防御**：报告 ≥3,000 字且含 ≥10 条数值陈述时，部署四步法（H1-H4）
5. **风险阈值**：防御率 ≥80% 低风险 / 60-80% 中风险 / <60% 高风险（建议补充检索）

---

## §七 输出文件规范

### 7.1 文件命名

```
{任务ID}_{对象名}_{分析类型}_v{版本号}_{日期}.md
{任务ID}_{对象名}_{分析类型}_v{版本号}_{日期}.html
```

示例：`jneng_photoelectric_商业尽调报告_v1_20260706.md`

### 7.2 输出目录

```
output/{任务ID}/
  ├── {报告}.md          ← Agent 直接写入
  ├── {报告}.html         ← 渲染脚本生成
  └── _source_audit/      ← Phase 审计表归档（可选）
```

### 7.3 HTML 渲染

报告定稿后调用渲染脚本：

```bash
python3 /Users/jinzhanxiang/.openclaw/workspace-research/skills/hv-analysis/scripts/hv_render_wrapper.py \
  output/{任务ID}/{报告}.md
```

### 7.4 交付物清单

- [ ] Markdown 报告（21/25 章完整结构，研究模式 21 章 / 决策模式 25 章）
- [ ] HTML 报告（商务尽调级渲染）
- [ ] 三个 Phase 审计表完整
- [ ] 全流程数据源覆盖总览
- [ ] 所有 T1 数据点双源验证通过

---

## §八 Phase 审计

### 8.1 Phase 结束审计表（强制输出）

每个 Phase 结束后，在报告末尾追加：

```markdown
### Phase {N} 数据源调用审计

| # | 工具 | 查询内容 | 状态 | 产出 | 新增关键信息 |
|---|------|---------|:--:|------|-------------|
| 1 | 本地文件 | — | ✅ | N页 | — |
| 2 | MX Search | "..." | ✅ | 15条 | — |
| ... | ... | ... | ... | ... | ... |

**本阶段统计**：工具调用数 / 独立数据源数 / 异步任务提交数-完成数 / 数据缺口
```

**要求**：
- 每个工具调用占一行，如实记录状态（✅成功 / ❌失败 / ⏳等待中 / 🔄降级）
- 工具失败时标注降级路径（如 `iFind 429 → 降级到 MX Search`）
- 「新增关键信息」列用简短短语列出增量信息
- 汇总统计必须明确「独立数据源 ≥2」是否满足

### 8.2 全流程覆盖总览（Phase 5 强制输出）

```markdown
### 全流程数据源覆盖总览

| 数据源 | 调用 | 成功 | 降级 | 贡献阶段 | 评级 |
|--------|------|------|------|---------|------|
| ... | ... | ... | ... | ... | ... |

**覆盖健康度**：
- 独立数据源：{M} 个（目标 ≥5，健康 ≥7，优秀 ≥9）
- T1 关键数据双源验证：{X}/{Y} 通过
- 最终数据缺口：{列出}（如无 → ✅ 无）
```

---

## §九 HTML 渲染层（**V3.42.2+ 极简商务尽调标准**）

### 渲染脚本

`scripts/md_to_html_v3422.py`（V3.42.2+ 极简版）+ `scripts/inject_charts_into_html.py`（图表注入）

### 核心设计原则（主公 2026-07-07 明确指示）

1. **极简单色**：仅深蓝 `#1a365d` 系 + 琥珀金 `#d69e2e` 系 + 暖白 `#fafaf9` 系
2. **不含**：HUD、玻璃拟态、4 级阴影、3 渐变、pulse 动效、侧边 TOC、顶部进度条、KPI 渐变、滚动动画、Hero 装饰
3. **保留**：暗色模式切换（V3.42.5 bug 修复）、打印样式 @page A4
4. **中文字体**：`-apple-system, "PingFang SC", "Microsoft YaHei", sans-serif`

### 表格配色严格规范（2026-07-07 主公考核点）

| 元素 | 浅色模式 | 暗色模式 | 备注 |
|------|---------|---------|------|
| **表头底色** | `#1a365d` 深蓝 | `#1a365d` 深蓝 | **品牌主色** |
| **表头文字** | `#ffffff` 纯白 | `#d69e2e` 琥珀金 | 浅底白字 / 暗底金字 |
| **表头下边线** | `#d69e2e` 琥珀金 3px | `#d69e2e` 琥珀金 3px | 视觉锦点 |
| **表体底色（奇行）** | `#ffffff` 纯白 | `#1a202c` 深黑 | 默认行 |
| **表体底色（偶行）** | `#f7fafc` 极浅蓝灰 | `#2d3748` 深灰 | 斑马纹 |
| **表体文字** | `#1a202c` 深灰 | `#e2e8f0` 浅灰 | ≥15:1 对比度 |
| **第一列（行索引）** | `#1a365d` 深蓝 + 700 | `#d69e2e` 琥珀金 | 加粗加重 |
| **第二列（数字）** | `#1a365d` 深蓝 + 600 | `#d69e2e` 琥珀金 | 数字加粗 |
| **末行（汇总）** | `#fef3c7` 浅琥珀底 + 深蓝字 | `#3d2f00` 深琥珀底 + 金字 | 2px 琥珀金顶边线 |
| **悬停（hover）** | `#fef3c7` 浅琥珀 + 深蓝字 | `#3d2f00` 深琥珀 + 金字 | `!important` 覆盖 |
| **表格外框** | `1px solid #cbd5e0` | `1px solid #4a5568` | 圆角 6px |

### 链接配色规范（避免与表头同色冲突）

| 元素 | 浅色 | 暗色 | 设计理由 |
|------|------|------|---------|
| **链接默认** | `#b7791f` 深琥珀金 + 1px dotted 下划线 | `#63b3ed` 浅青蓝 | 与表头深蓝错开 |
| **链接 hover** | `#975a16` 深棕 + solid 下划线 | `#d69e2e` 琥珀金 | 强化反馈 |

### 中文字体加载（图表场景）

```python
import matplotlib.font_manager as fm
font_prop = fm.FontProperties(fname='/System/Library/Fonts/STHeiti Medium.ttc')
```

macOS bash 3.2.57 不支持 ANSI 转义颜色 → banner 纯文本，不加颜色。

### 图表色板硬约束（**核心设计语言**）

**仅限 5 色**（2 必要辅助色）：
- `#1a365d` 深蓝（主色，标题/数据系列1）
- `#2c5282` 浅蓝（辅助，复杂图）
- `#d69e2e` 琥珀金（主色，数据系列2 / 强调）
- `#fef3c7` 浅琥珀（底色，高亮）
- `#fafaf9` 暖白（背景）
- `#cbd5e0` 浅蓝灰（斑马纹 / 中性节点）
- `#ecc94b` 浅琥珀中调（按需，数据系列）

**拒绝**：HUD、玻璃拟态、4 级阴影、3 渐变、pulse 动效、彩虹色、Material Design 全套

### 报告交付链路（一体化）

```bash
# Step 1：MD → HTML 极简渲染
python3 scripts/md_to_html_v3422.py report.md -o report_prechart.html -t "标题"

# Step 2：注入图表（base64 嵌入）
python3 scripts/inject_charts_into_html.py report_prechart.html -o report.html

# Step 3：HTTP 服务交付
python3 -m http.server 8090 --bind 0.0.0.0 --directory scripts/reports/

# Step 4：主公访问
http://192.168.7.25:8090/{filename}.html
```

### 常见问题快速诊断

| 问题 | 原因 | 修复 |
|------|------|------|
| 表格内容只有表头 | `\|` 数据行被解析为段落 | 修复表格检测：仅 SEP 行视为表头分隔，后续 `\|` 行都收集 |
| `**` `\|` `---` 裸源漏出 | 解析器未处理内联格式 | 检查 `process_inline` 是否被调用 |
| hover 看不清 | 悬停色与背景对比不足 | `#fef5e7` → `#fef3c7`（更深的浅琥珀） |
| 链接看不清 | 链接蓝与表头深蓝同色系 | 链接色 `#3182ce` → `#b7791f`（深琥珀金） |
| 图表被裁切 | chart-figure 无 overflow | 加 `overflow:hidden` + 缩小图表到 ≤1000px 宽 |
| 中文字体不渲染 | .ttc 字体名注册失败 | 用 `FontProperties(fname=路径)` 绕过 |
| 表格列宽不合理 | `table-layout:fixed` + 短列被拉宽 | `table-layout:auto` + `<colgroup>` 按内容字符权重动态分配 |
| 表格内容溢出 | `td` 短字串被 nowrap 压缩 | `white-space:normal` + `word-break:break-word` + `overflow-wrap:break-word` |
| 图表是“贴片”不是“嵌入” | 图表 PNG 白底 vs body 暖白 色差 | PNG 白底调为 `#fafaf9` 暖白 + chart-figure 顶 3px 深蓝 + 底 3px 琥珀金边框 |
| **图表文字看不清**（最常见） | **PNG 是别人生成的，字体控制不了** | **必须加 HTML 数据表对照**（图表下方插 data-table-compact） |
| **产业链上下游需要可视化** | 报告里只有 ASCII 代码块 | **重画为 HTML 流程图**（CSS grid + 矢量、中间列高亮、深蓝/琥珀金配色） |
| **PDF/打印断页** | 默认 CSS 无 @page 规则 | 添加 `@media print` + `break-after:page` 控制断页位置 |
| **KPI 数字看不清** | matplotlib 默认字号过小 | **加 KPI 重叠块**（HTML span 叠在 PNG 上方，深蓝大字号） |

### V3.42.7+ 表格列宽自适应算法（`flush_table`）

**问题**：4 列时间表（年份/事件/战略意义/来源）原来“年份列过宽、事件列过窄”。

**原理**：表格渲染时在 Python 解析阶段**计算每列内容字符权重**（中文×2 + 英文×1.2），生成 `<colgroup><col width="X%">`，浏览器按比例分配。

```python
# 字符权重：中文字符×2 + 其他×1.2
def cell_weight(text: str) -> float:
    t = re.sub(r'\*\*([^*]+)\*\*', r'\1', text)
    chinese = sum(1 for c in t if '\u4e00' <= c <= '\u9fff')
    other = len(t) - chinese
    return chinese * 2 + other * 1.2

# 每列取最大权重，总和归一为 100%
col_weights = [max(max(cell_weight(c) for c in col), 8) for col in cols]
col_pct = [round(w / sum(col_weights) * 100, 1) for w in col_weights]
colgroup = '<colgroup>' + ''.join(f'<col style="width:{p}%">' for p in col_pct) + '</colgroup>'
```

**验证**：航天宏图 1.2 关键里程碑 = 年份 9.1% / 事件 44.8% / 战略意义 26.8% / 来源 19.3%（事件列最长，分到最多空间）。

### V3.42.7+ 图表背景融合（`inject_charts_into_html.py`）

**问题**：matplotlib 默认 `facecolor='white'`，与报告 body 暖白 `#fafaf9` 有可辨识的色差，看起来是“贴片”。

**解决方案**：
1. **Pillow 预处理**：将 PNG 中 RGB(>240,>240,>240) 的纯白像素全部替换为 `#fafaf9` 暖白（浅色版）/ `#1a202c` 深色（暗色版）
2. **双图叠加**：浅色版为 `class="chart-light"`，暗色版为 `class="chart-dark"`
3. **CSS 媒体查询**：`body.dark-mode .chart-light{display:none}` + `body.dark-mode .chart-dark{display:block}`
4. **chart-figure 边框（视觉锦点）**：顶 3px 深蓝 + 底 3px 琥珀金 + 1px 浅蓝灰四边，让图表“锺定”于 body 而不是“贴上去”

```python
from PIL import Image
img = Image.open(png).convert('RGBA')
pixels = img.load()
for y in range(h):
    for x in range(w):
        r, g, b, a = pixels[x, y]
        if r > 240 and g > 240 and b > 240:
            pixels[x, y] = (250, 250, 249, 255)  # 暖白
img.save(warm_path, optimize=True)
```

**输出**：`{name}_warm.png` + `{name}_dark.png` 缓存在 `scripts/reports/_charts/`。

### V3.42.8+ 图表文字可读性 = HTML 数据表对照（必须）

**问题**：图表 PNG 是 project 代理/报告专家生成的，research **不能改字体、字号**。主公反馈"图表上的文字看不清楚"。

**原理**：叠使用 HTML 数据表（`data-table-compact`）与 PNG 图互补，保证"印刷品级"可读，不依赖 PNG 字号。

```python
# inject_charts_into_html.py - CHART_INJECTIONS 配置中加 'data_table' 字段
{
    'key': 'chart1',
    'caption': '**图 1** — 航天宏图 2019-2025 营收/净利财务时序',
    'after': '三、财务表现与盈利质量',
    'image': 'chart1_financial_timeline.png',
    'data_table': '''
<table class="data-table-compact card-table">
  <thead><tr><th>年份</th><th>营收</th><th>归母净利</th><th>同比</th></tr></thead>
  <tbody>
    <tr><td>2022</td><td><strong>24.1</strong></td><td><strong>2.5</strong></td><td><strong>+73%</strong></td></tr>
    <tr><td>2025</td><td>4.5</td><td><strong style="color:#c53030;">−18.6</strong></td><td>−71%</td></tr>
  </tbody>
</table>
''',
}
```

**CSS 补充**：
```css
.chart-data-table{margin-top:20px;padding-top:16px;border-top:1px dashed #d69e2e}
.chart-data-table table{width:100% !important;max-width:760px;margin:0 auto;font-size:14px}
body.dark-mode .chart-data-table{border-top-color:#4a5568}
```

**验证**：航天宏图图 1 财报 + 图 3 债务 + 图 5 IRR + 图 8 雷达 4 个关键图表都有数据表。**评级 5/5**。

### V3.42.8+ 产业链结构图 = HTML/CSS grid 矢量（必须）

**问题**：报告里 6.1 章节只有 ASCII 代码块，主公要求"可视化展现"。

**原理**：用 CSS grid 画三栏式产业链（上→中→下），中间列高亮、箭头连接、节点卡片。矢量、可缩放、响应式。

```html
<div class="chain-container">
  <div class="chain-stage chain-upstream">...</div>
  <div class="chain-arrow">→</div>
  <div class="chain-stage chain-midstream chain-highlight">...</div>
  <div class="chain-arrow">→</div>
  <div class="chain-stage chain-downstream">...</div>
</div>
```

```css
.chain-container{display:grid;grid-template-columns:1fr auto 1.2fr auto 1fr;gap:14px}
.chain-midstream.chain-highlight{background:linear-gradient(180deg,#fafaf9,#fff);border:2px solid #d69e2e}
.chain-node-pie{background:linear-gradient(135deg,#fef3c7,#fde68a);border:2px solid #d69e2e}
@media (max-width:980px){.chain-container{grid-template-columns:1fr}}
```

**验证**：航天宏图 6.1 产业链图 = 三段式清晰 / 中游 PIE 高亮 / 毛利梯度数据完整 / **评级 5/5**。

---

## §十 Challenge B 防幻觉核查（简要参考）

完整防幻觉核查由 `hv_challenge_b_v3.py` 驱动（~1,800 行，全 LLM Prompt 架构）：

```bash
python3 scripts/hv_challenge_b_v3.py --input report.md --output result.json
python3 scripts/render_challenge_b_v3.py result.json report.html
```

**防幻觉门槛**：幻觉数 = 0 且 冲突数 < 5 → PASS。否则 FAIL，需修正后重新核查。

Agent 在 Phase 3 结束后可选择运行 Challenge B 进行全量数据点核查（141 个数据点，5 源金融数据接入）。详见脚本源码。

---

## §十一 领域增强

以下三个领域文件提供专业级分析增强，Agent 按 §五 路由规则加载：

| 文件 | 核心增强 | 标志性工具 |
|------|---------|-----------|
| `domains/commercial-dd.md` | 收入3维拆分/客户结构/护城河5类评分/产业链利润池/竞品6维度模板/波特五力/TAM-SAM-SOM | 竞品对标6维度模板（强制使用） |
| `domains/financial-dd.md` | QoE盈利质量/政府补助依赖度/营运效率/盈利预测假设检验/财务对标矩阵/三情景DCF/三重锚定校验/SOTP分部估值/双口径估值 | 30%缺乏流动性折价（非上市自动应用） / SOTP（≥3业务板块）/ 双口径（多时点估值锚） |
| `domains/legal-dd.md` | 股权历史沿革/IP三链验证/合规事件时间线/4×4合规风险矩阵/同业竞争/关联交易公允性 | IP三链验证（创造链/权属链/应用链） |

---

## §十二 字数强制执行

> **设计目的**：字数不是指标，是内容深度的代理变量。低于下限意味着某个维度被跳过了。

### 12.1 自检命令

报告写完后，Agent 必须运行以下 Python 自检：

```bash
python3 -c "
import re
text = open('output/{任务ID}/{报告}.md').read()

# 检测 Phase 4 是否激活（检查第22章标记）
has_p4 = '## 二十二、交易结构分析' in text or '## 22. 交易结构分析' in text

# Phase 切分
p1_end = text.find('## 九、行业规模') if '九、行业规模' in text else text.find('## 9. 行业规模')
p2_end = text.find('## 十五、核心矛盾') if '十五、核心矛盾' in text else text.find('## 15. 核心矛盾')
p3_end = text.find('## 二十二、交易结构分析') if '二十二、交易结构分析' in text else text.find('## 22. 交易结构分析')

p1 = text[:p1_end] if p1_end > 0 else ''
p2 = text[p1_end:p2_end] if p1_end > 0 and p2_end > 0 else ''
p3 = text[p2_end:p3_end] if p2_end > 0 and p3_end > 0 else text[p2_end:]
p4 = text[p3_end:] if p3_end > 0 and has_p4 else ''

c1, c2, c3, c4 = len(p1), len(p2), len(p3), len(p4)
total = c1 + c2 + c3 + c4
min_total = 21000 if has_p4 else 18000

print(f'Phase 1: {c1:,} chars (min 8,000) {\"✅\" if c1>=8000 else \"❌ 不足\"}')
print(f'Phase 2: {c2:,} chars (min 6,000) {\"✅\" if c2>=6000 else \"❌ 不足\"}')
print(f'Phase 3: {c3:,} chars (min 4,000) {\"✅\" if c3>=4000 else \"❌ 不足\"}')
if has_p4:
    print(f'Phase 4: {c4:,} chars (min 3,000) {\"✅\" if c4>=3000 else \"❌ 不足\"}')
print(f'Total:   {total:,} chars (min {min_total:,}) {\"✅\" if total>=min_total else \"❌ 不足\"}')

if has_p4:
    print(f'Ratio:   {c1/total*100:.0f}/{c2/total*100:.0f}/{c3/total*100:.0f}/{c4/total*100:.0f} (target 35-45/25-35/12-20/10-18)')
else:
    print(f'Ratio:   {c1/total*100:.0f}/{c2/total*100:.0f}/{c3/total*100:.0f} (target 35-50/25-40/15-35)')
"
```

### 12.2 不达标补救机制

```
IF 任一 Phase 低于最低字符数:
  Step 1 — 定位缺口：低于下限的章节是哪些？
  Step 2 — 补充检索：该章节缺少的数据维度是什么？→ 调用对应工具补充
  Step 3 — 扩展内容：基于补充数据扩展对应章节至达标
  Step 4 — 再次自检：重新运行 12.1 自检命令
  Step 5 — 最多 2 轮补救后仍未达标：标注 [字数未达标-已穷尽可用数据]

IF 总字符数 < 10,000（标准模式）:
  → 检查是否遗漏了某个核心分析维度（通常是横向对标或交叉验证）
  → 补充后重新自检
```

### 12.3 校准案例

晶能光电 2026-07-06 三阶段完整报告作为字数基准（实际运行产出）：

| 阶段 | 实际字数 | 章节数 | 占比 | 质量特征 |
|------|:------:|:------:|:------:|---------|
| 纵向（Phase 1）| 8,344 | 6 章 | 39% | 公司沿革 1,619 / 业务 1,628 / 财务 1,702 / 法律 914 / 融资 781 |
| 横向（Phase 2）| 6,415 | 4 章 | 30% | 6 维度竞品对标完整 / 4 家上市公司财务对比 / 估值横向校验 |
| 交叉（Phase 3）| 6,633 | 4 章 | 31% | T1 4/4 双源通过 / 矛盾标注 8 处 / 缺口清单 5 项 |
| **总计** | **21,392** | 14 章 | 100% | 独立数据源 6 个 / SearXNG 0 次 / 源标注 38 种格式 |

**关键校准结论**：
- 强章（1,600+ 字）与轻章（300+ 字）共存是正常现象 — 取决于该维度的数据可得性
- 总字数 ≥18,000 是硬线，逐章最低字数是**引导线**（强章可补偿轻章）
- 源标注密度和格式丰富度是质量的代理指标 — 38 种标注格式 = 多源交叉验证到位
- **新报告不应显著低于此基准的总字数**（±20% = 17,100-25,670 可接受范围）

---

## 附录A：脚本速查

| 脚本 | 用途 | 调用方式 |
|------|------|---------|
| `scripts/hv_academic_gemini.py` | 学术研究模式主驱动 | `python3 hv_academic_gemini.py` |
| `scripts/hv_challenge_b_v3.py` | Challenge B 防幻觉核查 | `python3 hv_challenge_b_v3.py --input report.md` |
| `scripts/render_challenge_b_v3.py` | Challenge B 结果可视化 | `python3 render_challenge_b_v3.py result.json out.html` |
| `scripts/hv_render_wrapper.py` | .md → .html 渲染 | `python3 hv_render_wrapper.py report.md` |
| `scripts/hv-render.sh` | 一键渲染入口 | `bash hv-render.sh` |

## 附录B：查询模板速查

### 商业尽调常用

| 数据需求 | 首选工具 | 查询模板 |
|---------|---------|---------|
| 公司最新动态 | iFind News | `"{公司名} 技术 产品 市场 合作"` |
| 公司深度分析 | MX Search | `"{公司名} 业务 客户 竞争 增长"` |
| 行业规模/增速 | MX Data D4 | `"{行业名} 市场规模 增速 竞争格局"` |
| 竞品对标 | MX Data D7 | `"{竞品1} {竞品2} 对比 营收 净利 估值"` |
| 产业链分析 | iFind Chain ★ | `"分析{行业名}产业链"` (submit→poll) |

### 财务尽调常用

| 数据需求 | 首选工具 | 查询模板 |
|---------|---------|---------|
| 上市公司财务 | iFind Finance | `"{股票名} 营收 净利 ROE 毛利率 负债"` |
| 非上市公司财务 | MX Data D1 | `"{公司名} 营收 净利 融资 估值"` |
| 行业财务基准 | MX Data D4 | `"{行业名} 平均毛利率 净利率 ROE"` |
| 深度投研 | iFind Investment ★ | `"分析{公司名}"` (submit→poll) |

### 法律尽调常用

| 数据需求 | 首选工具 | 查询模板 |
|---------|---------|---------|
| 诉讼/处罚 | MX Data D5 | `"{公司名} 诉讼 处罚 异常"` |
| 公告/监管 | iFind Announcement | `"{公司名} 审计 关联交易 担保"` |
| 实控人关联方 | 天眼查(通过MX代理) | `"{实控人名} {公司名} 对外投资 关联"` |

---

## 十三、图表生成模块 V3.46.0（2026-07-09 固化）

> **触发**：每次 HV Analysis 报告必须嵌入 ≥ 5 张图表。
> **铁律**："无图不成报告"——V1 报告（汇天 2026-07-08）有 0 张图被主公批评。

### A. 图表生成器（hv_charts.py）

**位置**：`scripts/charts/hv_charts.py`（23,531 bytes，V3.46.0）

**8 种内置图表类型**：

| 编号 | 函数 | 用途 | 典型场景 |
|---|---|---|---|
| 1 | `chart_financial_timeline(years, revenue, net_profit, ...)` | 营收/净利双柱时序 | 公司财务时序（5-7 年）|
| 2 | `chart_horizontal_bar(labels, values, ...)` | 横向柱状 | 同业对标排名（PB/PE/ROE）|
| 3 | `chart_radar_compare(categories, series, ...)` | 多维度雷达 | 6 维能力对标 |
| 4 | `chart_pie_structure(labels, sizes, ...)` | 饼图 | 业务/物业/股权结构 |
| 5 | `chart_scenario_irr(scenarios, irr_values, ...)` | 场景柱状 | IRR/估值三情景 |
| 6 | `chart_line_trend(x_data, y_series, ...)` | 折线趋势 | 上电率/单价/出租率 |
| 7 | `chart_kpi_dashboard(kpi_data, ...)` | KPI 仪表盘 | 4-6 个核心数字横排 |
| 8 | `chart_stacked_bar(x_data, y_series, ...)` | 堆叠柱状 | 多年/多家业务结构对比 |

### B. 双版本（浅+暗）

所有图表同时输出：
- `{name}_light.svg`（浅色版，body=#ffffff）
- `{name}_dark.svg`（暗色版，body=#1a202c）

通过 `save_dual(fig_func, name, out_dir)` 一次性保存两个版本。

### C. 嵌入 MD 报告（base64）

**脚本**：`scripts/charts/embed_charts_into_md.py`（2,657 bytes）

**工作流**：
1. 报告 MD 中用占位符 `{{CHART1_LIGHT}}` `{{CHART1_DARK}}` 标记
2. 调 `make_huitian_charts.py` 生成 SVG + manifest.json
3. 调 `embed_charts_into_md.py` 替换占位符为 base64
4. 渲染 HTML 时 base64 直接显示，无需外部资源

### D. 调用示例（汇天 IDC V2）

```python
# scripts/charts/make_huitian_charts.py（V3.46.0 实战版）
from hv_charts import chart_financial_timeline, save_dual

def _fig1(dark_mode):
    return chart_financial_timeline(
        years=[2021, 2022, 2023, 2024, 2025],
        revenue=[0, 0, 0.2942, 0.1672, 0.7843],  # 亿元
        net_profit=[0, 0, -0.0156, 0.0102, 0.0467],
        title="汇天网络 2021-2025 营收/归母净利时序（亿元）",
        dark_mode=dark_mode,
    )

light_b64, dark_b64 = save_dual(_fig1, "chart1_huitian_finance", out_dir)
```

### E. 字体与字号（V3.42.9+ 标准）

- 字体：`/System/Library/Fonts/STHeiti Medium.ttc`（macOS 系统字体）
- 字号：title 22 / axis_label 16 / tick 14 / bar_value 13

### F. V3.46.0 核心规则

1. **每报告 ≥ 5 张图**（少则退回重做）
2. **数据双源验证**：iFind + Tavily / 港交所公告（避免 V1 错误）
3. **必须含 KPI 仪表盘**（4-6 个核心数字横排）
4. **必须含同业对标**（PB/PE/ROE 横向 + 6 维雷达）
5. **必须含 IRR 三情景**（如有估值/回报测算）
6. **base64 嵌入 MD**：单文件可移植（V3.42.2+ 标准）
7. **深色模式自动适配**：chart-light/chart-dark + CSS media query

### G. 关联文件

- `scripts/charts/hv_charts.py`（8 种图表，23KB）
- `scripts/charts/make_huitian_charts.py`（汇天 IDC 实战，10KB）
- `scripts/charts/embed_charts_into_md.py`（base64 嵌入，3KB）
- `~/.openclaw/workspace-research/projects/汇天网络科技/charts/`（16 SVG + manifest.json）
- `~/.openclaw/workspace-research/memory/2026-07-09.md`（V1→V2 修复记录）


---

## §十四 V3.49 数据权威性核查机制（2026-07-16 主公固化）

### 14.1 背景与动机

**问题**：2026-07-16 主公反馈已脱敏研究未调用 iFind Finance / MX 等专业金融数据源，仅用了 tavily（C 级通用搜索）。

**根因**：
1. `web_search` 失败时直接降级到 tavily，跳过 A/B 级
2. AGENTS.md 写了"iFind / MX 优先"但未内嵌到判断链路
3. 报告数据源以 B 级（财经媒体）为主，未达 A 级标准

### 14.2 三脚本工具链

| 脚本 | 路径 | 字节 | 功能 |
|:-----|:-----|-----:|:-----|
| `hv-data-auth-check.py` | `skills/hv-analysis/scripts/` | ~9.6K | Phase 0 自动检测 iFind / MX / AKShare / Tushare 可用性 |
| `hv-data-quality-class.py` | `skills/hv-analysis/scripts/` | ~6.8K | 数据源分级（A/B/C）+ 报告审计 + 自动重新核实 |
| `hv-audit-data-quality.py` | `skills/hv-analysis/scripts/` | ~6.8K | 项目目录报告批量审计 + 严格模式门禁 |

### 14.3 三阶段强制规则

#### Phase 0：必须先检测数据源可用性

```bash
python3 hv-data-auth-check.py
# 输出 iFind-repilot 系列 token 状态 + MX / AKShare / Tushare 可用性
# 任一 iFind Finance / News 不可用 → 必须修复 token 才能进入 Phase 1
```

#### Phase 1-2：数据采集必须按降级顺序

```
A 级（专业金融）：iFind Finance / MX Data / 港交所公告
   ↓ 失败降级
B 级（财经媒体）：财联社 / 证券时报 / 界面 / 雪球
   ↓ 失败降级
C 级（通用搜索）：tavily / web_search（**最后兜底**）
```

**绝对禁止**：跳过 A/B 直接走 C。

#### Phase 3 报告交付前：必须审计

```bash
# 单报告审计
python3 hv-audit-data-quality.py --report <report.md>

# 项目目录批量审计
python3 hv-audit-data-quality.py --project <project_dir>

# 严格模式（A 级 < 30% 阻止交付）
python3 hv-audit-data-quality.py --project <project_dir> --strict
```

### 14.4 数据源引用标识规范

报告正文中的每个数据点必须有引用标识，格式：

| 格式 | 示例 | 级别 |
|:-----|:-----|:----:|
| `[A-iFind-Finance: xxx]` | `[A-iFind-Finance: 20251231 实测 4.6671 亿]` | A |
| `[A-iFind-News: xxx]` | `[A-iFind-News: 证券之星 2026-04-15 收盘]` | A |
| `[A-iFind-Announcement: xxx]` | `[A-iFind-Announcement: 2025-12-26 公告]` | A |
| `[B-财联社: xxx]` | `[B-财联社: 钙钛矿报道]` | B |
| `[C-tavily: xxx]` | `[C-tavily: 搜索关键词]` | C（应避免）|

### 14.5 审计判定规则

| 规则 | 阈值 | 触发动作 |
|:-----|:----:|:--------|
| A 级占比 < 30% | 🔴 P0 | 必须补充 iFind Finance / 公告核实 |
| C 级占比 > 20% | ⚠️ 警告 | 建议替换为 iFind Finance / 公告原文 |
| B 级占比 > 60% | ⚠️ 警告 | 建议二次核实（用 iFind 验证关键数字）|

**已脱敏报告实测**：A 级 47.4%（9/19）/ B 级 5.3%（1/19）/ C 级 0% → ✅ 通过。

### 14.6 自动化门禁（推荐集成到 hv-auto-research.py）

```python
# 在 Phase 3 报告生成后强制调用
from hv_audit_data_quality import audit_project

audit = audit_project(project_dir)
if not audit["overall_passed"]:
    raise RuntimeError(f"🔴 数据源质量门禁未通过：{audit['failed_count']} 个报告 A 级 < 30%")
```

### 14.7 Lessons 沉淀

| Lesson | 内容 |
|:-------|:-----|
| Lesson 52 | iFind Finance / News / Announcement / Investment / Chain 共 5 个技能 token 已验证可用 |
| Lesson 53 | MX 服务真实在线（http://localhost:8080/health），不需要重装 |
| Lesson 54 | A 级数据源检测必须内置到 Phase 0（hv-data-auth-check.py），不能"看到 web_search 失败就降级到 tavily" |
| Lesson 55 | 报告数据源必须分级（A/B/C），报告交付前自动审计 A 级占比 ≥30% |
| Lesson 56 | Python 函数接受参数的格式必须与上游调用一致（[xxx] vs xxx）——Lesson 20 延伸 |


---

## §十五 数据采集优先级规则（Agent 自主判断 / 非代码实现，2026-07-16 主公固化）

### 15.1 规则制定背景

**问题**：Agent 在数据采集阶段倾向于"最熟悉的路径"（tavily / web_search），跳过 iFind Finance / MX 等专业金融数据源——导致报告数据源以 B/C 级为主，未达 A 级标准。

**核心矛盾**：自动化代码强制调用 = 侵入技能本身（违反"Agent 自适应闭环"原则）；完全不强制 = Agent 重蹈覆辙。

**解决方案**：用**规则引导 Agent 自主判断**，不写自动调用代码。

### 15.2 数据采集优先级规则（7 条强制规则）

> **规则 1 — Phase 0 启动检查**：每次接收到研究任务后，**第一步必须先调用 `hv-data-auth-check.py`**（仅 1 次，10 秒内完成）。**当且仅当** iFind Finance / iFind News / iFind Announcement 中**有任何一个可用**时，Phase 1-2 才允许使用 B/C 级数据源；**若全部不可用**才允许直接走 tavily 兜底。

> **规则 2 — 数据源降级顺序**：Phase 1-2 数据采集必须按以下顺序逐级尝试，**任何上一级成功的情况都禁止跳到下一级**：
> ① **A 级**（专业金融）：iFind Finance / iFind News / iFind Announcement / iFind Investment / iFind Chain、MX Data、港交所公告、巨潮资讯
> ② **B 级**（财经媒体）：财联社、证券时报、界面新闻、同花顺、雪球、东方财富
> ③ **C 级**（通用搜索）：tavily / web_search / 百度（**最后兜底**，且必须标注 `[C-tavily: 关键词]`）

> **规则 3 — 数据点必须有引用标识**：报告正文中每个数据点必须标注数据源级别，格式如下：
> - `[A-iFind-Finance: 20251231 实测 4.6671 亿]` ✅ A 级推荐
> - `[A-iFind-News: 证券之星 2026-04-15 收盘]` ✅ A 级推荐
> - `[A-iFind-Announcement: 2025-12-26 公告]` ✅ A 级推荐
> - `[B-财联社: 钙钛矿报道]` ⚠️ B 级需二次核实
> - `[C-tavily: 关键词]` ❌ C 级应避免

> **规则 4 — 单条数据查询优先 iFind**：当 Agent 需要查询"某公司某年的财务数据 / 公告 / 新闻"时，**优先使用 iFind 自然语言查询**（如 `已脱敏 2025 年报 营收`），**而非**用 tavily 搜索"已脱敏 2025 年报"。如果 iFind 返回空或失败，**才降级**到财经媒体或 tavily。

> **规则 5 — 报告交付前自动审计**：Phase 3 报告生成后，**必须调用 `hv-audit-data-quality.py --project <项目目录>`** 审计数据源质量。判定规则：
> - A 级占比 < 30% → 🔴 P0 必须补充 iFind 核实，禁止交付
> - C 级占比 > 20% → ⚠️ 警告，建议替换为 iFind / 公告
> - B 级占比 > 60% → ⚠️ 警告，建议二次核实

> **规则 6 — 已脱敏失误案例警示**：2026-07-16 已脱敏研究失误案例（5 次 tavily_search + 0 次 iFind）已固化到 MEMORY.md Lesson 53。Agent 在 Phase 1 启动时应**主动回顾 Lesson 53**，避免重蹈覆辙。

> **规则 7 — C 级使用触发自动重新核实**：当 Agent 不慎使用 C 级通用搜索时，**必须立即**调 `hv-data-quality-class.py --auto-reverify --topic "<主题>"` 触发自动重新核实流程，用 iFind Finance 重新核实关键数据。

### 15.3 Agent 自主判断检查清单（Phase 1 启动时必读）

```
□ 我已经调用了 hv-data-auth-check.py 吗？
    → 是 → iFind 是否可用？
        → 是 → 进入下一步（规则 2-5）
        → 否 → 立即修复 token，再次调用直到 iFind 可用
    → 否 → 立即调用，不能跳过

□ 我接下来要查询的数据属于哪个类别？
    → 财务数据 → 必须用 iFind Finance（自然语言）
    → 公司新闻 → 必须用 iFind News（语义检索）
    → 公告文件 → 必须用 iFind Announcement（向量检索）
    → 行业研究 → 必须用 iFind Chain 或 iFind Investment
    → 投资价值 → 必须用 iFind Company Investment Research

□ 我准备的查询语句是 iFind 自然语言格式吗？
    → "已脱敏 2025 年报 营收" ✅
    → "已脱敏 营收 2025" ✅
    → "300585 annual report 2025" ✅
    → "site:cninfo.com.cn 已脱敏 公告" ❌（这是 tavily/web 搜索格式）

□ 我现在是否正准备调用 tavily_search？
    → 是 → 我已经尝试过 iFind Finance / News / Announcement 了吗？
        → 否 → 立即停止，先尝试 iFind
        → 是 → iFind 是否返回了有效数据？
            → 是 → 用 iFind 的数据，不要调用 tavily
            → 否 → 才允许降级到 tavily，并标注 [C-tavily: 关键词]
```

### 15.4 Agent 自适应闭环（Phase 1-2 数据采集流程）

```
Step 1：调用 hv-data-auth-check.py（确认数据源状态）
  ↓ iFind Finance / News / Announcement 任一可用
Step 2：用 iFind 自然语言查询关键数据
  ↓ iFind 返回有效数据
Step 3：标注引用标识 [A-iFind-xxx: ...]
  ↓ 数据采集完成
Step 4：报告生成 + 标注 A 级引用标识
  ↓ 报告生成完成
Step 5：调用 hv-audit-data-quality.py 审计
  ↓ A 级 < 30%
Step 6：自动重新核实（hv-data-quality-class.py --auto-reverify）
  ↓ 重新核实补充 A 级数据
Step 7：交付报告
```

**关键约束**：
- Step 2 **不是"可选尝试"**，是**强制步骤**
- Step 5-6 **失败则禁止交付**
- 整个流程**不允许跳过任何 Step**

### 15.5 规则 vs 代码的边界（主公核心要求）

**规则形式**（✅ 本节采用）：用文字描述强制规则，让 Agent 自主判断
- 优点：保留 Agent 自适应闭环 + 灵活应对新场景
- 适用：数据采集优先级、报告标注规范、降级顺序

**代码形式**（❌ 本节不采用）：在 hv-auto-research.py 中自动调用 hv-data-auth-check.py
- 缺点：侵入技能本身 + 破坏 Agent 自适应闭环 + 难以应对新场景
- 适用：仅用于报告交付前的硬门禁（如 --strict 模式 exit 1）

**判断原则**：
- **规则** 引导 Agent "应该怎么做"
- **代码** 仅用于 "硬性阻止不符合规则的产物"

### 15.6 已脱敏案例复盘（Agent 应主动避免）

**触发条件**：Agent 在 Phase 1 没有先调用 hv-data-auth-check.py
**错误路径**：
1. ❌ 直接调用 tavily_search（跳过 iFind 检测）
2. ❌ web_search 失败后降级到 tavily（跳过 A 级）
3. ❌ 报告数据点未标注 [A-iFind-xxx] 标识
4. ❌ 报告交付前未调用 hv-audit-data-quality.py

**正确路径**：
1. ✅ Phase 0 先调用 hv-data-auth-check.py（确认 iFind 5/5 可用）
2. ✅ Phase 1 用 iFind Finance 查询财务数据（"已脱敏 2025 年报 营收"）
3. ✅ Phase 1 用 iFind News 查询舆情（"已脱敏 钙钛矿"）
4. ✅ Phase 1 用 iFind Announcement 查询公告（"已脱敏 控股股东"）
5. ✅ 报告每个数据点标注 [A-iFind-Finance: 实测数据] / [A-iFind-News: 来源] 等
6. ✅ Phase 3 报告交付前调用 hv-audit-data-quality.py --strict

### 15.7 规则自检触发点（Agent 应内嵌到判断链路）

> **IF**（Phase 1 数据采集准备调用工具）
> **THEN**（先问 3 个问题）：
> 1. 我是否已经调过 hv-data-auth-check.py 确认 iFind 可用？
> 2. 我现在准备的查询是否能用 iFind 自然语言表达？
> 3. 我准备调用的工具是 iFind 还是 tavily？（如果不是 iFind，回退到 Step 2）
> **AND**（任一问题答 No，先调 iFind，再考虑 B/C 级）


---

## §十六 Agent 失效模式库 + 跨任务复用案例（2026-07-16 主公固化）

### 16.1 失效模式 F1 — "路径依赖陷阱"

> **症状**：Agent 默认走 tavily → 跳过 A 级 → 数据质量全面降级
> **触发条件**：
> - Agent 启动时直接调用 `web_search` 或 `tavily_search`，未先调用 `hv-data-auth-check.py`
> - Agent 只记得"有 tavily 可用"，不记得 iFind Finance 才是首选
> **反面教材**：已脱敏研究（2026-07-16）—— 5 次 tavily_search + 0 次 iFind 调用
> **自检触发点**：
>
> ```
> IF（Phase 1 准备调用 search 工具）
> THEN（先问）：我是否已经确认 iFind Finance / News 状态？
>   → YES → 用 iFind 自然语言查询
>   → NO → 立即调用 hv-data-auth-check.py，禁止先调用 tavily
> ```

### 16.2 失效模式 F2 — "格式不对齐陷阱"

> **症状**：iFind 自然语言查询写得像 web 搜索，导致 iFind 返空
> **触发条件**：
> - Agent 写的是 `"site:cninfo.com.cn 已脱敏 公告"` → 这是 web 搜索语法，iFind 不识别
> - Agent 写的是 `"已脱敏 300585 营收"` → 这是 A 股股票代码混用，iFind 解析失败
> **正确格式**：
> - ✅ `"已脱敏 2025 年报 营收"`（自然语言）
> - ✅ `"已脱敏 2025 年净利润 同比"`（自然语言 + 同比）
> - ✅ `"已脱敏 控股股东 减持"`（自然语言 + 事件）
> **自检触发点**：
>
> ```
> IF（写 iFind 查询语句）
> THEN（先问）：这是 web 搜索语法还是自然语言？
>   → web 搜索语法 → 改写为自然语言
>   → 自然语言 → 用 iFind Finance
> ```

### 16.3 失效模式 F3 — "降级跳级陷阱"

> **症状**：iFind 失败 → 直接跳到 tavily，跳过 B 级（财联社 / 证券时报）
> **触发条件**：
> - iFind Finance 失败 → Agent 跳过财联社 / 雪球，直接用 tavily
> - iFind News 没找到"已脱敏 钙钛矿" → Agent 直接用 web 搜索
> **正确降级顺序**：
> 1. A1：iFind Finance（财务）
> 2. A2：iFind News（舆情）
> 3. A3：iFind Announcement（公告）
> 4. B1：财联社 + 雪球（财经媒体）
> 5. B2：同花顺 / 东方财富（财经数据）
> 6. C1：tavily / web_search（兜底）
> **自检触发点**：
>
> ```
> IF（A 级失败准备降级）
> THEN（先问）：我已经尝试过 B 级财经媒体了吗？
>   → YES → 才允许降到 C 级
>   → NO → 必须先调 B 级（财联社 / 雪球）
> ```

### 16.4 失效模式 F4 — "幻觉填充陷阱"

> **症状**：iFind 没数据 → Agent 用"经验"或"常识"填充 → 编造数字
> **触发条件**：
> - iFind 搜索"已脱敏 钙钛矿产能"返回空 → Agent 编造"2GW"
> - iFind 搜索"已脱敏 控股股东 减持比例"返回空 → Agent 编造"3.5%"
> **正确做法**：
> - iFind 无数据 → 标注 `[本地: 数据库无该数据]` 或 `[A-iFind: 暂无记录]`
> - **绝对禁止**用经验填充，必须标注"待核实"
> **自检触发点**：
>
> ```
> IF（iFind 返空或失败）
> THEN（先问）：我是否准备用经验/常识填充？
>   → YES → 立即停止，标注"待核实 [C-待核实: 字段]" 或查找二手来源
>   → NO → 可标注"暂无数据"
> ```

### 16.5 失效模式 F5 — "报告标注遗漏陷阱"

> **症状**：Agent 调了 iFind 但报告里没标注 `[A-iFind-xxx]` 标识 → 审计脚本不识别为 A 级
> **触发条件**：
> - iFind Finance 返回"已脱敏 2025 营收 4.6671 亿" → Agent 在报告只写"4.6671 亿"未标 `[A-iFind-Finance]`
> - iFind News 返回"证券之星 收盘价 X" → Agent 在报告只写"X 元"未标 `[A-iFind-News]`
> **正确做法**：
> - 每个数据点必须有级别前缀：`[A-iFind-Finance: 20251231 实测 4.6671 亿]`
> - 即使是 iFind 自身的数据也要标（不标 = 审计脚本识别为 Unknown）
> **自检触发点**：
>
> ```
> IF（写报告时引用数据点）
> THEN（必填字段）：级别前缀 (A/B/C) + 数据源名 (iFind/财联社/tavily) + 类型 (Finance/News/Announcement) + 内容
>   → 格式：`[A-iFind-Finance: 20251231 实测 4.6671 亿]`
>   → 错误：`4.6671 亿`（无标注）
> ```

### 16.6 失效模式 F6 — "审计脚本未调用陷阱"

> **症状**：报告生成后直接发给主公，没调 `hv-audit-data-quality.py` 审计
> **触发条件**：
> - Agent 在 Phase 3 生成报告后跳过审计步骤
> - Agent 觉得"报告看起来不错，不用审计"
> **正确做法**：
> - Phase 3 报告交付前**必须**调 `hv-audit-data-quality.py --project <目录>`
> - **必须**用 `--strict` 模式（A 级 < 30% 阻止交付）
> **自检触发点**：
>
> ```
> IF（准备交付报告）
> THEN（先问）：我已经调过 hv-audit-data-quality.py 了吗？
>   → YES → 审计通过吗？
>       → YES → 交付
>       → NO → 重新核实补充 A 级
>   → NO → 立即调用，禁止不审计就交付
> ```

### 16.7 跨任务复用：4 个研究项目的应用模板

> **场景 1 — 上市公司财务研究**（如已脱敏、天保能源）
>
> ```
> Phase 0：hv-data-auth-check.py（确认 iFind Finance / News / Announcement 可用）
> Phase 1：iFind Finance 查询 5 年财务数据 → 标 [A-iFind-Finance]
> Phase 1：iFind Announcement 查询 12 个月内公告 → 标 [A-iFind-Announcement]
> Phase 1：iFind News 查询近期舆情 → 标 [A-iFind-News]
> Phase 2：横向对标用 iFind Finance 查询同行业可比公司 → 标 [A-iFind-Finance]
> Phase 3：报告交付前 hv-audit-data-quality.py --strict
> ```

> **场景 2 — 非上市公司早期评估**（新增储备项目）
>
> ```
> Phase 0：hv-data-auth-check.py（确认 iFind Finance 不可用是常态）
> Phase 1：iFind News 查询"公司名 + 行业"→ 标 [A-iFind-News]
> Phase 1：iFind Investment 综合投研（如可用）→ 标 [A-iFind-Investment]
> Phase 1：天眼查 / 启信宝（备选）→ 标 [B-天眼查] 或 [B-启信宝]
> Phase 1：新闻 + 行业研究补 → 标 [B-财联社] / [B-雪球]
> Phase 2：行业研究用 iFind Chain → 标 [A-iFind-Chain]
> Phase 3：hv-audit-data-quality.py（注意：A 级可能不足 30%，需补充 iFind News）
> ```

> **场景 3 — 并购尽调**（如汇天 IDC V4）
>
> ```
> Phase 0：hv-data-auth-check.py（必须确认全 A 级可用）
> Phase 1：标的方财务 → iFind Finance → 标 [A-iFind-Finance]
> Phase 1：标的方公告 → iFind Announcement → 标 [A-iFind-Announcement]
> Phase 1：标的方舆情 → iFind News → 标 [A-iFind-News]
> Phase 1：港股标的 → 港交所原文 PDF → 标 [A-港交所]
> Phase 2：可比公司 → iFind Finance → 标 [A-iFind-Finance]
> Phase 2：关联交易 / 限消令 → iFind Announcement + 巨潮 → 标 [A-iFind-Announcement]
> Phase 3：hv-audit-data-quality.py --strict
> ```

> **场景 4 — 行业研究 / 产业链**
>
> ```
> Phase 0：hv-data-auth-check.py（确认 iFind Chain / Investment 可用）
> Phase 1：产业链结构 → iFind Chain → 标 [A-iFind-Chain]
> Phase 1：行业头部公司 → iFind Finance（按行业筛选）→ 标 [A-iFind-Finance]
> Phase 1：行业政策 → iFind News → 标 [A-iFind-News]
> Phase 2：行业整合度 / CR5 → iFind Investment → 标 [A-iFind-Investment]
> Phase 3：hv-audit-data-quality.py
> ```

### 16.8 Agent 反向检查 5 问（每次 Phase 1 数据采集前必答）

```
1. 我现在是不是直接调 tavily_search？
   → 是：立即停止，改为 iFind Finance 自然语言查询

2. 我准备的 iFind 查询语句是自然语言吗？
   → 否：立即改写为自然语言，不用 web 搜索语法

3. 我跳过了哪个 A 级数据源？
   → 跳过 iFind Finance / News / Announcement / Investment / Chain 任一个 → 必须先调该 A 级

4. 我准备用经验/常识填充数据吗？
   → 是：立即停止，标注"待核实"或查询二手来源

5. 我报告里的数据点都加了 [A-iFind-xxx] 标识吗？
   → 否：补充标注，否则审计脚本识别为 Unknown
```

---

## §X 可选前置模块：storm-research（2026-07-18 主公固化）

**作用**：STORM 5 角色多视角扫描（Stanford OVAL NAACL 2024 方法论）。非侵入式前置增强。

### 触发条件（双重 OR 关系，任一命中即触发）

#### 条件 A：任务维度（4 问自检）
- Q1 研究对象是否涉及多视角可能冲突的领域？
- Q2 任务复杂度是否 ≥ 中等？（决策模式 / 并购尽调 / 25 章 / SOTP）
- Q3 是否存在主流共识可能掩盖非主流视角？
- Q4 是否需要批判性分析（不只是事实汇总）？

**触发规则**：≥3 问"是" → ✅ 强制触发 / 2 问 → ⚠️ 推荐触发 / ≤1 问 → ❌ 不触发

#### 条件 B：用户怀疑信号（U1-U5）
- U1 怀疑关键词（怀疑/担心/风险/估值高/不可信）
- U2 反方视角要求（怀疑者视角/角色扮演）
- U3 同行评审要求（自评/弱点在哪）
- U4 决策语气强烈（重大决策/大额/国资委）
- U5 历史踩雷（上次/我担心/误判）

**触发规则**：U1 ≥3 个 OR U2/U3 直接要求 → 🔴 强烈触发 / U4/U5 → ⚠️ 推荐触发

### 综合判定

```
总分 = max(任务维度 X/4, 用户怀疑 X/5)
- ≥3 → ✅ 强制触发 STORM（~3,800 token）
- =2 → ⚠️ 推荐触发 STORM（~2,800 token）
- ≤1 → ❌ 不触发
```

### 调用时机

hv-analysis **Phase 0 完成后** → Phase 1 启动前的"间隔窗"。

### 输出物与接入点

| STORM 输出 | 接入到 hv-analysis |
|-----------|------------------|
| 5 角色立场（卖方/买方/PE/产业/媒体）| Phase 1 §1-2（角色补强）|
| 矛盾图 | Phase 3 §14（视角矛盾）|
| 综合简报 | Phase 4 §25（决策建议）|
| 同行评审（5 维度 + 弱环）| §十二 自检（质性补充）|

### 不修改项（核心约束）

- hv-analysis 主流程 Phase 0-4
- 现有脚本（hv-data-auth-check.py / hv-auto-research.py / hv-data-quality-class.py / hv-audit-data-quality.py / hv_charts.py）
- §十二 自检规则（STORM 是补充，不是替代）
- 任何现有章节一字不动

### 详细参考

- **STORM Skill 文档**：`~/.openclaw/workspace-research/skills/storm-research/SKILL.md`
- **自动调用规则**：`~/.openclaw/workspace-research/AGENTS.md` §"storm-research 自动调用规则"
- **触发设计**：`~/.openclaw/workspace-research/temp/storm_auto_trigger_design.md`
- **测试案例**：`~/Documents/OpenClaw-Workspace-research/projects/宏远创信/storm_test/STORM_5角色重跑测试报告_20260718.md`

### 关联 Skill 接入点

- academic-deep-research-pro / khazix-writer / report-html-publish（详见 storm-research SKILL.md §"5 角色定制表"）

