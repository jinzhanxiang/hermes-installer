#!/usr/bin/env bash
# hv-start.sh - 纵横分析法（hv-analysis V3.46.0）一键入口
# 用法：
#   ./hv-start.sh <project> [--mode decision|analysis] [--render-html] [--push-deploy]
# 例：
#   ./hv-start.sh 汇天网络科技 --render-html --push-deploy
set -e

PROJECT="${1:-}"
shift || true

if [ -z "$PROJECT" ]; then
    echo "❌ 用法: $0 <project_name> [--render-html] [--push-deploy]"
    echo ""
    echo "示例:"
    echo "  $0 汇天网络科技 --render-html --push-deploy"
    echo "  $0 启源芯动力 --mode analysis"
    exit 1
fi

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PYTHON="${PYTHON:-/usr/bin/python3}"

echo "============================================================"
echo "  hv-analysis V3.46.0 - 纵横分析法一键入口"
echo "  项目: $PROJECT"
echo "  时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "============================================================"

# 走主入口脚本
exec "$PYTHON" "$SCRIPT_DIR/scripts/hv-auto-research.py" "$PROJECT" "$@"
