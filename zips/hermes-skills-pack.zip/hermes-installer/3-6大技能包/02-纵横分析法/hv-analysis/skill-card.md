## Description: <br>
HV Analysis 横纵分析法 guides agents through web-based horizontal and vertical research on a product, company, concept, technology, or person and produces a structured research report. <br>

**【5-Layer Fusion · V3.43.0】** HV-Analysis now runs on Gemini Deep Research Agent + Academic Deep Research Pro + arXiv API + 6-dimension benchmarking template + word-count recipe (10-30K chars standard mode). Methodology rooted in Saussure (Diachronic/Synchronic) + Cook & Campbell (Longitudinal/Cross-sectional) + Yin (Case Study) + Porter (Five Forces). Produces academic-grade narrative PDF reports + business due diligence HTML. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[kkkkhazix](https://clawhub.ai/user/kkkkhazix) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and researchers use this skill to build deep longitudinal and cross-sectional reports about products, companies, concepts, technologies, or people. The agent gathers current web evidence, compares alternatives, develops timeline-based analysis, and prepares the findings for Markdown or PDF report output. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Research targets, motivations, and focus areas may be shared with online search providers or tool contexts during report generation. <br>
Mitigation: Avoid entering sensitive research intent unless the connected tools and data-handling settings are appropriate for that information. <br>
Risk: External repository files or PDF conversion scripts associated with the full workflow may execute local code if used. <br>
Mitigation: Inspect external files and conversion scripts before running them, and run PDF generation only in a trusted environment. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/kkkkhazix/hv-analysis) <br>
- [Full skill reference from artifact](https://github.com/KKKKhazix/khazix-skills) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, guidance] <br>
**Output Format:** [Structured Markdown research report with optional PDF output] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May use web search and optional PDF conversion for long-form reports.] <br>

## Skill Version(s): <br>
1.43.0 (V3.43.0 - 2026-07-04 - Methodology four-source fusion + 6-dim benchmark template + word-count recipe + arXiv API) <br>
Previous: 1.0.0 (V3.42.5) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
