#!/usr/bin/env python3
"""
hv_fusion_trigger.py - Hermes 并行融合自动派单/轮询钩子（V3.48.0+）

V3.48.0 整改（2026-07-12）：
  - 把"SKILL.md §3.1-bis 必触发 Hermes 融合"从文本规则固化为自动脚本钩子
  - 不依赖 LLM 主动遵守规则，每次报告自动触发 Hermes 独立研究
  - 防止"未追溯半成品任务"的 V1 教训再次发生

核心协议（双轨制）：
  - A 径：文件系统握手 out/{task_id}.task.json
  - B 径：hermes kanban create + assign default + claim --ttl 1800

硬约束（来自主公 2026-07-12 指示）：
  - ⚠️ 不得重启 hermes 网关
  - ⚠️ 不得启动 hermes kanban daemon（已 deprecation）
  - ✅ 仅通过 hermes kanban DB 操作 + 文件系统握手触发

典型工作流（4 阶段）：
  1. trigger：派单（写 task.json + kanban create/assign/claim）
  2. poll：轮询 incoming/{task_id}.report.md（30 分钟 timeout）
  3. read：返回报告内容供 LLM 融合
  4. log：写入 fusion.log

CLI 用法：
  # 派单（必填：项目名 + 公司全称）
  python3 hv_fusion_trigger.py trigger \\
      --project 汇天网络科技 \\
      --target "汇天网络科技有限公司" \\
      --key-questions Q1,Q2,Q3 \\
      --data-sources /path/to/file1,/path/to/file2 \\
      --deadline-minutes 30

  # 轮询 + 读取（30 分钟 timeout）
  python3 hv_fusion_trigger.py poll \\
      --task-id huitian-p3-001 \\
      --timeout-minutes 30

  # 一次性：派单 + 阻塞等待 + 打印报告路径
  python3 hv_fusion_trigger.py dispatch \\
      --project 汇天网络科技 \\
      --target "汇天网络科技有限公司" \\
      --deadline-minutes 30

  # 检查是否已有 in-flight 任务（防止重复派单）
  python3 hv_fusion_trigger.py check --project 汇天网络科技

  # 列出今日所有 Hermes 任务
  python3 hv_fusion_trigger.py list
"""
import sys
import os
import json
import time
import argparse
import subprocess
from pathlib import Path
from datetime import datetime, timezone, timedelta

# ===== 常量 =====
HANDSHAKE_DIR = Path.home() / ".openclaw/shared/handoffs"
OUTGOING_DIR = HANDSHAKE_DIR / "outgoing"
INCOMING_DIR = HANDSHAKE_DIR / "incoming"
LOG_DIR = Path.home() / ".openclaw/shared/logs"
LOG_FILE = LOG_DIR / "fusion.log"

CST = timezone(timedelta(hours=8))


def log(msg: str):
    """统一日志输出（带 CST 时间戳，追加到 fusion.log）"""
    ts = datetime.now(CST).strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def ensure_dirs():
    """确保 handoffs 目录存在"""
    OUTGOING_DIR.mkdir(parents=True, exist_ok=True)
    INCOMING_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)


def build_task_json(
    project: str,
    target: str,
    key_questions: list,
    data_sources: list,
    deadline_minutes: int = 30,
    extra: dict = None,
) -> tuple:
    """
    构造 task.json + 返回 task_id 和 .task.json 路径

    Returns:
        (task_id, task_json_path)
    """
    ensure_dirs()
    ts_compact = datetime.now(CST).strftime("%m%d%H%M%S")
    task_id = f"{project}-P3-{ts_compact}"

    task_data = {
        "task_id": task_id,
        "created_at": datetime.now(CST).strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "created_by": "research (OpenClaw)",
        "protocol_version": "V1.1",
        "target": {
            "company_name": target,
            "industry": extra.get("industry", "") if extra else "",
        },
        "data_sources": data_sources,
        "key_questions": key_questions,
        "requested_output": "full_report",
        "fusion_contract": {
            "deadline_minutes": deadline_minutes,
            "must_include": [
                "DCF结果",
                "可比估值",
                "敏感性分析",
                "风险清单",
                "投资建议（评级+目标估值）",
            ],
            "output_format": "natural_language_markdown",
            "report_header_must_contain": [
                "项目名",
                "Hermes 独立研究标识",
                "数据基准日期",
                "假设链摘要",
            ],
            "explicit_dissent_rule": "如与 OpenClaw 估计有分歧（Δ>10%），必须显式标注分歧点",
        },
        "return_path": str(INCOMING_DIR / f"{task_id}.report.md"),
    }

    if extra:
        # 注入额外上下文（如 data_anchors / do_not_do 等）
        if "data_anchors" in extra:
            task_data["data_anchors"] = extra["data_anchors"]
        if "do_not_do" in extra:
            task_data["do_not_do"] = extra["do_not_do"]

    out_path = OUTGOING_DIR / f"{task_id}.task.json"
    out_path.write_text(
        json.dumps(task_data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return task_id, out_path


def cmd_trigger(args) -> int:
    """派单：写 task.json + kanban create/assign/claim"""
    log(f"🟢 触发 Hermes 融合：项目={args.project}, 标的={args.target}")

    # 1. 构造 task.json
    key_questions = args.key_questions.split(",") if args.key_questions else [
        "Q1: 公司定位与护城河",
        "Q2: 财务健康度",
        "Q3: DCF 估值",
        "Q4: 可比公司估值",
        "Q5: 风险 Top 5",
        "Q6: 投资建议",
    ]
    data_sources = args.data_sources.split(",") if args.data_sources else []
    extra = {}
    if args.data_anchors_json:
        try:
            extra["data_anchors"] = json.loads(args.data_anchors_json)
        except json.JSONDecodeError as e:
            log(f"❌ --data-anchors-json 解析失败: {e}")
            return 1

    task_id, task_json_path = build_task_json(
        project=args.project,
        target=args.target,
        key_questions=key_questions,
        data_sources=data_sources,
        deadline_minutes=args.deadline_minutes,
        extra=extra if extra else None,
    )
    log(f"   📝 task.json 已写: {task_json_path} ({task_json_path.stat().st_size} bytes)")
    log(f"   🆔 task_id: {task_id}")

    # 2. A 径：文件系统握手 = task.json 已就位 ✅

    # 3. B 径：kanban create + assign default + claim
    body = (
        f"# Hermes 独立研究任务\n\n"
        f"## 任务标识\n"
        f"- task_id: {task_id}\n"
        f"- 配对文件系统任务: {task_json_path}\n\n"
        f"## 标的\n"
        f"- 公司全称: {args.target}\n\n"
        f"## 核心问题（按顺序回答）\n"
        + "\n".join(f"{i+1}. {q}" for i, q in enumerate(key_questions))
        + "\n\n"
        f"## 数据源\n"
        + ("\n".join(f"- {s}" for s in data_sources) if data_sources else "（无外部文件，按 key_questions 自行研究）")
        + "\n\n"
        f"## 时限\n"
        f"- {args.deadline_minutes} 分钟\n\n"
        f"## 产出\n"
        f"- 自然语言 Markdown 报告\n"
        f"- 路径: {INCOMING_DIR / f'{task_id}.report.md'}\n"
        f"- 完成后无需回复——research 端会轮询\n"
    )

    try:
        log(f"   🚀 执行: hermes kanban create (assignee=default)")
        create_cmd = [
            "hermes", "kanban", "create",
            "--body", body,
            "--assignee", "default",
            "--created-by", "research (OpenClaw)",
            "--max-runtime", f"{args.deadline_minutes}m",
            "--idempotency-key", task_id,
            f"Hermes独立研究-{args.project}",
        ]
        result = subprocess.run(create_cmd, capture_output=True, text=True, check=True)
        log(f"   ✅ kanban create: {result.stdout.strip()[:200]}")

        # 从 stdout 解析 task_id（如 t_xxxxxx）
        kanban_id = None
        for line in result.stdout.split("\n"):
            if "t_" in line:
                parts = line.split()
                for part in parts:
                    if part.startswith("t_"):
                        kanban_id = part.rstrip(":.,)")
                        break
                if kanban_id:
                    break

        if not kanban_id:
            log(f"⚠️ 未能从 stdout 解析 kanban task_id，跳过 assign/claim（task.json 已就位）")
            return 0

        log(f"   🆔 kanban task_id: {kanban_id}")

        # 强制 assign 到 default profile（防 create 时未生效）
        assign_cmd = ["hermes", "kanban", "assign", kanban_id, "default"]
        result = subprocess.run(assign_cmd, capture_output=True, text=True, check=True)
        log(f"   ✅ kanban assign: default")

        # claim 立即取走（不依赖 dispatcher tick）
        claim_cmd = ["hermes", "kanban", "claim", "--ttl", str(args.deadline_minutes * 60), kanban_id]
        result = subprocess.run(claim_cmd, capture_output=True, text=True, check=True)
        log(f"   ✅ kanban claim (ttl={args.deadline_minutes}m)")

    except subprocess.CalledProcessError as e:
        log(f"⚠️ kanban 命令失败 (returncode={e.returncode}): {e.stderr[:200]}")
        log(f"   ⚠️ Hermes 派单失败——但 task.json 已写入，仍可被文件系统协议捕获")
        return 0  # 不视为致命失败——A 径已生效

    log(f"✅ 派单完成：{task_id}")
    print(f"\n📋 后续操作：")
    print(f"   python3 hv_fusion_trigger.py poll --task-id {task_id} --timeout-minutes {args.deadline_minutes}")
    return 0


def cmd_poll(args) -> int:
    """轮询 incoming/{task_id}.report.md（最多 timeout 分钟）"""
    task_id = args.task_id
    report_path = INCOMING_DIR / f"{task_id}.report.md"
    deadline = args.timeout_minutes
    interval = args.interval_seconds

    log(f"🟢 启动轮询 task={task_id} (timeout={deadline}min)")
    deadline_at = time.time() + deadline * 60

    while time.time() < deadline_at:
        if report_path.exists():
            size = report_path.stat().st_size
            log(f"✅ Hermes 报告返回: {report_path} ({size} bytes)")
            if args.print_path:
                print(str(report_path))
            return 0
        elapsed_min = (deadline_at - time.time()) / 60
        log(f"⏳ 还剩 {elapsed_min:.1f}min, 文件未出现, {interval}s 后重试")
        time.sleep(interval)

    log(f"⚠️ Hermes 超时（{deadline}min）未返，继续主流程")
    if args.print_path:
        print("")
    return 2  # 超时 = 2


def cmd_check(args) -> int:
    """检查是否已有 in-flight 任务（防止重复派单）"""
    project = args.project
    ensure_dirs()

    today = datetime.now(CST).strftime("%Y%m%d")
    matching = []
    for task_json in OUTGOING_DIR.glob(f"{project}-*.task.json"):
        # 注意：file.stem 只去最后一个 .json，要手剥完整后缀
        task_id = task_json.name[:-len(".task.json")]
        report_path = INCOMING_DIR / f"{task_id}.report.md"
        report_returned = report_path.exists()
        # 如果文件已存在，视为已返回；否则查 kanban 真实状态
        if report_returned:
            kanban_status = "done"
        else:
            try:
                r = subprocess.run(
                    ["hermes", "kanban", "list", "--json"],
                    capture_output=True, text=True, timeout=5,
                )
                if r.returncode == 0:
                    tasks_data = json.loads(r.stdout)
                    matches = [
                        t for t in tasks_data
                        if task_id in t.get("title", "") or
                           task_id in (t.get("body", "")[:500])
                    ]
                    kanban_status = matches[0]["status"] if matches else "unknown"
                else:
                    kanban_status = "unknown"
            except Exception:
                kanban_status = "unknown"

        matching.append({
            "task_id": task_id,
            "task_json": str(task_json),
            "task_json_mtime": task_json.stat().st_mtime,
            "report_returned": report_returned,
            "report_path": str(report_path) if report_returned else None,
            "kanban_status": kanban_status,
        })

    if not matching:
        log(f"✅ 项目 {project} 当前无 in-flight 任务，可派单")
        return 0

    log(f"⚠️ 项目 {project} 有 {len(matching)} 个历史任务：")
    has_in_flight = False
    for m in matching:
        age_min = (time.time() - m["task_json_mtime"]) / 60
        if m["report_returned"]:
            status = "✅ 已返回"
        elif m["kanban_status"] in ("running", "ready", "blocked"):
            status = f"🟢 {m['kanban_status']}（in-flight）"
            has_in_flight = True
        elif m["kanban_status"] == "done":
            status = "✅ done（incoming 文件未找到）"
        else:
            status = f"❓ {m['kanban_status']}"
        log(f"   {status}  {m['task_id']} ({age_min:.1f}min 前)")
    return 1 if has_in_flight else 0


def get_hermes_status(task_id: str) -> str:
    """查询 Hermes kanban 任务的真实状态（不依赖 incoming/ 文件检查）
    Returns: 'done' / 'running' / 'ready' / 'unknown'
    """
    # 尝试从 task_id 推算 kanban_id（无法直接映射；fallback 到文件系统）
    # 简化：如果 incoming 文件存在 → done
    report_path = INCOMING_DIR / f"{task_id}.report.md"
    if report_path.exists():
        return "done"
    # 否则根据 .task.json 内的 created_at 判断是否存在
    task_json_path = OUTGOING_DIR / f"{task_id}.task.json"
    if not task_json_path.exists():
        return "unknown"
    # 默认 running（如果 outgoing 存在但 incoming 不存在）
    return "running"


def cmd_list(args) -> int:
    """列出所有 outgoing 任务 + 状态（基于 incoming/ 文件 + 实时 kanban 查询）"""
    ensure_dirs()
    tasks = sorted(OUTGOING_DIR.glob("*.task.json"), key=lambda p: p.stat().st_mtime, reverse=True)

    if not tasks:
        log("无 outgoing 任务")
        return 0

    log(f"📋 outgoing 任务（共 {len(tasks)} 个）")
    for task_json in tasks[:20]:
        # 注意：file.stem 只去最后一个 .json，要手剥完整后缀
        task_id = task_json.name[:-len(".task.json")]
        report_path = INCOMING_DIR / f"{task_id}.report.md"
        age_min = (time.time() - task_json.stat().st_mtime) / 60
        size = task_json.stat().st_size
        try:
            data = json.loads(task_json.read_text(encoding="utf-8"))
            target = data.get("target", {}).get("company_name", "?")
        except Exception:
            target = "?"

        # 状态判定
        if report_path.exists():
            status = "✅"
        else:
            # 尝试从 kanban 查真实状态
            try:
                r = subprocess.run(
                    ["hermes", "kanban", "list", "--json"],
                    capture_output=True, text=True, timeout=5,
                )
                if r.returncode == 0:
                    tasks_data = json.loads(r.stdout)
                    # 查找匹配的 task_id（title 中含 task_id）
                    matching = [
                        t for t in tasks_data
                        if task_id in t.get("title", "") or
                           task_id in (t.get("body", "")[:500])
                    ]
                    if matching:
                        ks = matching[0].get("status", "?")
                        status = {
                            "done": "✅",
                            "running": "🟢",
                            "ready": "⏸️",
                            "blocked": "🚫",
                        }.get(ks, "❓")
                    else:
                        status = "❓"
                else:
                    status = "⏳"
            except Exception:
                status = "⏳"

        log(f"   {status}  {task_id:40} | {age_min:5.1f}min 前 | {size:6}B | {target}")
    return 0


def cmd_dispatch(args) -> int:
    """一次性：派单 + 阻塞等待 + 打印报告路径"""
    # 1. trigger
    rc = cmd_trigger(args)
    if rc != 0:
        return rc

    # 2. 从 task_id 推算（找最新匹配的 outgoing）
    matching = sorted(
        OUTGOING_DIR.glob(f"{args.project}-P3-*.task.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if not matching:
        log("❌ trigger 后找不到 task.json")
        return 1
    task_id = matching[0].stem

    # 3. poll
    poll_args = argparse.Namespace(
        task_id=task_id,
        timeout_minutes=args.deadline_minutes,
        interval_seconds=60,
        print_path=True,
    )
    return cmd_poll(poll_args)


def main():
    parser = argparse.ArgumentParser(
        description="hv_fusion_trigger.py - Hermes 并行融合自动派单/轮询（V3.48.0+）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="action", required=True)

    # trigger
    p_trigger = sub.add_parser("trigger", help="派单：写 task.json + kanban create/assign/claim")
    p_trigger.add_argument("--project", required=True, help="项目名（如 汇天网络科技）")
    p_trigger.add_argument("--target", required=True, help="标的（如 汇天网络科技有限公司）")
    p_trigger.add_argument("--key-questions", help="逗号分隔的关键问题列表")
    p_trigger.add_argument("--data-sources", help="逗号分隔的数据源文件路径")
    p_trigger.add_argument("--data-anchors-json", help="data_anchors JSON 字符串")
    p_trigger.add_argument("--deadline-minutes", type=int, default=30)
    p_trigger.set_defaults(func=cmd_trigger)

    # poll
    p_poll = sub.add_parser("poll", help="轮询 Hermes 报告")
    p_poll.add_argument("--task-id", required=True)
    p_poll.add_argument("--timeout-minutes", type=int, default=30)
    p_poll.add_argument("--interval-seconds", type=int, default=60)
    p_poll.add_argument("--print-path", action="store_true")
    p_poll.set_defaults(func=cmd_poll)

    # check
    p_check = sub.add_parser("check", help="检查项目是否有 in-flight 任务")
    p_check.add_argument("--project", required=True)
    p_check.set_defaults(func=cmd_check)

    # list
    p_list = sub.add_parser("list", help="列出所有 outgoing 任务")
    p_list.set_defaults(func=cmd_list)

    # dispatch（trigger + poll 一次性）
    p_dispatch = sub.add_parser("dispatch", help="派单 + 阻塞等待 + 打印报告路径")
    p_dispatch.add_argument("--project", required=True)
    p_dispatch.add_argument("--target", required=True)
    p_dispatch.add_argument("--key-questions")
    p_dispatch.add_argument("--data-sources")
    p_dispatch.add_argument("--data-anchors-json")
    p_dispatch.add_argument("--deadline-minutes", type=int, default=30)
    p_dispatch.set_defaults(func=cmd_dispatch)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())