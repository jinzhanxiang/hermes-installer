#!/usr/bin/env python3
"""
hv-write-report.py — 纵横分析法 V3.45+ 分块生成器（V3.47.0）

设计目标：
  解决 V3.43.0（8K 字）→ V3.45+（21K 字）的标准提升与工作流不匹配问题。
  按 §三 25 章模板，按 Phase 分块提供 LLM 提示词，避免单次 LLM 输出超 21K 字
  导致的中断和质量下降。

用法：
  python3 hv-write-report.py --phase 1 --project 汇天网络科技 --output output/汇天IDC_v3_phase1.md
  python3 hv-write-report.py --phase 2 --project 汇天网络科技 --output output/汇天IDC_v3_phase2.md
  python3 hv-write-report.py --phase 3 --project 汇天网络科技 --output output/汇天IDC_v3_phase3.md
  python3 hv-write-report.py --phase 4 --project 汇天网络科技 --output output/汇天IDC_v3_phase4.md
  python3 hv-write-report.py --merge output/汇天IDC_v3_phase{1..4}.md --final output/汇天IDC_v3_final.md

LLM 工作流：
  1. LLM 按 phase1_prompt() 输出的提示词写 Phase 1 八章（目标 ≥8K 中文字）
  2. LLM 按 phase2_prompt() 输出 Phase 2 六章（目标 ≥6K 中文字）
  3. LLM 按 phase3_prompt() 输出 Phase 3 七章（目标 ≥4K 中文字）
  4. LLM 按 phase4_prompt() 输出 Phase 4 四章（目标 ≥3K 中文字，决策模式激活时）
  5. 调用 merge_files() 合并 4 个 Phase 文件 → 最终报告

门禁（hv-gate.py）：
  - 整体 ≥18K 中文字（标准）/ ≥21K（决策模式）
  - 每个 Phase 单独达标
  - 章节数 ≥22（决策模式 25）
  - 来源标注 ≥10
  - 占位符 0
  - 图表 ≥5 张
"""
import sys
import os
import argparse
from pathlib import Path

# ═══════════════════════════════════════════════════════════════════════════
# §三 25 章模板（V3.45.2）
# ═══════════════════════════════════════════════════════════════════════════

CHAPTERS = {
    # Phase 1 纵向分析（8 章，≥8,000 字）
    1: {"title": "公司概况与发展历程", "phase": 1, "guide_words": 1000, "density": "≥3 个关键时间节点 + 股权结构表"},
    2: {"title": "业务结构与收入演变", "phase": 1, "guide_words": 1000, "density": "≥3 年数据 + 按产品线×地区拆分"},
    3: {"title": "财务表现与盈利质量", "phase": 1, "guide_words": 1000, "density": "≥3 年三表核心指标 + 扣非 vs GAAP"},
    4: {"title": "技术与知识产权", "phase": 1, "guide_words": 600, "density": "专利数量+类型+法律状态"},
    5: {"title": "公司治理与团队", "phase": 1, "guide_words": 600, "density": "实控人控制路径 + ESOP 详情"},
    6: {"title": "产业链定位", "phase": 1, "guide_words": 500, "density": "供应商CR3 + 客户CR3"},
    7: {"title": "盈利预测与假设检验", "phase": 1, "guide_words": 600, "density": "收入增速/毛利率/费用率 3 项假设检验"},
    8: {"title": "纵向分析小结", "phase": 1, "guide_words": 500, "density": "≥3 个核心发现"},
    # Phase 2 横向分析（6 章，≥6,000 字）
    9: {"title": "行业规模与竞争格局", "phase": 2, "guide_words": 1000, "density": "TAM/SAM/SOM + CR5 趋势"},
    10: {"title": "竞品对标矩阵", "phase": 2, "guide_words": 1000, "density": "≥3 家竞品 + 完整6维度"},
    11: {"title": "技术路线对比", "phase": 2, "guide_words": 600, "density": "≥2 条技术路线量化对比"},
    12: {"title": "商业模式对比", "phase": 2, "guide_words": 600, "density": "至少覆盖收入模式+成本结构"},
    13: {"title": "估值横向对比", "phase": 2, "guide_words": 800, "density": "≥3 个估值指标 + 竞品对比"},
    14: {"title": "横向分析小结", "phase": 2, "guide_words": 500, "density": "≥3 个核心发现"},
    # Phase 3 交叉洞察（7 章，≥4,000 字）
    15: {"title": "核心矛盾揭示", "phase": 3, "guide_words": 800, "density": "≥2 个矛盾点"},
    16: {"title": "竞争优势持续性评估", "phase": 3, "guide_words": 600, "density": "5 类护城河逐项评分"},
    17: {"title": "风险交叉验证", "phase": 3, "guide_words": 600, "density": "≥3 个交叉风险"},
    18: {"title": "估值三锚校验", "phase": 3, "guide_words": 600, "density": "三锚估值区间表 + 双口径P/S/P/E/P/B对照表"},
    19: {"title": "成长空间量化", "phase": 3, "guide_words": 500, "density": "三层市场空间测算"},
    20: {"title": "投资结论与建议", "phase": 3, "guide_words": 600, "density": "≥3 条明确建议 + 7 维评分 + 置信度表"},
    21: {"title": "交叉分析总结", "phase": 3, "guide_words": 400, "density": "≥5 个关键洞察"},
    # Phase 4 决策支持（4 章，≥3,000 字，决策模式激活时）
    22: {"title": "交易结构分析", "phase": 4, "guide_words": 800, "density": "≥2 种交易结构方案量化对比"},
    23: {"title": "退出路径分析", "phase": 4, "guide_words": 800, "density": "至少覆盖 3 种退出路径 + 可行性评分"},
    24: {"title": "约束条件建模", "phase": 4, "guide_words": 600, "density": "每项约束标注「确定性/影响程度/可规避性」"},
    25: {"title": "情景推演与行动建议", "phase": 4, "guide_words": 800, "density": "≥3 情景 + 每情景含：隐含市值/PE倍数/基金IRR/MOIC + 行动建议"},
}


# ═══════════════════════════════════════════════════════════════════════════
# Phase 提示词模板
# ═══════════════════════════════════════════════════════════════════════════

PHASE_HEADER_TEMPLATE = """# {project_name} — 纵横分析法研究报告

> **方法论**：Saussure 历时-共时 / Cook & Campbell 纵横向 / Yin 案例研究 / Porter 竞争战略
> **报告模式**：{mode_cn}（{chapter_count} 章 / 总字数目标 ≥{total_target:,}）
> **生成日期**：{today}

---
"""

PHASE1_PROMPT = """# Phase 1：纵向分析（8 章，目标 ≥8,000 中文字符）

## 任务背景
你正在为「{project_name}」撰写纵横分析法研究报告的 **Phase 1 纵向分析**部分。
纵向分析 = 单一研究对象的 N 年时间轴深度追踪。

## 数据源使用规则
1. **本地文件**（首选）：从 `~/Documents/OpenClaw-Workspace-research/projects/{project_name}/extracted/` 读取所有 PDF/DOCX/PNG
2. **桌面文件**（次选）：从 `~/Desktop/` 扫描项目相关文件
3. **iFind Finance**（A 级信源）：上市公司财务数据
4. **AKShare**（A 级信源）：宏观/行业数据
5. **Tavily/Web**（B 级信源）：补充新闻/政策

每条数据点必须标注来源：`[本地:文件名]` / `[iFind:财务指标]` / `[AKShare:宏观]` / `[Tavily:新闻]`

## 章节模板（8 章）

### 第一章：{c1}（引导 1,000 字 / {c1_density}）
- 成立背景 / 股权演变 / 关键里程碑 / 实际控制人
- 必须包含：≥3 个关键时间节点 + 股权结构表

### 第二章：{c2}（引导 1,000 字 / {c2_density}）
- 产品线拆分 / 量价驱动 / 地区分布 / 客户结构
- 必须包含：≥3 年数据 + 按产品线×地区拆分

### 第三章：{c3}（引导 1,000 字 / {c3_density}）
- 营收 / 净利 / 毛利率 / ROE 趋势 + QoE 调整
- 必须包含：≥3 年三表核心指标 + 扣非 vs GAAP 对比

### 第四章：{c4}（引导 600 字 / {c4_density}）
- 技术路线 / 专利布局 / 研发投入 / 技术里程碑
- 必须包含：专利数量+类型+法律状态

### 第五章：{c5}（引导 600 字 / {c5_density}）
- 董事会 / 核心团队 / 股权激励 / 历史合规
- 必须包含：实控人控制路径 + ESOP 详情

### 第六章：{c6}（引导 500 字 / {c6_density}）
- 上下游结构 / 议价力 / 利润池分布 / 垂直整合
- 必须包含：供应商CR3 + 客户CR3

### 第七章：{c7}（引导 600 字 / {c7_density}）
- 预测假设逐项验证 / 敏感性分析
- 必须包含：收入增速 / 毛利率 / 费用率 3 项假设检验

### 第八章：{c8}（引导 500 字 / {c8_density}）
- 核心发现 / 关键转折点 / 待验证问题
- 必须包含：≥3 个核心发现

## 硬性约束（违反即报告不合规）
- 总字符 ≥8,000 中文字符
- 每章不少于引导字数的 50%
- ≥10 处来源标注（[本地] / [iFind] / [AKShare] / [Tavily]）
- 0 处占位符（## TODO / ## 待补充 / ## 占位 等）

## 输出格式
直接输出 Markdown 报告正文（不含 H1 大标题——已在外层统一管理）。每章用 `## 一、第一章标题` 起始。
"""


PHASE2_PROMPT = """# Phase 2：横向分析（6 章，目标 ≥6,000 中文字符）

## 任务背景
你正在为「{project_name}」撰写纵横分析法研究报告的 **Phase 2 横向分析**部分。
横向分析 = N 个对象在同一时点的切片对比。

## 数据源使用规则（同 Phase 1）
- 本地文件 / iFind / AKShare / Tavily
- 必须包含 ≥3 家可比公司的财务对标

## 章节模板（6 章）

### 第九章：{c9}（引导 1,000 字 / {c9_density}）
- 市场规模 / CAGR / CR5 / 波特五力 / 政策环境
- 必须包含：TAM/SAM/SOM + CR5 趋势

### 第十章：{c10}（引导 1,000 字 / {c10_density}）
- 6 维度对标：技术 / 产品 / 用户 / 优劣势 / 定价 / 规模
- 必须包含：≥3 家竞品 + 完整 6 维度

### 第十一章：{c11}（引导 600 字 / {c11_density}）
- 技术路径差异 / 性能指标 / 专利布局 / 研发投入对比
- 必须包含：≥2 条技术路线量化对比

### 第十二章：{c12}（引导 600 字 / {c12_density}）
- 收入模式 / 成本结构 / 盈利质量 / 增长驱动
- 必须包含：收入模式 + 成本结构

### 第十三章：{c13}（引导 800 字 / {c13_density}）
- PE / PB / PS / EV-EBITDA / 非上市流动性折价
- 必须包含：≥3 个估值指标 + 竞品对比

### 第十四章：{c14}（引导 500 字 / {c14_density}）
- 相对定位 / 差异化优势 / 竞争劣势 / 待验证问题
- 必须包含：≥3 个核心发现

## 硬性约束
- 总字符 ≥6,000 中文字符
- ≥5 处可比公司财务数据引用
- ≥10 处来源标注

## 输出格式
直接输出 Markdown 报告正文。每章用 `## 九、第九章标题` 起始。
"""


PHASE3_PROMPT = """# Phase 3：交叉洞察（7 章，目标 ≥4,000 中文字符）

## 任务背景
你正在为「{project_name}」撰写纵横分析法研究报告的 **Phase 3 交叉洞察**部分。
交叉洞察 = 纵向时间轴 × 横向切片的交叉点深度分析。

## 章节模板（7 章）

### 第十五章：{c15}（引导 800 字 / {c15_density}）
- 纵横向数据矛盾 / 财务×法律交叉 / 竞争×合规交叉
- 必须包含：≥2 个矛盾点

### 第十六章：{c16}（引导 600 字 / {c16_density}）
- 护城河评分 / 时间窗口量化 / 替代威胁
- 必须包含：5 类护城河逐项评分

### 第十七章：{c17}（引导 600 字 / {c17_density}）
- 财务风险 × 法律风险 × 商业风险关联
- 必须包含：≥3 个交叉风险

### 第十八章：{c18}（引导 600 字 / {c18_density}）
- 三锚估值：交易价格 / PE 对标 / SOTP
- 必须包含：三锚估值区间表 + 双口径 P/S / P/E / P/B 对照表

### 第十九章：{c19}（引导 500 字 / {c19_density}）
- TAM / SAM / SOM + 新市场可行性
- 必须包含：三层市场空间测算

### 第二十章：{c20}（引导 600 字 / {c20_density}）
**特别重要**：本章节是「决策摘要」，**必须包含以下 5 个模块**：
1. **7 维星级评分**（行业前景/商业模式/盈利能力/成长性/财务健康/估值合理性/投资性价比）
2. **优先级标注**（P1=🔴/P2=🟡/P3=🟢，按综合评分触发）
3. **投资建议**（核心逻辑+≥3 条亮点+≥3 条风险+≥3 条行动）
4. **退出路径快照**（可行性/时间窗口/预期回报/前置条件）
5. **数据置信度表**（A 级审计/A 级法律/B 级内部/C 级非正式）

### 第二十一章：{c21}（引导 400 字 / {c21_density}）
- 全文核心洞察汇总
- 必须包含：≥5 个关键洞察

## 警醒信号 S1-S7（V3.45+ 强制）
- **S1**：治理路径与业务实质矛盾（如合并权益 10.20% 与"控制并表"自相矛盾）
- **S2**：财务数据矛盾（不同来源差异 >20%）
- **S3**：估值与业绩倒挂（PE 极高但增速放缓）
- **S4**：退出路径单一（仅 IPO 或仅换股）
- **S5**：决策偏差警醒（5 模块决策摘要任一缺失）
- **S6**：警醒信号未触发但风险已显
- **S7**：本地文件 vs 公开数据矛盾

## 硬性约束
- 总字符 ≥4,000 中文字符
- ≥3 处 S1-S7 警醒信号触发分析
- 第 20 章 5 模块完整

## 输出格式
直接输出 Markdown 报告正文。每章用 `## 十五、第十五章标题` 起始。
"""


PHASE4_PROMPT = """# Phase 4：决策支持（4 章，目标 ≥3,000 中文字符，决策模式激活时）

## 任务背景
你正在为「{project_name}」撰写纵横分析法研究报告的 **Phase 4 决策支持**部分。
**加载条件**：任务类型含「尽调/投资/并购/退出/交易」时激活。研究类任务跳过。

## 章节模板（4 章）

### 第二十二章：{c22}（引导 800 字 / {c22_density}）
- 换股 / 现金 / 混合方案对比
- 换股比例计算 / 支付节奏 / 障碍项（基金亏损/合规缺口）
- 必须包含：≥2 种交易结构方案量化对比

### 第二十三章：{c23}（引导 800 字 / {c23_density}）
- 独立上市 / 被并购 / 注入平台的可行性矩阵
- 时间窗口 / 回报区间 / 约束条件传导
- 必须包含：至少覆盖 3 种退出路径 + 可行性评分

### 第二十四章：{c24}（引导 600 字 / {c24_density}）
- 监管约束（IPO 禁令/股东处罚）
- 平台约束（新收上限）
- 谈判约束（对方诉求）的量化影响
- 必须包含：每项约束标注「确定性/影响程度/可规避性」

### 第二十五章：{c25}（引导 800 字 / {c25_density}）
**特别重要**：本章节是「行动建议」，**必须包含 IRR 分级表**：

| 情景 | 概率 | 隐含市值 | PE倍数 | 基金IRR | MOIC | 关键前提 |
|------|:--:|:------:|:-----:|:-----:|:---:|---------|
| 保守 | 25% | — | — | — | — | — |
| 中性 | 50% | — | — | — | — | — |
| 乐观 | 25% | — | — | — | — | — |

- 必须包含：≥3 情景 + 每情景含：隐含市值 / PE 倍数 / 基金 IRR / MOIC + 行动建议
- IRR 计算说明：基金 IRR = 基于投资金额、退出市值、持有期限的年化内部收益率；MOIC = 退出价值/投资成本
- 持有期默认：3 年（换股并购）或 5 年（IPO）
- 概率加权 IRR = Σ(情景IRR × 概率)
- 强制规则：保守情景 IRR 不得低于回购条款保底回报（如年化 6%）；若 MOIC<1.0x 必须标 🔴

## 硬性约束
- 总字符 ≥3,000 中文字符
- IRR 分级表完整（保守/中性/乐观 × 隐含市值/PE/IRR/MOIC/前提）
- 概率加权 IRR 计算

## 输出格式
直接输出 Markdown 报告正文。每章用 `## 二十二、第二十二章标题` 起始。
"""


# ═══════════════════════════════════════════════════════════════════════════
# 工具函数
# ═══════════════════════════════════════════════════════════════════════════

def cn_count(text: str) -> int:
    """统计中文字符数（CJK Unified Ideographs）"""
    return sum(1 for c in text if '\u4e00' <= c <= '\u9fff')


def phase1_prompt(project_name: str, today: str = "") -> str:
    today = today or "2026-07-10"
    return PHASE1_PROMPT.format(
        project_name=project_name,
        c1=CHAPTERS[1]["title"], c1_density=CHAPTERS[1]["density"],
        c2=CHAPTERS[2]["title"], c2_density=CHAPTERS[2]["density"],
        c3=CHAPTERS[3]["title"], c3_density=CHAPTERS[3]["density"],
        c4=CHAPTERS[4]["title"], c4_density=CHAPTERS[4]["density"],
        c5=CHAPTERS[5]["title"], c5_density=CHAPTERS[5]["density"],
        c6=CHAPTERS[6]["title"], c6_density=CHAPTERS[6]["density"],
        c7=CHAPTERS[7]["title"], c7_density=CHAPTERS[7]["density"],
        c8=CHAPTERS[8]["title"], c8_density=CHAPTERS[8]["density"],
    )


def phase2_prompt(project_name: str) -> str:
    return PHASE2_PROMPT.format(
        project_name=project_name,
        c9=CHAPTERS[9]["title"], c9_density=CHAPTERS[9]["density"],
        c10=CHAPTERS[10]["title"], c10_density=CHAPTERS[10]["density"],
        c11=CHAPTERS[11]["title"], c11_density=CHAPTERS[11]["density"],
        c12=CHAPTERS[12]["title"], c12_density=CHAPTERS[12]["density"],
        c13=CHAPTERS[13]["title"], c13_density=CHAPTERS[13]["density"],
        c14=CHAPTERS[14]["title"], c14_density=CHAPTERS[14]["density"],
    )


def phase3_prompt(project_name: str) -> str:
    return PHASE3_PROMPT.format(
        project_name=project_name,
        c15=CHAPTERS[15]["title"], c15_density=CHAPTERS[15]["density"],
        c16=CHAPTERS[16]["title"], c16_density=CHAPTERS[16]["density"],
        c17=CHAPTERS[17]["title"], c17_density=CHAPTERS[17]["density"],
        c18=CHAPTERS[18]["title"], c18_density=CHAPTERS[18]["density"],
        c19=CHAPTERS[19]["title"], c19_density=CHAPTERS[19]["density"],
        c20=CHAPTERS[20]["title"], c20_density=CHAPTERS[20]["density"],
        c21=CHAPTERS[21]["title"], c21_density=CHAPTERS[21]["density"],
    )


def phase4_prompt(project_name: str) -> str:
    return PHASE4_PROMPT.format(
        project_name=project_name,
        c22=CHAPTERS[22]["title"], c22_density=CHAPTERS[22]["density"],
        c23=CHAPTERS[23]["title"], c23_density=CHAPTERS[23]["density"],
        c24=CHAPTERS[24]["title"], c24_density=CHAPTERS[24]["density"],
        c25=CHAPTERS[25]["title"], c25_density=CHAPTERS[25]["density"],
    )


def merge_files(phase_files: list, final_file: Path) -> dict:
    """合并 4 个 Phase 文件 → 最终报告
    
    Returns: {"total_chars": int, "chapter_count": int, "size_bytes": int}
    """
    today = "2026-07-10"  # 默认
    header = PHASE_HEADER_TEMPLATE.format(
        project_name="汇天网络科技",
        mode_cn="决策模式",
        chapter_count=25,
        total_target=21000,
        today=today,
    )
    
    body_parts = []
    for pf in phase_files:
        if Path(pf).exists():
            body_parts.append(Path(pf).read_text(encoding='utf-8'))
    
    full_text = header + "\n\n".join(body_parts)
    
    final_file.write_text(full_text, encoding='utf-8')
    
    return {
        "total_chars": cn_count(full_text),
        "chapter_count": sum(1 for line in full_text.split('\n') if line.startswith('## ') and not line.startswith('## §')),
        "size_bytes": final_file.stat().st_size,
    }


# ═══════════════════════════════════════════════════════════════════════════
# CLI 入口
# ═══════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="hv-write-report.py — V3.45+ 分块生成器")
    parser.add_argument("--phase", type=int, choices=[1, 2, 3, 4], help="Phase 编号（1-4）")
    parser.add_argument("--project", help="项目名称")
    parser.add_argument("--output", help="输出文件路径（默认 stdout）")
    parser.add_argument("--merge", nargs="+", help="合并多个 Phase 文件")
    parser.add_argument("--final", help="合并后的最终文件路径")
    parser.add_argument("--list-chapters", action="store_true", help="列出所有 25 章模板")
    args = parser.parse_args()
    
    if args.list_chapters:
        print("=" * 70)
        print("  §三 25 章模板（V3.45.2）")
        print("=" * 70)
        for n, c in CHAPTERS.items():
            print(f"  {n:2d}. [{c['phase']}] {c['title']}（引导 {c['guide_words']} 字 / {c['density']}）")
        print()
        print(f"  Phase 1 总目标: ≥8,000 中文字符")
        print(f"  Phase 2 总目标: ≥6,000 中文字符")
        print(f"  Phase 3 总目标: ≥4,000 中文字符")
        print(f"  Phase 4 总目标: ≥3,000 中文字符")
        print(f"  决策模式合计: ≥21,000 中文字符")
        print(f"  研究模式合计: ≥18,000 中文字符")
        return 0
    
    if args.merge:
        if not args.final:
            print("❌ --merge 必须配合 --final 指定合并输出路径")
            return 1
        result = merge_files(args.merge, Path(args.final))
        print(f"✅ 合并完成: {args.final}")
        print(f"   总字符: {result['total_chars']:,}")
        print(f"   章节数: {result['chapter_count']}")
        print(f"   大小: {result['size_bytes']:,} bytes")
        return 0
    
    if not args.phase or not args.project:
        parser.print_help()
        return 1
    
    # 输出对应 Phase 的提示词
    prompts = {1: phase1_prompt, 2: phase2_prompt, 3: phase3_prompt, 4: phase4_prompt}
    prompt_text = prompts[args.phase](args.project)
    
    if args.output:
        Path(args.output).write_text(prompt_text, encoding='utf-8')
        print(f"✅ Phase {args.phase} 提示词已写入: {args.output}")
        print(f"   字数: {cn_count(prompt_text):,} 中文字符")
        print(f"   大小: {Path(args.output).stat().st_size:,} bytes")
        print()
        print(f"📖 下一步：将此提示词发给 LLM，让其按提示写报告")
        print(f"   写完后用 --phase <N> 写下一阶段，最终用 --merge 合并")
    else:
        print(prompt_text)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())