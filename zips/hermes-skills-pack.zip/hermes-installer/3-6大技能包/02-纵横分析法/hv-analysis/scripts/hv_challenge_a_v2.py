#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HV-Challenge-A V2.0 · 横向对标防幻觉（嫁接 V3 ChallengeAgent + iFind 实接口）
================================================================================

【V2.0 核心升级】（基于 V2.0 防幻觉设计）
1. 取消 5 维度综合分（与 B 一致）
2. 新增：横向对标数据点抽取（金融 + 事实）
3. 新增：实接口多源比对（iFind 投研核验每个对标数据）
4. 新增：对标公司可验证性（每个对标公司是否真实可比）
5. 新增：横向数据幻觉清单（无法追溯的数据标 [幻觉]）
6. 新增：数据范围核实（数量与年度是否一致）

【输入】
- lateral_report: 横向对标报告 markdown
- competitors: 竞品列表
- target: 研究目标
- model: LLM 模型（默认 MiniMax-M3）

【输出】（V2.0 防幻觉格式）
1. 横向事实核查表（数据点 + 来源标注 + 一致性 + 多源验证）
2. 对标公司可验证性清单
3. 横向数据幻觉清单
4. 数据范围核实清单
5. 多源比对结果
6. 整体评估（passed/failed 依据：幻觉数 + 冲突数）

【与 hv_challenge_b 共享】
- extract_financial_data_points（金融数据抽取）
- extract_factual_data_points（事实数据抽取）
- generate_verification_plan（验证计划生成器，不调用外部接口）

【版本】V2.1.0（防幻觉改造 — Agent 驱动数据源）
"""

import sys
import os
import re
from pathlib import Path
from typing import Dict, List, Optional

# 让 hv_challenge_b 的 V2 模块可被 import
_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from hv_challenge_b import (
    extract_financial_data_points,
    extract_factual_data_points,
    generate_verification_plan,
    _IFIND_CACHE,
)


def run_challenge_a_v2(
    target: str,
    lateral_report: str,
    competitors: Optional[List[str]] = None,
    model: str = "minimax-portal/MiniMax-M3",
) -> Dict:
    """
    质疑节点 A V2.0：横向对标防幻觉核查

    与 V1.0 对比：
    - V1：5 维度评分 → 综合分 → 是否通过
    - V2：数据点抽取 → 多源比对 → 幻觉清单 → 是否通过（幻觉=0 强制标准）

    Returns:
        {
            "passed": bool,  # 幻觉 = 0 且 冲突 < 5 时通过
            "data_point_count": int,
            "hallucination_count": int,
            "conflict_count": int,
            "fact_check_table": List[Dict],
            "competitor_verification": List[Dict],
            "data_range_check": List[Dict],
            "multi_source_verification": Dict,
            "hallucination_list": List[Dict],
            "markdown": str,
        }
    """
    print(f"[HV-Challenge-A-V2] ▶ 横向对标防幻觉核查（target={target}）", file=sys.stderr)

    # 1. 抽取数据点（复用 B 的接口）
    financial_points = extract_financial_data_points(lateral_report)
    factual_points = extract_factual_data_points(lateral_report)
    total_data_points = len(financial_points) + len(factual_points)

    print(
        f"[HV-Challenge-A-V2]   → 金融数据点 {len(financial_points)} / "
        f"事实数据点 {len(factual_points)}",
        file=sys.stderr,
    )

    # 2. 识别对标公司（从报告 + competitors 参数）
    identified_competitors = _identify_competitors(target, lateral_report, competitors)
    print(
        f"[HV-Challenge-A-V2]   → 识别对标公司 {len(identified_competitors)}",
        file=sys.stderr,
    )

    # 3. 对标公司可验证性核查
    competitor_verification = _verify_competitors(identified_competitors)

    # 4. 数据范围核实（数量级 / 年度匹配）
    data_range_check = _check_data_range(financial_points, factual_points)

    # 5. 生成验证计划（不调用外部接口）
    financial_plan = generate_verification_plan(
        financial_points, company_hint=target
    )
    factual_plan = generate_verification_plan(
        factual_points, company_hint=target
    )
    multi_source = {
        "financial_plan": financial_plan,
        "factual_plan": factual_plan,
        "note": "Agent 通过 Bash 工具自主执行验证，计划供参考",
    }

    # 6. 幻觉清单（基于验证计划评估）
    hallucination_list = _build_hallucination_list(
        financial_points, factual_points, financial_plan, factual_plan
    )

    # 7. 事实核查表（合并数据点 + 验证计划）
    fact_check_table = _build_fact_check_table(
        financial_points, factual_points, financial_plan, factual_plan
    )

    # 8. 整体判定
    hallucination_count = len(hallucination_list)
    conflict_count = (
        financial_verification.get("mismatched_points", 0)
        + factual_verification.get("mismatched_points", 0)
    )
    passed = (hallucination_count == 0) and (conflict_count < 5)

    print(
        f"[HV-Challenge-A-V2]   → 幻觉 {hallucination_count} / "
        f"冲突 {conflict_count} / "
        f"对标公司 {len(competitor_verification)}",
        file=sys.stderr,
    )

    # 9. 生成 markdown
    markdown = _render_challenge_a_v2_markdown(
        target=target,
        identified_competitors=identified_competitors,
        fact_check_table=fact_check_table,
        competitor_verification=competitor_verification,
        data_range_check=data_range_check,
        hallucination_list=hallucination_list,
        multi_source=multi_source,
        hallucination_count=hallucination_count,
        conflict_count=conflict_count,
        total_data_points=total_data_points,
        passed=passed,
    )

    print(
        f"[HV-Challenge-A-V2] {'✅ 通过' if passed else '⚠️ 未通过'}："
        f"{hallucination_count} 幻觉 / {conflict_count} 冲突",
        file=sys.stderr,
    )

    return {
        "passed": passed,
        "data_point_count": total_data_points,
        "hallucination_count": hallucination_count,
        "conflict_count": conflict_count,
        "fact_check_table": fact_check_table,
        "competitor_verification": competitor_verification,
        "data_range_check": data_range_check,
        "multi_source_verification": multi_source,
        "hallucination_list": hallucination_list,
        "markdown": markdown,
    }


# ============================================================
# 内部函数
# ============================================================

def _identify_competitors(
    target: str, report: str, competitors: Optional[List[str]]
) -> List[Dict]:
    """识别报告中的对标公司"""
    # 优先级：1) 用户传入 2) 报告里识别
    competitors_list = list(competitors) if competitors else []

    # 从报告里识别常见对标公司
    common_competitors = [
        ("三安光电", "600703.SH"),
        ("华灿光电", "300323.SZ"),
        ("蔚蓝锂芯", "002245.SZ"),
        ("乾照光电", "300102.SZ"),
        ("澳洋顺昌", "002245.SZ"),
        ("聚灿光电", "300708.SZ"),
        ("国星光电", "002449.SZ"),
        ("兆驰股份", "002429.SZ"),
        ("雷曼光电", "300162.SZ"),
        ("东山精密", "002384.SZ"),
    ]

    identified = []
    for name, code in common_competitors:
        # 用户传入优先
        if competitors_list and name in competitors_list:
            identified.append({"name": name, "code": code, "source": "user_provided"})
        elif name in report:
            identified.append({"name": name, "code": code, "source": "from_report"})

    # 用户传入但未识别的
    if competitors_list:
        for c in competitors_list:
            if not any(c == item["name"] for item in identified):
                identified.append({"name": c, "code": "未知", "source": "user_provided"})

    return identified


def _verify_competitors(competitors: List[Dict]) -> List[Dict]:
    """对标公司可验证性核查（判断股票代码是否真实上市）"""
    results = []
    for comp in competitors:
        name = comp["name"]
        code = comp["code"]
        if code == "未知":
            results.append({
                "name": name,
                "code": code,
                "verifiable": False,
                "label": "[待核实]",
                "note": "未提供股票代码，需 SearXNG / 企查查 / 天眼查核验",
            })
            continue

        # V2.1: 不再硬编码调用 iFind，改为输出验证推荐。
        # Agent 通过 Bash 工具自主决定是否验证。
        results.append({
            "name": name,
            "code": code,
            "verifiable": None,
            "label": "[待Agent验证]",
            "recommended_source": "iFind Finance / MX Data D1",
            "recommended_query": f"{name} {code} 基本信息",
        })

    return results


def _check_data_range(
    financial_points: List[Dict], factual_points: List[Dict]
) -> List[Dict]:
    """数据范围核实（数量级 + 年度匹配）"""
    issues = []

    for dp in financial_points:
        value = dp.get("value", "")
        category = dp.get("category", "")
        context = dp.get("context", "")

        # 数量级异常（如 "营收 100万" 但实际公司营收百亿）
        # 检查是否包含异常大或异常小
        m = re.search(r"(\d+(?:\.\d+)?)\s*(亿|万|%)?", value)
        if m:
            num = float(m.group(1))
            unit = m.group(2) or ""

            # 营收 < 1 亿 但说"千亿赛道"
            if category == "营收" and unit == "万" and num > 100:
                issues.append({
                    "data_point": value,
                    "category": category,
                    "type": "数量级异常",
                    "note": f"营收标 {num} 万，但通常公司营收以亿计",
                    "label": "[异常]",
                })

            # 毛利率/净利率 > 100%
            if category in ("毛利率", "净利率") and num > 100:
                issues.append({
                    "data_point": value,
                    "category": category,
                    "type": "百分比异常",
                    "note": f"{category} = {num}% 超过 100% 不合理",
                    "label": "[异常]",
                })

        # 年度上下文检查
        years = re.findall(r"(20\d{2})\s*年?", context)
        if years:
            unique_years = list(set(years))
            if len(unique_years) > 1:
                issues.append({
                    "data_point": value,
                    "category": category,
                    "type": "年度混杂",
                    "note": f"上下文涉及多个年度: {unique_years}",
                    "label": "[混杂]",
                })

    return issues


def _build_hallucination_list(
    financial_points, factual_points, financial_verification, factual_verification
) -> List[Dict]:
    """构建幻觉清单"""
    hallucinations = []

    # 1. 无源金融数据（context 中无来源标注）
    for dp in financial_points:
        context = dp.get("context", "")
        has_source = bool(re.search(r"\[源[：:]|来源|Source|源：|\[\d+_", context))
        if not has_source:
            hallucinations.append({
                "type": "无源金融数据",
                "data_point": dp.get("value", ""),
                "category": dp.get("category", ""),
                "context": context[:100],
                "label": "[幻觉]",
            })

    # 2. 无源事实数据
    for dp in factual_points:
        context = dp.get("context", "")
        has_source = bool(re.search(r"\[源[：:]|来源|Source|源：|\[\d+_", context))
        if not has_source:
            hallucinations.append({
                "type": "无源事实数据",
                "data_point": dp.get("value", ""),
                "category": dp.get("category", ""),
                "context": context[:100],
                "label": "[幻觉]",
            })

    # 3. 实接口冲突
    for m in financial_verification.get("details", []):
        if m.get("label") == "[冲突]":
            hallucinations.append({
                "type": "实接口冲突",
                "data_point": m.get("data_point", ""),
                "category": m.get("category", ""),
                "context": m.get("source_excerpt", "")[:100],
                "label": "[冲突]",
            })

    for m in factual_verification.get("details", []):
        if m.get("label") == "[冲突]":
            hallucinations.append({
                "type": "事实性冲突",
                "data_point": m.get("data_point", ""),
                "category": m.get("category", ""),
                "context": m.get("source_excerpt", "")[:100],
                "label": "[冲突]",
            })

    # 去重
    seen = set()
    unique = []
    for h in hallucinations:
        key = (h["type"], h["data_point"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(h)

    return unique


def _build_fact_check_table(
    financial_points,
    factual_points,
    financial_verification,
    factual_verification,
) -> List[Dict]:
    """构建事实核查表"""
    table = []

    for dp in financial_points:
        value = dp.get("value", "")
        category = dp.get("category", "")
        context = dp.get("context", "")

        # 来源标注（[源:xx] / [可信度:X]）
        sources = re.findall(r"\[源[：:][^\]]+\]", context)
        credibility = re.findall(r"\[可信度[：:][^\]]+\]", context)

        # 多源验证
        verified = False
        verified_label = "[待核]"
        for v in financial_verification.get("details", []):
            if v.get("data_point") == value and v.get("verified"):
                verified = True
                verified_label = "[已证]"
                break
            elif v.get("data_point") == value and v.get("verified") is False:
                verified_label = "[冲突]"

        table.append({
            "data_point": value,
            "category": category,
            "source": sources[0] if sources else "[无标注]",
            "credibility": credibility[0] if credibility else "[未标注]",
            "multi_source": verified_label,
            "context": context[:80],
        })

    for dp in factual_points:
        value = dp.get("value", "")
        category = dp.get("category", "")
        context = dp.get("context", "")

        sources = re.findall(r"\[源[：:][^\]]+\]", context)

        table.append({
            "data_point": value,
            "category": category,
            "source": sources[0] if sources else "[无标注]",
            "credibility": "[未标注]",
            "multi_source": "[事实-占位]",
            "context": context[:80],
        })

    return table


def _render_challenge_a_v2_markdown(
    target, identified_competitors, fact_check_table,
    competitor_verification, data_range_check, hallucination_list,
    multi_source, hallucination_count, conflict_count,
    total_data_points, passed
) -> str:
    """生成 V2.0 防幻觉 markdown"""
    status_icon = "✅" if passed else "⚠️"
    status_text = "通过（防幻觉）" if passed else "未通过（存在幻觉或冲突）"

    md = f"\n\n## 八、质疑节点 A V2.0 · 横向对标防幻觉核查\n\n"
    md += f"> **核查结论**：{status_icon} **{status_text}**  \n"
    md += f"> 数据点 {total_data_points} / 幻觉 {hallucination_count} / "
    md += f"冲突 {conflict_count}（门槛：幻觉=0 且 冲突<5）\n\n"

    # 8.1 对标公司可验证性
    md += "### 8.1 对标公司可验证性核查\n\n"
    md += "| 对标公司 | 股票代码 | 来源 | 可验证 | 标注 |\n"
    md += "|---------|---------|------|--------|------|\n"
    for cv in competitor_verification:
        icon = "✅" if cv.get("verifiable") else "❌"
        md += f"| {cv['name']} | {cv['code']} | {cv.get('source', '')} | "
        md += f"{icon} | {cv.get('label', '')} |\n"

    # 8.2 事实核查表
    md += "\n### 8.2 横向事实核查表\n\n"
    md += "| 数据点 | 类别 | 来源标注 | 可信度 | 多源验证 | 上下文 |\n"
    md += "|--------|------|----------|--------|----------|--------|\n"
    for row in fact_check_table[:20]:  # 前 20
        md += f"| {row['data_point']} | {row['category']} | "
        md += f"{row['source'][:20]} | {row['credibility'][:10]} | "
        md += f"{row['multi_source']} | {row['context'][:40]} |\n"
    if len(fact_check_table) > 20:
        md += f"| ... | 共 {len(fact_check_table)} 项，已截断显示 |  |  |  |  |\n"

    # 8.3 多源比对（金融）
    md += "\n### 8.3 多源比对结果（金融数据 · iFind 实接口）\n\n"
    financial_verification = multi_source.get("financial", {})
    md += f"- 已验证: {financial_verification.get('verified_points', 0)} 项\n"
    md += f"- **冲突**: {financial_verification.get('mismatched_points', 0)} 项\n"
    md += f"- 待核实: {financial_verification.get('unverified_points', 0)} 项\n\n"

    if financial_verification.get("details"):
        md += "<details><summary>查看详细比对（前 10）</summary>\n\n"
        for d in financial_verification["details"][:10]:
            label = d.get("label", "")
            dp = d.get("data_point", "")
            cat = d.get("category", "")
            excerpt = d.get("source_excerpt", "")[:60]
            md += f"- {label} **{dp}** ({cat}) - {excerpt}\n"
        md += "\n</details>\n\n"

    # 8.4 数据范围核实
    md += "### 8.4 数据范围核实\n\n"
    if data_range_check:
        md += "| 数据点 | 类别 | 类型 | 说明 | 标注 |\n"
        md += "|--------|------|------|------|------|\n"
        for issue in data_range_check:
            md += f"| {issue['data_point']} | {issue['category']} | "
            md += f"{issue['type']} | {issue['note']} | {issue['label']} |\n"
    else:
        md += "无异常数据。\n"

    # 8.5 横向数据幻觉清单
    md += "\n### 8.5 横向数据幻觉清单\n\n"
    if hallucination_list:
        md += f"共 {len(hallucination_list)} 项幻觉：\n\n"
        for i, h in enumerate(hallucination_list[:15], 1):
            md += f"{i}. **{h['type']}** - `{h['data_point']}` ({h['category']}) "
            md += f"{h['label']}  \n"
            md += f"   上下文：{h.get('context', '')[:80]}\n"
        if len(hallucination_list) > 15:
            md += f"\n（还有 {len(hallucination_list) - 15} 项已截断）\n"
    else:
        md += "✅ 无幻觉。\n"

    md += f"\n---\n\n"
    md += f"**【操作说明】**\n"
    md += f"- 本章节由 HV-Challenge-A V2.0 防幻觉模块生成（与 B V2.0 一致设计）\n"
    md += f"- 实接口：iFind 投研（金融数据）+ SearXNG（事实性数据占位）\n"
    md += f"- 门槛：幻觉数 = 0 且 冲突数 < 5\n"
    md += f"- 嫁接位置：纵横分析法【横向 lateral】阶段之后\n\n"

    return md


# ============================================================
# CLI
# ============================================================

def attach_challenge_a_v2_to_report(
    lateral_md_path: str,
    target: str = "标的",
    competitors: Optional[List[str]] = None,
) -> str:
    """读取横向报告 → 跑质疑 A V2.0 → 输出增强版"""
    p = Path(lateral_md_path)
    if not p.exists():
        raise FileNotFoundError(lateral_md_path)

    lateral_text = p.read_text(encoding="utf-8")
    result = run_challenge_a_v2(target, lateral_text, competitors)

    new_md = lateral_text + result["markdown"]

    output_path = p.parent / f"{p.stem}_with_challenge_a_v2.md"
    output_path.write_text(new_md, encoding="utf-8")

    print(f"[HV-Challenge-A-V2] ✅ 输出：{output_path}", file=sys.stderr)
    return str(output_path)


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser(description="HV-Challenge-A V2.0 横向对标防幻觉")
    ap.add_argument("--md", required=True, help="横向 lateral 报告 markdown 路径")
    ap.add_argument("--target", default="标的", help="研究目标")
    ap.add_argument("--competitors", help="竞品列表（逗号分隔）")
    args = ap.parse_args()

    competitors = (
        [c.strip() for c in args.competitors.split(",")] if args.competitors else None
    )
    out = attach_challenge_a_v2_to_report(args.md, args.target, competitors)
    print(out)