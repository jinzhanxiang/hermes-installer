#!/usr/bin/env python3
"""
hv-data-quality-class.py — 纵横分析法 V3.49 数据源分级 + 自动重新核实（V3 极简版）
"""
import re
import json
import argparse
import subprocess
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple

# A 级数据源（专业金融）
A_LEVEL_PATTERNS = {
    "iFind": [r"\[iFind[:\s\-]", r"\[同花顺iFind[:\s\-]"],
    "MX": [r"\[MX[:\s\-]", r"\[妙想[:\s\-]"],
    "AKShare": [r"\[AKShare[:\s\-]"],
    "Tushare": [r"\[Tushare[:\s\-]"],
    "港交所": [r"\[港交所[:\s\-]", r"\[HKEx[:\s\-]"],
    "巨潮": [r"\[巨潮[:\s\-]", r"\[cninfo[:\s\-]"],
}

# B 级数据源（财经媒体）
B_LEVEL_PATTERNS = {
    "财联社": [r"\[财联社[:\s\-]"],
    "证券时报": [r"\[证券时报[:\s\-]"],
    "界面": [r"\[界面[:\s\-]"],
    "证券之星": [r"\[证券之星[:\s\-]"],
    "同花顺": [r"\[同花顺[:\s\-]"],
    "雪球": [r"\[雪球[:\s\-]"],
    "东方财富": [r"\[东方财富[:\s\-]"],
    "凤凰": [r"\[凤凰[:\s\-]"],
    "搜狐": [r"\[搜狐[:\s\-]"],
    "新浪": [r"\[新浪[:\s\-]"],
}

# C 级数据源（通用搜索）
C_LEVEL_PATTERNS = {
    "tavily": [r"\[tavily[:\s\-]", r"tavily_search"],
    "web_search": [r"\[web_search[:\s\-]"],
    "百度": [r"\[百度[:\s\-]"],
}


def classify_data_source(text: str) -> Tuple[str, str]:
    """分类单个文本中的数据源级别（V3 简化版）

    支持两种输入格式：
    1. 带方括号："[A-iFind-Finance: xxx]"（用户从报告里直接复制）
    2. 不带方括号："A-iFind-Finance: xxx"（analyze_report 内部调用）

    Returns:
        (level, source_name) 例如 ("A", "iFind") / ("B", "财联社") / ("C", "tavily") / ("Unknown", "")
    """
    text_lower = text.lower()

    # 1. 优先匹配级别前缀 [A- / [B- / [C- （允许带或不带方括号）
    # 正则：可选的 [ + A/B/C + - 或 级
    level_match = re.match(r"\[?\s*([ABC])\s*[\-级]", text)
    if level_match:
        level = level_match.group(1)
        # 在合并字典中找数据源关键字
        all_sources = {**A_LEVEL_PATTERNS, **B_LEVEL_PATTERNS, **C_LEVEL_PATTERNS}
        for source in all_sources.keys():
            keyword = source.lower().replace(" ", "").replace("iex", "").strip()
            if len(keyword) >= 2 and keyword in text_lower:
                return (level, source)
        return (level, "未指定")

    # 2. 无级别前缀：按正则精确匹配（兼容带/不带方括号）
    for source, patterns in A_LEVEL_PATTERNS.items():
        for pattern in patterns:
            # 修改 pattern 允许可选的 [ 前缀
            pattern_loose = pattern.replace(r"\[", r"\[?\s*")
            if re.search(pattern_loose, text, re.IGNORECASE):
                return ("A", source)
    for source, patterns in B_LEVEL_PATTERNS.items():
        for pattern in patterns:
            pattern_loose = pattern.replace(r"\[", r"\[?\s*")
            if re.search(pattern_loose, text, re.IGNORECASE):
                return ("B", source)
    for source, patterns in C_LEVEL_PATTERNS.items():
        for pattern in patterns:
            pattern_loose = pattern.replace(r"\[", r"\[?\s*")
            if re.search(pattern_loose, text, re.IGNORECASE):
                return ("C", source)
    return ("Unknown", "")


def analyze_report(report_path: str) -> Dict[str, Any]:
    """分析报告 MD 文件的数据源使用情况"""
    path = Path(report_path)
    if not path.exists():
        return {"error": f"报告文件不存在: {report_path}"}

    content = path.read_text(encoding="utf-8")
    all_citations = re.findall(r"\[([^\]]+)\]", content)

    by_level = {"A": 0, "B": 0, "C": 0, "Unknown": 0}
    by_source = {}
    for citation in all_citations:
        level, source = classify_data_source(citation)
        by_level[level] = by_level.get(level, 0) + 1
        if source and source != "未指定":
            by_source[source] = by_source.get(source, 0) + 1

    total = sum(by_level.values())
    a_ratio = by_level.get("A", 0) / total if total > 0 else 0
    b_ratio = by_level.get("B", 0) / total if total > 0 else 0
    c_ratio = by_level.get("C", 0) / total if total > 0 else 0

    warnings = []
    recommendations = []
    if a_ratio < 0.30:
        warnings.append(f"🔴 P0: A 级数据源占比仅 {a_ratio*100:.1f}%，未达 30% 门槛")
        recommendations.append("建议补充 iFind Finance / MX / 港交所原文核实核心财务数据")
    if c_ratio > 0.20:
        warnings.append(f"⚠️ C 级数据源占比 {c_ratio*100:.1f}%，超过 20% 红线")
        recommendations.append("建议将 C 级（tavily/web_search）来源替换为 iFind Finance / 公告原文")

    critical_passed = not any("🔴" in w for w in warnings)

    return {
        "file_path": str(path.absolute()),
        "file_size_bytes": path.stat().st_size,
        "total_citations": total,
        "by_level": by_level,
        "by_source": dict(sorted(by_source.items(), key=lambda x: -x[1])),
        "A_ratio_pct": f"{a_ratio*100:.1f}%",
        "B_ratio_pct": f"{b_ratio*100:.1f}%",
        "C_ratio_pct": f"{c_ratio*100:.1f}%",
        "critical_passed": critical_passed,
        "warnings": warnings,
        "recommendations": recommendations,
        "check_time": datetime.now().isoformat(),
    }


def format_markdown(result: Dict[str, Any]) -> str:
    if "error" in result:
        return f"❌ 错误：{result['error']}"
    lines = ["## 📊 数据源质量审计报告\n",
             f"**文件**：{result['file_path']}",
             f"**文件大小**：{result['file_size_bytes']:,} 字节",
             f"**总引用点**：{result['total_citations']}\n",
             "### 数据源分级统计",
             "| 级别 | 数量 | 占比 |",
             "|:----:|:----:|:----:|",
             f"| **A 级（专业金融）** | {result['by_level'].get('A', 0)} | **{result['A_ratio_pct']}** |",
             f"| **B 级（财经媒体）** | {result['by_level'].get('B', 0)} | {result['B_ratio_pct']} |",
             f"| **C 级（通用搜索）** | {result['by_level'].get('C', 0)} | {result['C_ratio_pct']} |",
             f"| Unknown | {result['by_level'].get('Unknown', 0)} | - |\n",
             "### 判定：" + ("✅ 通过" if result["critical_passed"] else "❌ 未通过") + "\n"]
    if result["warnings"]:
        lines.append("### ⚠️ 警告")
        for w in result["warnings"]:
            lines.append(f"- {w}")
        lines.append("")
    if result["recommendations"]:
        lines.append("### 💡 修复建议")
        for r in result["recommendations"]:
            lines.append(f"- {r}")
        lines.append("")
    lines.append(f"**检查时间**：{result['check_time']}")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=str, help="报告 MD 文件路径")
    parser.add_argument("--json", action="store_true", help="输出 JSON")
    parser.add_argument("--strict", action="store_true", help="严格模式")
    args = parser.parse_args()
    if args.report:
        result = analyze_report(args.report)
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(format_markdown(result))
        if args.strict and not result.get("critical_passed", False):
            sys.exit(1)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()