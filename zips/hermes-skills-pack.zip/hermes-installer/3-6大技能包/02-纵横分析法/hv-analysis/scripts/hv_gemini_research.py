#!/usr/bin/env python3
"""
融合脚本：hv-analysis + gemini-deep-research
用 Gemini Deep Research Agent 驱动 hv-analysis 的联网信息收集步骤

用法：
  python3 scripts/hv_gemini_research.py --query "研究XXX" --phase longitudinal
  python3 scripts/hv_gemini_research.py --query "研究XXX" --phase lateral
  python3 scripts/hv_gemini_research.py --query "研究XXX" --phase cross_insight

环境变量：
  GEMINI_API_KEY  - Gemini API 密钥（必须）
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
import requests

API_BASE = "https://generativelanguage.googleapis.com/v1beta"
AGENT_MODEL = "deep-research-pro-preview-12-2025"


def create_interaction(api_key, query, output_format=None, file_search_store=None):
    headers = {
        "Content-Type": "application/json",
        "x-goog-api-key": api_key
    }
    
    payload = {
        "input": query,
        "agent": AGENT_MODEL,
        "background": True
    }
    
    if output_format:
        payload["input"] = f"{query}\n\nFormat the output as follows:\n{output_format}"
    
    if file_search_store:
        payload["tools"] = [{
            "type": "file_search",
            "file_search_store_names": [file_search_store]
        }]
    
    response = requests.post(
        f"{API_BASE}/interactions",
        headers=headers,
        json=payload
    )
    
    if response.status_code != 200:
        print(f"Error creating interaction: {response.status_code}", file=sys.stderr)
        print(response.text, file=sys.stderr)
        sys.exit(1)
    
    return response.json()


def poll_interaction(api_key, interaction_id, stream=False):
    headers = {
        "x-goog-api-key": api_key
    }
    
    while True:
        response = requests.get(
            f"{API_BASE}/interactions/{interaction_id}",
            headers=headers
        )
        
        if response.status_code != 200:
            print(f"Error polling interaction: {response.status_code}", file=sys.stderr)
            print(response.text, file=sys.stderr)
            sys.exit(1)
        
        data = response.json()
        status = data.get("status", "UNKNOWN")
        
        if stream:
            if "statusMessage" in data:
                print(f"[{status}] {data['statusMessage']}", file=sys.stderr)
        
        if status == "completed":
            return data
        elif status == "failed":
            print(f"Research failed: {data.get('error', 'Unknown error')}", file=sys.stderr)
            sys.exit(1)
        
        time.sleep(10)


def extract_report(interaction_data):
    if "output" in interaction_data:
        output = interaction_data["output"]
        if isinstance(output, dict) and "text" in output:
            return output["text"]
        elif isinstance(output, str):
            return output
    
    messages = interaction_data.get("messages", [])
    for msg in reversed(messages):
        if msg.get("role") == "model" and "parts" in msg:
            for part in msg["parts"]:
                if "text" in part:
                    return part["text"]
    
    return None


# ── HV-Analysis 专项 Query 构造 ──────────────────────────────────────────────

def build_longitudinal_query(target, research_type):
    """纵向信息收集 Query（起源、发展历程、关键事件、融资、战略转向）"""
    type_hints = {
        "产品": "产品发展历程、版本迭代、技术路线演进、里程碑事件",
        "公司": "公司发展历程、融资历程、关键战略转向、并购/上市、重要产品发布",
        "概念": "概念起源、理论演变、重要时间节点、范式转换",
        "人物": "人物职业轨迹、关键决策、里程碑事件、教育背景",
    }
    hint = type_hints.get(research_type, "发展历程")
    return (
        f"请对【{target}】进行深度纵向（历时性）研究。\n\n"
        f"研究类型：{research_type}。\n\n"
        f"请系统收集以下信息（按时间顺序组织）：\n"
        f"1. 起源与诞生背景（何时、何地、创始人/发起方、初始动机）\n"
        f"2. 关键发展节点（每次重大变化的时间、事件、决策）\n"
        f"3. {hint}\n"
        f"4. 重大战略转向或转型（如有）\n"
        f"5. 截至当前的最新状态\n\n"
        f"信息来源优先级：一手来源 > 二手来源（官方公告 > 权威媒体原创 > 转载聚合）。\n"
        f"请提供尽可能完整的时间线，标注每个节点的信息来源。"
    )


def build_lateral_query(target, research_type,竞品列表=None):
    """横向信息收集 Query（竞品对比、市场份额、用户口碑）"""
    type_hints = {
        "产品": "产品功能对比、用户体验、优劣势分析",
        "公司": "商业模式对比、市场份额、核心竞争力、盈利能力",
        "概念": "相关概念区分、理论流派对比",
        "人物": "同领域人物对比、成就对比",
    }
    hint = type_hints.get(research_type, "竞争分析")
    竞品提示 = f"\n重点竞品参考：{', '.join(竞品列表)}" if 竞品列表 else ""
    
    return (
        f"请对【{target}】进行深度横向（共时性）竞品研究。\n\n"
        f"研究类型：{research_type}。\n\n"
        f"请系统收集以下信息：\n"
        f"1. 竞品识别（{target}的主要竞争对手有哪些，各自定位如何）\n"
        f"2. {hint}\n"
        f"3. 市场份额与行业地位（各竞品市场占比、用户规模）\n"
        f"4. 用户视角（真实口碑、评价、用户社区讨论）\n"
        f"5. 各竞品生态位分析与趋势判断{竞品提示}\n\n"
        f"信息来源优先级：一手来源 > 二手来源（官方博客 > 权威媒体原创 > 转载聚合）。\n"
        f"请提供数据化的对比表格，标注每个数据点的来源。"
    )


def build_cross_insight_query(target, research_type, longitudinal_summary, lateral_summary):
    """横纵交汇洞察 Query（综合判断、未来剧本）"""
    return (
        f"请对【{target}】进行横纵交汇综合洞察分析。\n\n"
        f"研究类型：{research_type}。\n\n"
        f"已完成资料：\n"
        f"--- 纵向（历时）摘要 ---\n{longitudinal_summary[:2000]}\n\n"
        f"--- 横向（共时）摘要 ---\n{lateral_summary[:2000]}\n\n"
        f"请基于上述材料，产出以下分析：\n"
        f"1. 历史如何塑造了【{target}】当下的竞争位置\n"
        f"2. 优势和劣势各自的历史根源\n"
        f"3. 未来三个剧本：最可能的、最危险的、最乐观的\n"
        f"4. 综合新判断（不是前述内容的缩编，而是基于横纵交叉产生的新洞察）\n\n"
        f"要求：敢下判断，层层剥开，有洞见深度，避免AI味套话。"
    )


# ── 输出格式化模板 ────────────────────────────────────────────────────────────

LONGITUDINAL_FORMAT = """
请按以下结构输出纵向研究报告：

## 一、起源与诞生背景
[内容，含具体时间/地点/人物]

## 二、发展历程时间线
[按时间顺序排列的完整时间线，含每个节点的信息来源]

## 三、关键决策与逻辑
[每个关键节点的选择原因分析]

## 四、阶段划分
[萌芽期/增长期/转型期等各阶段特征]

## 五、信息来源索引
[所有引用的数据源，按优先级排序]
"""

LATERAL_FORMAT = """
请按以下结构输出横向竞品研究报告：

## 一、竞品全景图
[识别出的所有主要竞品及其定位]

## 二、多维度对比表
[用表格呈现核心差异（技术路线/产品形态/商业模式等）]

## 三、市场份额与行业地位
[数据化呈现，含来源]

## 四、用户视角分析
[真实口碑、评价、用户社区讨论摘要]

## 五、生态位与趋势判断
[各竞品在行业版图中的位置及未来趋势]

## 六、信息来源索引
[所有引用的数据源]
"""

CROSS_INSIGHT_FORMAT = """
请按以下结构输出横纵交汇洞察：

## 一、历史纵深与竞争位置
[历史如何塑造了当下的竞争位置]

## 二、优势与劣势的历史根源
[基于时间线的深度分析]

## 三、未来三个剧本
### 最可能的剧本：
[分析]

### 最危险的剧本：
[分析]

### 最乐观的剧本：
[分析]

## 四、横纵交汇新洞察
[基于纵横向交叉产生的新判断，不是前述内容的缩写]

## 五、风险提示
[基于历史规律和横向对比识别的潜在风险]
"""


def main():
    parser = argparse.ArgumentParser(
        description="HV-Analysis × Gemini Deep Research 融合研究引擎"
    )
    parser.add_argument("--query", required=True, help="研究对象（如：公司名/产品名）")
    parser.add_argument("--phase", required=True,
                        choices=["longitudinal", "lateral", "cross_insight"],
                        help="研究阶段：longitudinal=纵向,lateral=横向,cross_insight=横纵交汇")
    parser.add_argument("--type", default="公司",
                        choices=["产品", "公司", "概念", "人物"],
                        help="研究对象类型")
    parser.add_argument("--competitors", help="已知竞品列表（逗号分隔）")
    parser.add_argument("--longitudinal-summary", help="cross_insight阶段：纵向摘要（文件路径或文本）")
    parser.add_argument("--lateral-summary", help="cross_insight阶段：横向摘要（文件路径或文本）")
    parser.add_argument("--stream", action="store_true", help="显示进度更新")
    parser.add_argument("--output-dir", default=".",
                        help="结果输出目录")
    parser.add_argument("--api-key", help="Gemini API key（覆盖环境变量）")
    parser.add_argument("--format", help="自定义输出格式（覆盖默认模板）")
    
    args = parser.parse_args()
    
    # API Key
    api_key = args.api_key or os.environ.get("GEMINI_API_KEY")
    if not api_key:
        print("Error: 缺少 GEMINI_API_KEY", file=sys.stderr)
        print("请设置环境变量：export GEMINI_API_KEY=<your_key>", file=sys.stderr)
        sys.exit(1)
    
    # 构造 Query
    if args.phase == "longitudinal":
        query = build_longitudinal_query(args.query, args.type)
        output_fmt = args.format or LONGITUDINAL_FORMAT
    elif args.phase == "lateral":
        竞品列表 = [c.strip() for c in args.competitors.split(",")] if args.competitors else None
        query = build_lateral_query(args.query, args.type, 竞品列表)
        output_fmt = args.format or LATERAL_FORMAT
    else:  # cross_insight
        long_sum = ""
        lat_sum = ""
        if args.longitudinal_summary:
            p = Path(args.longitudinal_summary)
            long_sum = p.read_text() if p.exists() else args.longitudinal_summary
        if args.lateral_summary:
            p = Path(args.lateral_summary)
            lat_sum = p.read_text() if p.exists() else args.lateral_summary
        query = build_cross_insight_query(args.query, args.type, long_sum, lat_sum)
        output_fmt = args.format or CROSS_INSIGHT_FORMAT
    
    print(f"[HV-Gemini] 阶段: {args.phase} | 研究对象: {args.query}", file=sys.stderr)
    
    # 启动 Gemini Deep Research
    interaction = create_interaction(api_key, query, output_format=output_fmt)
    interaction_id = interaction.get("id")
    if not interaction_id:
        print(f"Error: 无法创建 interaction: {interaction}", file=sys.stderr)
        sys.exit(1)
    print(f"[HV-Gemini] Interaction started: {interaction_id}", file=sys.stderr)
    
    # 轮询结果
    print("[HV-Gemini] 深度研究中（可能需要数分钟）...", file=sys.stderr)
    result = poll_interaction(api_key, interaction_id, stream=args.stream)
    
    # 提取报告
    report = extract_report(result)
    if not report:
        print("Warning: 无法从响应中提取报告文本", file=sys.stderr)
        report = json.dumps(result, indent=2)
    
    # 保存结果
    timestamp = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    phase_name = {"longitudinal": "long", "lateral": "lat", "cross_insight": "cross"}.get(args.phase, args.phase)
    md_path = output_dir / f"hv-{phase_name}-{timestamp}.md"
    json_path = output_dir / f"hv-{phase_name}-{timestamp}.json"
    
    md_path.write_text(report)
    json_path.write_text(json.dumps(result, indent=2))
    
    print(f"\n[HV-Gemini] ✅ 研究完成！", file=sys.stderr)
    print(f"报告: {md_path}", file=sys.stderr)
    print(f"完整数据: {json_path}", file=sys.stderr)
    
    # 输出到 stdout
    print(report)


if __name__ == "__main__":
    main()