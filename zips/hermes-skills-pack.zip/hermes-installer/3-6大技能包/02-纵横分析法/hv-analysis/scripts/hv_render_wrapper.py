#!/usr/bin/env python3
"""
hv_render_wrapper.py
─────────────────────
纵横分析法（hv-analysis）→ HTML 渲染包装层。

设计哲学：
  1. Agent 执行 hv-analysis 产出的 .md 报告
     → 自动用 CC 基线简洁模板渲染 .html（hv_simple_render.py）
     → 不需要手动执行渲染命令

  2. 支持批量渲染：HV 三阶段（longitudinal/lateral/cross_insight）的 3 份报告一键转 HTML

  3. 可被以下入口调用：
     - Agent 流程内（Phase 5 末尾自动调用）
     - 命令行独立调用：`python3 hv_render_wrapper.py report.md`
     - shell 入口：`bash scripts/hv-render.sh`

用法：
  # 单文件渲染
  python3 hv_render_wrapper.py /path/to/report.md

  # 批量渲染整个目录
  python3 hv_render_wrapper.py /path/to/output-dir/ --batch

  # 在 hv-full 收尾时调用（自动找最新 .md）
  python3 hv_render_wrapper.py --latest

  # 干运行（不写入文件）
  python3 hv_render_wrapper.py /path/to/report.md --dry-run
"""
import os
import sys
import argparse
from pathlib import Path
from typing import Optional, List

# ── Path Resolution ───────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent.parent.parent
HV_SIMPLE_RENDER = PROJECT_ROOT / "scripts" / "hv_simple_render.py"

# Python 3.11（带 markdown 库）
PYTHON_CMD = "/Library/Frameworks/Python.framework/Versions/3.11/bin/python3"


def _import_simple_render():
    """
    在 HV 进程内直接 import hv_simple_render.render_report()，避免子进程开销。

    返回 (render_func, None) 或 (None, error_msg)
    """
    try:
        sys.path.insert(0, str(PROJECT_ROOT / "scripts"))
        from hv_simple_render import render_report
        return render_report, None
    except Exception as e:
        return None, str(e)


def _subprocess_render(md_file: str, html_file: Optional[str] = None) -> dict:
    """
    子进程调用：`python3 hv_simple_render.py file.md -o output.html`

    用于：
    - 不同 Python 环境（HV 自带 venv 没有 markdown）
    - 隔离错误（HV 主流程不中断）
    """
    import subprocess

    cmd = [PYTHON_CMD, str(HV_SIMPLE_RENDER), md_file]
    if html_file:
        cmd += ["-o", html_file]

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        return {
            "ok": proc.returncode == 0,
            "stdout": proc.stdout.strip(),
            "stderr": proc.stderr.strip(),
            "html_path": html_file or str(Path(md_file).with_suffix(".html")),
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout 30s", "html_path": html_file}
    except FileNotFoundError as e:
        return {"ok": False, "error": str(e), "html_path": html_file}


def render_md(md_file: str, html_file: Optional[str] = None,
              verbose: bool = True) -> dict:
    """
    单一 .md → .html 入口（使用 CC 基线简洁模板）。

    策略：
    1. 优先 in-process import（快速，无子进程开销）
    2. 失败则 fallback 到子进程方式
    """
    md_path = Path(md_file).expanduser().resolve()

    if not md_path.exists():
        return {"ok": False, "error": f"file not found: {md_path}", "md_path": str(md_path)}

    html_path = (
        Path(html_file).expanduser().resolve()
        if html_file
        else md_path.with_suffix(".html")
    )

    # 策略 1：in-process
    render_fn, err = _import_simple_render()
    if render_fn:
        try:
            result = render_fn(str(md_path), str(html_path), verbose=verbose)
            return {
                "ok": True,
                "method": "in-process",
                "md_path": str(md_path),
                "html_path": str(html_path),
                "md_size": result["md_size"],
                "html_size": result["html_size"],
                "title": result["title"],
            }
        except Exception as e:
            if verbose:
                print(f"⚠️  in-process 失败 ({e})，降级到子进程", file=sys.stderr)

    # 策略 2：子进程
    result = _subprocess_render(str(md_path), str(html_path))
    if verbose and result.get("stderr"):
        print(f"[stderr] {result['stderr']}", file=sys.stderr)
    return result


def render_batch(directory: str, pattern: str = "*.md",
                 verbose: bool = True) -> List[dict]:
    """
    批量渲染目录下所有 .md 文件。

    用于：HV 三阶段完成后一次性渲染
    """
    d = Path(directory).expanduser().resolve()
    if not d.exists() or not d.is_dir():
        return [{"ok": False, "error": f"directory not found: {d}"}]

    results = []
    for md_file in sorted(d.glob(pattern)):
        if md_file.name.startswith("."):
            continue  # 跳过隐藏文件
        r = render_md(str(md_file), verbose=verbose)
        results.append(r)
        if verbose:
            status = "✅" if r.get("ok") else "❌"
            html = r.get("html_path", "—")
            size = r.get("html_size", 0)
            print(f"  {status} {md_file.name} → {html} ({size:,}B)", file=sys.stderr)

    return results


def render_latest(output_dir: str = None, verbose: bool = True) -> dict:
    """
    渲染 output_dir 下最新修改的 .md 文件。

    用于：Agent 全部阶段收尾自动调用
    """
    if not output_dir:
        output_dir = str(PROJECT_ROOT)
    d = Path(output_dir).expanduser().resolve()

    md_files = sorted(d.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not md_files:
        return {"ok": False, "error": f"no .md files in {d}"}

    latest = md_files[0]
    if verbose:
        print(f"[HV-Wrap] 🎯 Latest: {latest.name}", file=sys.stderr)
    return render_md(str(latest), verbose=verbose)


# ── CLI ───────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="HV → HTML 渲染包装层（V3.42.4 学术研究增强）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例：
  # 单文件
  python3 hv_render_wrapper.py /path/to/report.md

  # 批量渲染整个目录（HV 三阶段报告）
  python3 hv_render_wrapper.py /path/to/output/ --batch

  # 自动找最新的 .md
  python3 hv_render_wrapper.py --latest --output-dir /path/to/output/

  # 干运行
  python3 hv_render_wrapper.py /path/to/report.md --dry-run
""",
    )

    parser.add_argument("target", nargs="?",
                        help="单个 .md 文件 或 目录路径（与 --batch 配合）")
    parser.add_argument("--batch", action="store_true",
                        help="批量渲染目录下所有 .md")
    parser.add_argument("--latest", action="store_true",
                        help="自动渲染最新修改的 .md")
    parser.add_argument("--output-dir",
                        help="--latest 模式下的搜索目录")
    parser.add_argument("--dry-run", action="store_true",
                        help="仅打印计划，不实际写入")
    parser.add_argument("-o", "--output",
                        help="指定输出 HTML 文件（默认与 .md 同名同目录）")
    parser.add_argument("-q", "--quiet", action="store_true",
                        help="安静模式（HV 内部调用）")

    args = parser.parse_args()

    if args.dry_run:
        print(f"[DRY-RUN] target={args.target} batch={args.batch} latest={args.latest}")
        return 0

    verbose = not args.quiet

    # 模式 1：批量
    if args.batch and args.target:
        results = render_batch(args.target, verbose=verbose)
        ok_count = sum(1 for r in results if r.get("ok"))
        print(f"\n[HV-Wrap] ✅ {ok_count}/{len(results)} 渲染成功")
        return 0 if ok_count == len(results) else 1

    # 模式 2：找最新
    if args.latest:
        result = render_latest(args.output_dir, verbose=verbose)
        if verbose:
            if result.get("ok"):
                print(f"✅ {result['html_path']}")
            else:
                print(f"❌ {result.get('error')}")
        return 0 if result.get("ok") else 1

    # 模式 3：单文件
    if args.target:
        result = render_md(args.target, args.output, verbose=verbose)
        if verbose:
            if result.get("ok"):
                print(f"✅ HTML: {result['html_path']} ({result.get('html_size', 0):,}B)")
            else:
                print(f"❌ {result.get('error') or result.get('stderr', 'unknown')}")
        return 0 if result.get("ok") else 1

    # 没参数：打印帮助
    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
