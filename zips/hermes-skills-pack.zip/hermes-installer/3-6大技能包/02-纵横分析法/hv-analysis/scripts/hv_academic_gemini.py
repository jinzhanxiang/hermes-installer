#!/usr/bin/env python3
"""
融合脚本：hv-analysis × gemini-deep-research × academic-deep-research-pro

三层融合：
  Layer 1 — hv-analysis:     横纵分析法框架（纵向/横向/交汇）
  Layer 2 — gemini-deep-research: Gemini Deep Research Agent 驱动
  Layer 3 — academic-deep-research-pro: 双周期协议 + 证据层级 + APA引注 + 置信度标注

用法：
  python3 scripts/hv_academic_gemini.py --query "研究XXX" --phase all --type 公司
  python3 scripts/hv_academic_gemini.py --query "研究XXX" --phase longitudinal --type 公司 --stream

环境变量：
  GEMINI_API_KEY  - Gemini API 密钥（必须）
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
import requests

API_BASE = "https://generativelanguage.googleapis.com/v1beta"
AGENT_MODEL = "deep-research-pro-preview-12-2025"

# ── Evidence Hierarchy（学术深度研究层）────────────────────────────────────
# Level 1 最高 → Level 7 最低
EVIDENCE_HIERARCHY = [
    "Systematic reviews & meta-analyses",
    "Randomized controlled trials",
    "Cohort / longitudinal studies",
    "Expert consensus / guidelines",
    "Cross-sectional / observational studies",
    "Expert opinion / editorials",
    "Media reports / blogs",
]

# 置信度标注
CONFIDENCE_LABEL = {
    "HIGH": "Multiple high-quality sources agree",
    "MEDIUM": "Limited or mixed evidence",
    "LOW": "Single source or preliminary",
    "SPECULATIVE": "Hypothesis or emerging area",
}


def create_interaction(api_key, query, output_format=None, file_search_store=None):
    headers = {
        "Content-Type": "application/json",
        "x-goog-api-key": api_key
    }
    payload = {
        "input": query,
        "agent": AGENT_MODEL,
        "background": True
    }
    if output_format:
        payload["input"] = f"{query}\n\nFormat the output as follows:\n{output_format}"
    if file_search_store:
        payload["tools"] = [{
            "type": "file_search",
            "file_search_store_names": [file_search_store]
        }]
    response = requests.post(f"{API_BASE}/interactions", headers=headers, json=payload)
    if response.status_code != 200:
        print(f"Error creating interaction: {response.status_code}", file=sys.stderr)
        print(response.text, file=sys.stderr)
        sys.exit(1)
    return response.json()


def poll_interaction(api_key, interaction_id, stream=False):
    headers = {"x-goog-api-key": api_key}
    while True:
        response = requests.get(f"{API_BASE}/interactions/{interaction_id}", headers=headers)
        if response.status_code != 200:
            print(f"Error polling interaction: {response.status_code}", file=sys.stderr)
            print(response.text, file=sys.stderr)
            sys.exit(1)
        data = response.json()
        status = data.get("status", "UNKNOWN")
        if stream:
            msg = data.get("statusMessage", "")
            if msg:
                print(f"  [{status}] {msg}", file=sys.stderr)
        if status == "completed":
            return data
        elif status == "failed":
            print(f"Research failed: {data.get('error', 'Unknown error')}", file=sys.stderr)
            sys.exit(1)
        time.sleep(10)


def extract_report(interaction_data):
    if "output" in interaction_data:
        output = interaction_data["output"]
        if isinstance(output, dict) and "text" in output:
            return output["text"]
        elif isinstance(output, str):
            return output
    messages = interaction_data.get("messages", [])
    for msg in reversed(messages):
        if msg.get("role") == "model" and "parts" in msg:
            for part in msg["parts"]:
                if "text" in part:
                    return part["text"]
    return None


# ── Query Builders（横纵分析法 × 学术深度研究双周期协议）────────────────────────

def build_longitudinal_query_v2(target, research_type):
    """
    纵向研究双周期协议：
    - Cycle 1 (Landscape): 宽泛搜索，还原发展全貌
    - Cycle 2 (Deep): 聚焦关键节点，获取一手来源
    输出含证据层级+置信度标注指令
    """
    type_hints = {
        "产品": "产品发展历程、版本迭代、技术路线演进、里程碑事件",
        "公司": "公司发展历程、融资历程、关键战略转向、并购/上市、重要产品发布",
        "概念": "概念起源、理论演变、重要时间节点、范式转换",
        "人物": "人物职业轨迹、关键决策、里程碑事件、教育背景",
    }
    hint = type_hints.get(research_type, "发展历程")
    return (
        f"# 【纵向研究 · 双周期协议】研究对象：{target}（类型：{research_type}）\n\n"
        f"## Cycle 1 — Landscape Analysis（全景扫描）\n"
        f"请对【{target}】进行宽泛搜索，系统还原其从诞生至今的完整发展全貌。\n\n"
        f"搜索要点：\n"
        f"1. 起源与诞生背景（何时、何地、创始人/发起方、初始动机）\n"
        f"2. 关键发展节点（每次重大变化的时间、事件、决策）\n"
        f"3. {hint}\n"
        f"4. 重大战略转向或转型（如有）\n"
        f"5. 截至当前的最新状态\n\n"
        f"信息来源优先级（证据层级）：\n"
        f"  Level 1 > Level 2 > Level 3 > Level 4 > Level 5 > Level 6 > Level 7\n"
        f"  （系统综述 > 随机对照试验 > 队列研究 > 专家共识 > 横截面研究 > 专家意见 > 媒体报道）\n\n"
        f"## Cycle 2 — Deep Investigation（深度挖掘）\n"
        f"基于 Cycle 1 发现的关键节点和证据缺口，进行针对性深度搜索：\n"
        f"1. 获取一手来源（官方公告、原始论文、年报、财报）\n"
        f"2. 验证 Cycle 1 中的矛盾点和不确定信息\n"
        f"3. 补充证据层级较高的来源\n\n"
        f"## 输出要求\n"
        f"1. 每个结论必须注明：证据来源（含URL）、证据层级（Level 1-7）、置信度标注（[HIGH]/[MEDIUM]/[LOW]/[SPECULATIVE]）\n"
        f"2. 所有矛盾点必须单独说明并给出可能的解释\n"
        f"3. 时间线按时间顺序组织，每个节点注明信息来源\n"
        f"4. 明确标注：哪些是确定的，哪些是推测的（[SPECULATIVE]）\n"
    )


def build_lateral_query_v2(target, research_type, 竞品列表=None):
    """
    横向研究双周期协议：
    - Cycle 1: 竞品全景扫描
    - Cycle 2: 深度对比挖掘
    含市场份额多源验证机制
    """
    type_hints = {
        "产品": "产品功能对比、用户体验、优劣势分析",
        "公司": "商业模式对比、市场份额、核心竞争力、盈利能力",
        "概念": "相关概念区分、理论流派对比",
        "人物": "同领域人物对比、成就对比",
    }
    hint = type_hints.get(research_type, "竞争分析")
    竞品提示 = f"\n重点竞品参考：{', '.join(竞品列表)}" if 竞品列表 else ""
    
    return (
        f"# 【横向研究 · 双周期协议】研究对象：{target}（类型：{research_type}）{竞品提示}\n\n"
        f"## Cycle 1 — Landscape Analysis（竞品全景）\n"
        f"请对【{target}】进行全面的竞品横向分析。\n\n"
        f"搜索要点：\n"
        f"1. 竞品识别（{target}的主要竞争对手有哪些，各自定位如何）\n"
        f"2. {hint}\n"
        f"3. 市场份额与行业地位（各竞品市场占比、用户规模——需多源验证）\n"
        f"4. 用户视角（真实口碑、评价、用户社区讨论）\n"
        f"5. 各竞品生态位分析与趋势判断\n\n"
        f"市场份额验证规则：\n"
        f"  - 每个市场份额数据至少需要2个不同来源验证\n"
        f"  - 若只有单一来源，标注为 [LOW] 置信度\n"
        f"  - 若多源一致，标注为 [HIGH] 置信度\n"
        f"  - 若多源矛盾，分别列出并分析原因\n\n"
        f"信息来源优先级（证据层级）：\n"
        f"  Level 1 > Level 2 > Level 3 > Level 4 > Level 5 > Level 6 > Level 7\n\n"
        f"## Cycle 2 — Deep Investigation（深度对比）\n"
        f"基于 Cycle 1 识别出的竞品格局，进行针对性深度分析：\n"
        f"1. 获取竞品一手数据（财报、年报、官方发布）\n"
        f"2. 验证关键指标（如营收、市占率、毛利率）的多源一致性\n"
        f"3. 深入分析技术路线、商业模式、用户体验差异的根源\n"
        f"4. 识别各竞品的核心优势和脆弱点\n\n"
        f"## 输出要求\n"
        f"1. 对比表格：核心差异（技术路线/产品形态/商业模式等）\n"
        f"2. 每个数据点必须注明来源、证据层级、置信度\n"
        f"3. 矛盾数据单独列出，分析可能原因\n"
        f"4. 每个竞品注明：[HIGH]/[MEDIUM]/[LOW]/[SPECULATIVE] 置信度\n"
    )


def build_cross_insight_query_v2(target, research_type, longitudinal_summary, lateral_summary):
    """
    横纵交汇洞察双周期协议：
    - Cycle 1: 横纵交叉分析
    - Cycle 2: 综合洞察与风险识别
    最终产出学术叙事风格报告（含APA引注格式说明）
    """
    return (
        f"# 【横纵交汇洞察 · 双周期协议】研究对象：{target}（类型：{research_type}）\n\n"
        f"## Cycle 1 — Cross-Section Analysis（横纵交叉）\n"
        f"基于以下纵向和横向研究成果，进行横纵交汇分析。\n\n"
        f"--- 纵向（历时）摘要 ---\n{longitudinal_summary[:3000]}\n\n"
        f"--- 横向（共时）摘要 ---\n{lateral_summary[:3000]}\n\n"
        f"请分析：\n"
        f"1. 历史如何塑造了【{target}】当下的竞争位置\n"
        f"2. 优势和劣势各自的历史根源\n"
        f"3. 横向竞品格局如何影响纵向发展路径选择\n"
        f"4. 关键矛盾点：纵向时间线与横向竞品数据是否有矛盾？如何解释？\n\n"
        f"## Cycle 2 — Deep Insight & Risk（综合洞察与风险）\n"
        f"基于 Cycle 1 横纵交叉结论，产出：\n\n"
        f"1. **未来三个剧本**：\n"
        f"   - 最可能的剧本：[分析，标注置信度[HIGH/MEDIUM/LOW]\n"
        f"   - 最危险的剧本：[分析，标注置信度\n"
        f"   - 最乐观的剧本：[分析，标注置信度\n\n"
        f"2. **综合新洞察**（不是前述内容的缩写，而是横纵交叉产生的新判断）：\n\n"
        f"3. **风险识别**：\n"
        f"   - 历史规律揭示的潜在风险\n"
        f"   - 横向竞品格局带来的威胁\n"
        f"   - 每个风险注明置信度和证据来源\n\n"
        f"## 输出格式（学术叙事风格）\n"
        f"请按以下结构输出，最终可直接用于学术报告：\n\n"
        f"1. **Executive Summary**：2-3段话捕捉研究问题、主要发现、置信度\n"
        f"2. **Knowledge Development**：研究理解如何随双周期推进而演化（6-8+段落）\n"
        f"3. **Comprehensive Analysis**：主要发现、模式、矛盾、证据强度（6-8+段落）\n"
        f"4. **Practical Implications**：应用、风险、实施考量、未来研究方向（6-8+段落）\n"
        f"5. **References**：完整APA格式参考文献列表（按作者姓氏字母排序）\n\n"
        f"## 引注格式要求（APA 7th）\n"
        f"- 每段至少1-2个引注\n"
        f"- 格式：(Author, Year)，如 (Johnson et al., 2023)\n"
        f"- 3个以上作者首次出现用 et al.，后续可用 (Smith, 2020; Garcia et al., 2022)\n"
        f"- 所有文中引注必须在参考文献列表中出现\n"
        f"- 参考文献格式：Author, A. A. (Year). Title. Journal, Vol(Issue), pages. https://doi.org/xx.xxxx\n"
        f"- 若缺少数据：使用 (Source Name, n.d.) + URL\n\n"
        f"## 置信度标注说明\n"
        f"- [HIGH] Multiple high-quality sources agree\n"
        f"- [MEDIUM] Limited or mixed evidence\n"
        f"- [LOW] Single source or preliminary finding\n"
        f"- [SPECULATIVE] Hypothesis or emerging area\n"
        f"每个结论必须标注置信度，矛盾点必须单独说明。\n"
    )


# ── 输出格式化模板 ────────────────────────────────────────────────────────────

LONGITUDINAL_FORMAT = """
请严格按以下结构输出纵向研究报告（含证据层级+置信度标注）：

## 一、起源与诞生背景
[内容，含具体时间/地点/人物，注明证据来源和置信度]

## 二、发展历程时间线
[按时间顺序排列的完整时间线，含每个节点的信息来源、证据层级、置信度]

## 三、关键决策与逻辑
[每个关键节点的选择原因分析，含多源验证情况]

## 四、阶段划分
[萌芽期/增长期/转型期等各阶段特征，注明各阶段的置信度]

## 五、证据质量评估
[列出高置信度结论（HIGH）和低置信度/推测性结论（LOW/[SPECULATIVE]）]

## 六、矛盾点与未解问题
[列出所有矛盾点和证据空白，注明可能的原因]

## 七、信息来源索引
[所有引用的数据源，按证据层级排序]
"""

LATERAL_FORMAT = """
请严格按以下结构输出横向竞品研究报告（含双周期证据+置信度标注）：

## 一、竞品全景图
[识别出的所有主要竞品及其定位，注明各竞品的置信度]

## 二、多维度对比表
[用表格呈现核心差异（技术路线/产品形态/商业模式等），每个数据点注明来源和置信度]

## 三、市场份额多源验证
[每个市场份额数据均需列出2+来源，注明一致性情况和置信度]

## 四、用户视角分析
[真实口碑、评价、用户社区讨论摘要，含证据来源]

## 五、生态位与趋势判断
[各竞品在行业版图中的位置及未来趋势，注明置信度]

## 六、矛盾数据专项分析
[列出所有多源不一致的数据，分析可能原因]

## 七、信息来源索引
[所有引用的数据源，按证据层级排序]
"""

CROSS_INSIGHT_FORMAT = """
请按学术报告结构输出横纵交汇洞察（含APA引注+置信度标注）：

# 研究报告：{target}

## Executive Summary
[2-3段，捕捉研究问题、主要发现、置信度总览]

## Knowledge Development
[6-8+段，叙述研究理解如何随双周期推进而演化]
[每段1-2个APA引注：(Author, Year)]

## Comprehensive Analysis
### 横纵交汇发现
[6-8+段，主要发现、模式、矛盾、证据强度]
### 证据质量总评
[列出[HIGH]/[MEDIUM]/[LOW]/[SPECULATIVE]结论分布]

## Practical Implications
### 应用建议
[6-8+段]
### 风险提示
[每个风险注明置信度和证据来源]
### 未来研究方向

## References
[完整APA格式参考文献，按作者姓氏字母排序]
格式：Author, A. A., & Author, B. B. (Year). Title. Journal, Vol(Issue), pages. https://doi.org/xx.xxxx
"""


def run_cycle(api_key, query, output_fmt, phase_label, stream=False):
    print(f"\n[HV-Academic-Gemini] ▶ {phase_label} 开始（Gemini Deep Research + 双周期协议）", file=sys.stderr)
    interaction = create_interaction(api_key, query, output_format=output_fmt)
    interaction_id = interaction.get("id")
    if not interaction_id:
        print(f"Error: 无法创建 interaction: {interaction}", file=sys.stderr)
        sys.exit(1)
    print(f"[HV-Academic-Gemini] Interaction: {interaction_id}", file=sys.stderr)
    print("[HV-Academic-Gemini] 深度研究中（Gemini双周期，可能需要数分钟）...", file=sys.stderr)
    result = poll_interaction(api_key, interaction_id, stream=stream)
    report = extract_report(result)
    if not report:
        print("Warning: 无法提取报告文本", file=sys.stderr)
        report = json.dumps(result, indent=2)
    return report, result


def save_outputs(report, result, phase, output_dir):
    timestamp = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    phase_name = {"longitudinal": "long", "lateral": "lat", "cross_insight": "cross", "all": "all"}.get(phase, phase)
    md_path = output_dir / f"hvag-{phase_name}-{timestamp}.md"
    json_path = output_dir / f"hvag-{phase_name}-{timestamp}.json"
    md_path.write_text(report)
    json_path.write_text(json.dumps(result, indent=2))
    print(f"[HV-Academic-Gemini] ✅ {phase} 完成 → {md_path}", file=sys.stderr)
    return str(md_path)


def main():
    parser = argparse.ArgumentParser(
        description="HV-Analysis × Academic Deep Research × Gemini Deep Research 三层融合研究引擎"
    )
    parser.add_argument("--query", required=True, help="研究对象（如：公司名/产品名）")
    parser.add_argument("--phase", required=True,
                        choices=["longitudinal", "lateral", "cross_insight", "all"],
                        help="研究阶段：longitudinal=纵向,lateral=横向,cross_insight=横纵交汇,all=完整流程")
    parser.add_argument("--type", default="公司",
                        choices=["产品", "公司", "概念", "人物"],
                        help="研究对象类型")
    parser.add_argument("--competitors", help="已知竞品列表（逗号分隔）")
    parser.add_argument("--longitudinal-summary", help="cross_insight阶段：纵向摘要文件路径")
    parser.add_argument("--lateral-summary", help="cross_insight阶段：横向摘要文件路径")
    parser.add_argument("--stream", action="store_true", help="显示进度更新")
    parser.add_argument("--output-dir", default=".", help="结果输出目录")
    parser.add_argument("--api-key", help="Gemini API key（覆盖环境变量）")
    parser.add_argument("--format", help="自定义输出格式（覆盖默认模板）")

    args = parser.parse_args()

    api_key = args.api_key or os.environ.get("GEMINI_API_KEY")
    if not api_key:
        print("Error: 缺少 GEMINI_API_KEY", file=sys.stderr)
        print("请设置：export GEMINI_API_KEY=***", file=sys.stderr)
        sys.exit(1)

    results = {}

    if args.phase in ("longitudinal", "all"):
        query = build_longitudinal_query_v2(args.query, args.type)
        output_fmt = args.format or LONGITUDINAL_FORMAT
        report, _ = run_cycle(api_key, query, output_fmt, "纵向研究（Cycle1+2）", args.stream)
        path = save_outputs(report, {}, "longitudinal", args.output_dir)
        results["longitudinal"] = {"report": report, "path": path}

    if args.phase in ("lateral", "all"):
        竞品列表 = [c.strip() for c in args.competitors.split(",")] if args.competitors else None
        query = build_lateral_query_v2(args.query, args.type, 竞品列表)
        output_fmt = args.format or LATERAL_FORMAT
        report, _ = run_cycle(api_key, query, output_fmt, "横向研究（Cycle1+2）", args.stream)
        path = save_outputs(report, {}, "lateral", args.output_dir)
        results["lateral"] = {"report": report, "path": path}

    if args.phase in ("cross_insight", "all"):
        long_sum = ""
        lat_sum = ""
        if args.longitudinal_summary:
            p = Path(args.longitudinal_summary)
            long_sum = p.read_text() if p.exists() else args.longitudinal_summary
        if args.lateral_summary:
            p = Path(args.lateral_summary)
            lat_sum = p.read_text() if p.exists() else args.lateral_summary
        if not long_sum and not lat_sum and args.phase == "all":
            long_sum = results.get("longitudinal", {}).get("report", "")
            lat_sum = results.get("lateral", {}).get("report", "")
        query = build_cross_insight_query_v2(args.query, args.type, long_sum, lat_sum)
        output_fmt = args.format or CROSS_INSIGHT_FORMAT
        report, _ = run_cycle(api_key, query, output_fmt, "横纵交汇洞察（Cycle1+2）", args.stream)
        path = save_outputs(report, {}, "cross_insight", args.output_dir)
        results["cross_insight"] = {"report": report, "path": path}

    print(f"\n[HV-Academic-Gemini] ═══ 全部完成 ═══", file=sys.stderr)
    for k, v in results.items():
        print(f"  {k}: {v['path']}", file=sys.stderr)

    # 最终报告输出到 stdout
    if "cross_insight" in results:
        print("\n" + "="*60)
        print(results["cross_insight"]["report"])


if __name__ == "__main__":
    main()