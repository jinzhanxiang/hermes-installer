#!/usr/bin/env python3
"""
hv-gate.py - 纵横分析法 V3.47.0 报告门禁脚本（强制校验）

设计哲学：
  - SKILL.md 是描述，hv-gate.py 才是门禁
  - 任何报告生成后必须通过本门禁，否则视为"未通过质量审查"
  - 不通过的项会逐项列出 + 退出码非 0，迫使修复

用法：
  python3 hv-gate.py <project_name> [<md_file>] [--mode decision|analysis] [--enforce]

硬约束（V3.47.0 整改）：
  1. 总字数：决策 ≥21K / 研究 ≥18K / 底线 ≥8K
  2. Phase 字符下限：P1≥8K / P2≥6K / P3≥4K / P4≥3K（激活时）
  3. Phase 字符占比：35-50/25-40/15-35（无 P4）/ 35-45/25-35/12-20/10-18（有 P4）
  4. 章节数：决策模式 22-25 章（含摘要+小结） / 研究模式 18-21 章
  5. 图表数：≥5 张 base64 SVG 嵌入（V3.46.0 Lesson 40）
  6. 数据双源验证：关键数值必须标注来源（[本地/iFind/MX/...]）
  7. 占位符检测：禁止 ## TODO / ## 待补充 / ## 后续完善
  8. 决策模式章节完整性：必须含交易结构/退出路径/约束/情景推演四大章
  9. 警醒信号：S1-S7 在交叉洞察章节必须出现
  10. HTML 渲染：可选，但若指定 --render-html 必须产出有效 HTML
"""
import sys
import re
import argparse
from pathlib import Path
from datetime import datetime


# ========================= 硬约束字典 =========================
GATES = {
    "total_chars": {
        "decision_min": 21000,
        "analysis_min": 18000,
        "absolute_min": 8000,
    },
    "phase_chars": {
        "P1": 8000, "P2": 6000, "P3": 4000, "P4": 3000,
    },
    "phase_ratio": {
        "no_p4": {"P1": (35, 50), "P2": (25, 40), "P3": (15, 35)},
        "with_p4": {"P1": (35, 45), "P2": (25, 35), "P3": (12, 20), "P4": (10, 18)},
    },
    "chapter_count": {
        "decision": (22, 25),
        "analysis": (18, 21),
    },
    "charts_min": 5,
    "source_patterns": [
        r"\[本地[:：]", r"\[iFind[:：]", r"\[MX[:：]", r"\[港交所",
        r"\[公告[:：]", r"\[年报[:：]", r"\[Wind", r"\[同花顺", r"\[券商",
    ],
    "decision_required_chapters": [
        "交易结构", "退出路径", "约束", "情景推演",
    ],
    "alert_signals": [f"S{i}" for i in range(1, 8)],
    "forbidden_placeholders": [
        "## TODO", "## 待补充", "## 后续完善", "## 占位",
        "Placeholder", "(占位符)",
    ],
}


def banner(text):
    bar = "=" * 70
    return f"\n{bar}\n  {text}\n{bar}"


def count_chinese_chars(text):
    """中文字符数（CJK 范围内字符数）"""
    return sum(1 for c in text if '\u4e00' <= c <= '\u9fff')


def extract_chapters(text):
    """提取二级标题作为章节标题（V3.47.0：自动排除附录、门禁审计、摘要）"""
    chapters = []
    # 排除标题模式
    exclude_patterns = [
        r"门禁审计", r"附录", r"摘要", r"使用说明", r"图表与数据表",
    ]
    for line in text.split("\n"):
        m = re.match(r"^##\s+(.+?)$", line.strip())
        if m:
            title = m.group(1).strip()
            # 排除附录/摘要/门禁审计/使用说明
            if any(re.search(pat, title) for pat in exclude_patterns):
                continue
            chapters.append(title)
    return chapters


def split_phases(text, chapters):
    """按章节序号分配 Phase
    
    决策模式章节分配：
      Phase 1（第 1-8 章）：摘要/公司概况/业务/财务/技术/治理/供应链/预测/小结
      Phase 2（第 9-14 章）：行业/竞品/技术路线/商业模式/估值/小结
      Phase 3（第 15-21 章）：矛盾/护城河/风险/三锚估值/成长/结论/小结
      Phase 4（第 22-25 章）：交易结构/退出路径/约束/情景推演
    """
    # 启发式：根据章节关键词分配
    p1_keywords = ["摘要", "公司概况", "业务", "财务", "技术", "治理", "供应链", "预测", "研究对象", "公司沿革", "IDC 资产", "关键预测"]
    p2_keywords = ["行业", "同业", "竞争", "能力雷达", "技术路线", "商业模式", "估值对标", "Phase 2 小结", "IDC 行业", "IDC 同业", "竟品"]
    p3_keywords = ["矛盾", "护城河", "风险交叉", "三锚估值", "成长性", "综合结论", "Phase 3 小结", "交叉洞察"]
    p4_keywords = ["交易结构", "退出路径", "约束条件", "情景推演", "行动建议"]
    
    phases = {"P1": "", "P2": "", "P3": "", "P4": ""}
    current_phase = "P1"
    in_chapter = False
    chapter_title = ""
    chapter_text = []
    
    for line in text.split("\n"):
        m = re.match(r"^##\s+(.+?)$", line.strip())
        if m:
            # 保存上一章节
            if chapter_title:
                content = "\n".join(chapter_text)
                phases[current_phase] += content + "\n"
            
            chapter_title = m.group(1).strip()
            chapter_text = [line]
            
            # 判断 Phase
            if any(kw in chapter_title for kw in p4_keywords):
                current_phase = "P4"
            elif any(kw in chapter_title for kw in p3_keywords):
                current_phase = "P3"
            elif any(kw in chapter_title for kw in p2_keywords):
                current_phase = "P2"
            elif any(kw in chapter_title for kw in p1_keywords):
                current_phase = "P1"
        else:
            chapter_text.append(line)
    
    # 保存最后一章
    if chapter_title:
        content = "\n".join(chapter_text)
        phases[current_phase] += content + "\n"
    
    return phases


def main():
    parser = argparse.ArgumentParser(description="hv-gate.py - 纵横分析法报告门禁校验（V3.47.0）")
    parser.add_argument("project", help="项目名称")
    parser.add_argument("md_file", nargs="?", help="MD 文件路径（默认取 output/ 最新）")
    parser.add_argument("--mode", choices=["decision", "analysis"], default="decision")
    parser.add_argument("--enforce", action="store_true", help="失败时退出码非 0（用于 CI/门禁）")
    parser.add_argument("--html", help="HTML 文件路径（可选，用于校验图表嵌入）")
    parser.add_argument("--phase", type=int, choices=[1, 2, 3, 4], 
                        help="V3.47.0 单 Phase 校验模式（仅校验指定 Phase 的字符下限）")
    args = parser.parse_args()
    
    print(banner(f"hv-gate V3.47.0 - {args.project} - {args.mode.upper()} 模式"))
    
    # 找 MD 文件
    if args.md_file:
        md_path = Path(args.md_file)
    else:
        output_dir = Path(f"~/Documents/OpenClaw-Workspace-research/projects/{args.project}/output").expanduser()
        md_files = sorted(output_dir.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not md_files:
            print(f"❌ MD 文件不存在: {output_dir}/*.md")
            sys.exit(1)
        md_path = md_files[0]
    
    print(f"\n📄 MD 文件: {md_path}")
    print(f"   字节数: {md_path.stat().st_size:,}")
    
    if not md_path.exists():
        print(f"❌ MD 文件不存在")
        sys.exit(1)
    
    md_text = md_path.read_text(encoding='utf-8')
    cn_chars = count_chinese_chars(md_text)
    print(f"   中文字符: {cn_chars:,}")
    
    html_text = ""
    if args.html and Path(args.html).exists():
        html_path = Path(args.html)
        html_text = html_path.read_text(encoding='utf-8')
        print(f"📄 HTML 文件: {html_path} ({html_path.stat().st_size:,} bytes)")
    
    # ====== 门禁校验 ======
    print(banner("门禁校验"))
    failures = []
    warnings = []
    
    # 1. 总字数（V3.47.0 支持单 Phase 模式）
    print("\n[1/10] 总字数校验")
    if args.phase:
        # 单 Phase 模式：只校验该 Phase 的字符下限
        phase_min = GATES["phase_chars"][f"P{args.phase}"]
        if cn_chars >= phase_min:
            print(f"   ✅ PASS Phase {args.phase} 模式 ({cn_chars:,} ≥ {phase_min:,})")
        elif cn_chars >= GATES["total_chars"]["absolute_min"]:
            warnings.append(f"Phase {args.phase} 字符 {cn_chars:,} < 下限 {phase_min:,} 但 ≥ 底线")
            print(f"   ⚠️ WARN Phase {args.phase} ({cn_chars:,} < {phase_min:,})")
        else:
            failures.append(f"Phase {args.phase} 字符 {cn_chars:,} < 底线 {GATES['total_chars']['absolute_min']:,}")
            print(f"   ❌ FAIL Phase {args.phase} ({cn_chars:,} < {GATES['total_chars']['absolute_min']:,})")
    elif args.mode == "decision":
        min_total = GATES["total_chars"]["decision_min"]
        if cn_chars >= min_total:
            print(f"   ✅ PASS  ({cn_chars:,} ≥ {min_total:,})")
        elif cn_chars >= GATES["total_chars"]["absolute_min"]:
            warnings.append(f"总字数 {cn_chars:,} < 标准 {min_total:,} 但 ≥ 底线 {GATES['total_chars']['absolute_min']:,}")
            print(f"   ⚠️ WARN  ({cn_chars:,} < {min_total:,} 标准, 但 ≥ 底线)")
        else:
            failures.append(f"总字数 {cn_chars:,} < 底线 {GATES['total_chars']['absolute_min']:,}")
            print(f"   ❌ FAIL  ({cn_chars:,} < {GATES['total_chars']['absolute_min']:,})")
    else:
        min_total = GATES["total_chars"]["analysis_min"]
        if cn_chars >= min_total:
            print(f"   ✅ PASS  ({cn_chars:,} ≥ {min_total:,})")
        elif cn_chars >= GATES["total_chars"]["absolute_min"]:
            warnings.append(f"总字数 {cn_chars:,} < 标准 {min_total:,} 但 ≥ 底线 {GATES['total_chars']['absolute_min']:,}")
            print(f"   ⚠️ WARN  ({cn_chars:,} < {min_total:,} 标准, 但 ≥ 底线)")
        else:
            failures.append(f"总字数 {cn_chars:,} < 底线 {GATES['total_chars']['absolute_min']:,}")
            print(f"   ❌ FAIL  ({cn_chars:,} < {GATES['total_chars']['absolute_min']:,})")
    
    # 2. 章节数
    print("\n[2/10] 章节数校验")
    chapters = extract_chapters(md_text)
    chapter_count = len(chapters)
    min_ch, max_ch = GATES["chapter_count"][args.mode]
    print(f"   实际: {chapter_count} 章（{args.mode} 模式要求 {min_ch}-{max_ch}，已排除附录/摘要）")
    if min_ch <= chapter_count <= max_ch:
        print(f"   ✅ PASS")
    else:
        failures.append(f"章节数 {chapter_count} 不在 {min_ch}-{max_ch} 范围内")
        print(f"   ❌ FAIL")
    
    # 3. Phase 字符分布
    print("\n[3/10] Phase 字符分布校验")
    phases = split_phases(md_text, chapters)
    has_p4 = bool(phases["P4"].strip())
    print(f"   Phase 4 激活: {'是' if has_p4 else '否'}")
    phase_chars = {p: count_chinese_chars(content) for p, content in phases.items() if p != "P4" or has_p4}
    print(f"   {' '.join(f'{p}={phase_chars.get(p, 0):,}' for p in ['P1', 'P2', 'P3', 'P4'])}")
    total = sum(phase_chars.values())
    
    if has_p4:
        ratio_target = GATES["phase_ratio"]["with_p4"]
    else:
        ratio_target = GATES["phase_ratio"]["no_p4"]
    
    phase_pass = True
    for p, (lo, hi) in ratio_target.items():
        if total > 0:
            pct = phase_chars.get(p, 0) / total * 100
            if lo <= pct <= hi:
                print(f"   ✅ {p}: {pct:.1f}% 在 [{lo}, {hi}]")
            else:
                phase_pass = False
                print(f"   ❌ {p}: {pct:.1f}% 不在 [{lo}, {hi}]")
                # Phase 比例失败不计入 hard fail（可接受），只警告
                warnings.append(f"{p} 比例 {pct:.1f}% 不在 [{lo}, {hi}]")
    
    # 4. Phase 字符下限
    print("\n[4/10] Phase 字符下限校验")
    for p, min_chars in GATES["phase_chars"].items():
        if has_p4 or p != "P4":
            actual = phase_chars.get(p, 0)
            if actual >= min_chars:
                print(f"   ✅ {p}: {actual:,} ≥ {min_chars:,}")
            else:
                failures.append(f"{p} 字符 {actual:,} < 下限 {min_chars:,}")
                print(f"   ❌ {p}: {actual:,} < {min_chars:,}")
    
    # 5. 图表数
    print("\n[5/10] 图表数校验（V3.46.0 强制 ≥5 张）")
    md_svg_count = md_text.count("data:image/svg+xml;base64")
    html_svg_count = html_text.count("data:image/svg+xml;base64")
    print(f"   MD 中 base64 SVG: {md_svg_count}")
    print(f"   HTML 中 base64 SVG: {html_svg_count}")
    
    target_count = max(md_svg_count, html_svg_count)
    if target_count >= GATES["charts_min"]:
        print(f"   ✅ PASS  ({target_count} ≥ {GATES['charts_min']})")
    else:
        failures.append(f"图表数 {target_count} < {GATES['charts_min']}")
        print(f"   ❌ FAIL  ({target_count} < {GATES['charts_min']})")
    
    # 6. 数据双源验证
    print("\n[6/10] 数据来源标注校验")
    source_count = 0
    for pattern in GATES["source_patterns"]:
        source_count += len(re.findall(pattern, md_text))
    print(f"   来源标注数: {source_count}（≥10 为佳，<3 视为弱标注）")
    if source_count >= 10:
        print(f"   ✅ PASS")
    elif source_count >= 3:
        warnings.append(f"来源标注 {source_count} 条，少于推荐 10 条")
        print(f"   ⚠️ WARN")
    else:
        failures.append(f"来源标注 {source_count} 条，太少")
        print(f"   ❌ FAIL")
    
    # 7. 占位符检测（只检测章节标题级别——避免误报）
    print("\n[7/10] 占位符/糊弄内容检测")
    placeholder_found = []
    # 只检测以 ## 开头的占位符章节（避免附录里"无 ## TODO"声明误报）
    placeholder_patterns = [
        r"^##\s+TODO", r"^##\s+待补充", r"^##\s+后续完善", r"^##\s+占位",
        r"^##\s+Placeholder", r"^##\s+\(占位符\)",
    ]
    for pat in placeholder_patterns:
        matches = re.findall(pat, md_text, re.MULTILINE)
        if matches:
            placeholder_found.extend(matches)
    if placeholder_found:
        failures.append(f"发现占位符章节: {placeholder_found}")
        print(f"   ❌ FAIL: 发现占位符章节 {placeholder_found}")
    else:
        print(f"   ✅ PASS（无占位符章节）")
    
    # 8. 决策模式必含章节
    print("\n[8/10] 决策模式必含章节校验")
    if args.mode == "decision":
        missing = []
        for kw in GATES["decision_required_chapters"]:
            if not any(kw in ch for ch in chapters):
                missing.append(kw)
        if missing:
            failures.append(f"决策模式缺章节: {missing}")
            print(f"   ❌ FAIL: 缺 {missing}")
        else:
            print(f"   ✅ PASS（4 大决策章节齐全）")
    else:
        print(f"   ⏭️ SKIP（研究模式不强制）")
    
    # 9. 警醒信号
    print("\n[9/10] 警醒信号 S1-S7 校验")
    if has_p4 or args.mode == "decision":
        missing_s = []
        for s in GATES["alert_signals"]:
            if s not in md_text:
                missing_s.append(s)
        if missing_s:
            warnings.append(f"警醒信号未出现: {missing_s}")
            print(f"   ⚠️ WARN: 缺 {missing_s}")
        else:
            print(f"   ✅ PASS（S1-S7 齐全）")
    else:
        print(f"   ⏭️ SKIP（研究模式不强制）")
    
    # 10. HTML 校验（如果指定）
    print("\n[10/10] HTML 渲染校验")
    if args.html:
        if not Path(args.html).exists():
            failures.append(f"HTML 文件不存在: {args.html}")
            print(f"   ❌ FAIL: HTML 不存在")
        else:
            html_size = Path(args.html).stat().st_size
            if html_size < 5000:
                failures.append(f"HTML 文件太小: {html_size} bytes（疑似空白页）")
                print(f"   ❌ FAIL: HTML 仅 {html_size} bytes")
            else:
                print(f"   ✅ PASS（{html_size:,} bytes）")
    else:
        print(f"   ⏭️ SKIP（未指定 HTML）")
    
    # ====== 总结 ======
    if args.phase:
        mode_label = f"Phase {args.phase} 模式"
    else:
        mode_label = f"整体 ({args.mode.upper()} 模式)"
    print(banner(f"门禁总结 - {mode_label}"))
    print(f"\n  ✅ 通过项: {10 - len(failures)} / 10")
    print(f"  ⚠️ 警告项: {len(warnings)}")
    print(f"  ❌ 失败项: {len(failures)}")
    
    if failures:
        print(f"\n  ❌ 失败明细：")
        for f in failures:
            print(f"     - {f}")
    
    if warnings:
        print(f"\n  ⚠️ 警告明细：")
        for w in warnings:
            print(f"     - {w}")
    
    if not failures and not warnings:
        print(f"\n  🎉 完美通过所有门禁！")
        return 0
    elif not failures:
        print(f"\n  ⚠️ 通过但有警告（建议修复后重跑）")
        return 0 if not args.enforce else 0  # 警告不阻断
    else:
        print(f"\n  ❌ 不通过门禁！必须修复后重跑。")
        return 1 if args.enforce else 1


if __name__ == "__main__":
    sys.exit(main())
