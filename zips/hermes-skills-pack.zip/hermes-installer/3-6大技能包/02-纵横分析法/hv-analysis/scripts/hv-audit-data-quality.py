#!/usr/bin/env python3
"""
hv-audit-data-quality.py — 纵横分析法 V3.49 报告交付前自动审计

核心功能：
1. 自动扫描指定项目目录下的所有报告 MD 文件
2. 调用 hv-data-quality-class 审计每个报告的数据源质量
3. 输出审计汇总报告（多文件对比）
4. 支持 --strict 模式（任一报告 A 级占比 < 30% 则 exit 1，阻止交付）

用法：
    # 审计单个报告
    python3 hv-audit-data-quality.py --report path/to/report.md

    # 审计项目目录下所有报告
    python3 hv-audit-data-quality.py --project ~/Documents/OpenClaw-Workspace-research/projects/奥联电子/

    # 严格模式（A 级 < 30% 阻止交付）
    python3 hv-audit-data-quality.py --project <path> --strict

    # 输出 JSON（给其他脚本调用）
    python3 hv-audit-data-quality.py --project <path> --json
"""
import sys
import json
import argparse
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any

# 引入同目录的 hv-data-quality-class 模块
sys.path.insert(0, str(Path(__file__).parent))
import importlib.util
spec = importlib.util.spec_from_file_location(
    "hv_data_quality_class",
    Path(__file__).parent / "hv-data-quality-class.py"
)
mod_data_quality = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod_data_quality)


def audit_report(report_path: Path) -> Dict[str, Any]:
    """审计单个报告（调用 hv-data-quality-class.analyze_report）"""
    try:
        result = mod_data_quality.analyze_report(str(report_path))
        result["audit_status"] = "success"
        return result
    except Exception as e:
        return {
            "file_path": str(report_path.absolute()),
            "audit_status": "error",
            "error": str(e)
        }


def find_report_files(project_dir: Path) -> List[Path]:
    """查找项目目录下所有报告 MD 文件

    匹配规则：
    - 包含"报告"/"research"/"report"/"主报告"的文件名
    - 排除：_extracted / _audit / _bak / _polluted / README.md
    - 排除目录：_v*_polluted_*, _extracted, input/, scripts/
    """
    reports = []

    for md_file in project_dir.rglob("*.md"):
        # 排除条件
        if any(p.startswith("_") for p in md_file.parts[:-1]):
            continue
        if md_file.name.startswith("_"):
            continue
        if "_bak" in md_file.name or "_polluted" in md_file.name or ".bak" in md_file.name:
            continue
        if md_file.name in ["README.md", "CHANGELOG.md"]:
            continue

        # 关键词匹配
        keywords = ["报告", "research", "report", "主报告", "尽调", "估值"]
        if any(k in md_file.name.lower() for k in keywords):
            reports.append(md_file)

    return sorted(reports)


def audit_project(project_dir: str) -> Dict[str, Any]:
    """审计项目目录下所有报告"""
    project_path = Path(project_dir).expanduser()

    if not project_path.exists():
        return {"error": f"项目目录不存在: {project_dir}"}

    reports = find_report_files(project_path)

    audit_results = []
    for report in reports:
        result = audit_report(report)
        audit_results.append(result)

    # 汇总
    total_reports = len(audit_results)
    passed_count = sum(1 for r in audit_results if r.get("critical_passed", False))
    failed_count = sum(1 for r in audit_results if r.get("audit_status") == "success" and not r.get("critical_passed", False))
    error_count = sum(1 for r in audit_results if r.get("audit_status") == "error")

    return {
        "project_dir": str(project_path.absolute()),
        "audit_time": datetime.now().isoformat(),
        "total_reports": total_reports,
        "passed_count": passed_count,
        "failed_count": failed_count,
        "error_count": error_count,
        "reports": audit_results,
        "overall_passed": passed_count == total_reports and error_count == 0,
    }


def format_markdown_audit(audit: Dict[str, Any]) -> str:
    """格式化 Markdown 审计报告"""
    if "error" in audit:
        return f"❌ 错误：{audit['error']}"

    lines = ["## 📋 报告数据源质量审计汇总\n",
             f"**项目目录**：{audit['project_dir']}",
             f"**审计时间**：{audit['audit_time']}",
             f"**报告总数**：{audit['total_reports']}",
             f"**通过**：{audit['passed_count']}",
             f"**未通过**：{audit['failed_count']}",
             f"**错误**：{audit['error_count']}\n"]

    if audit["total_reports"] == 0:
        lines.append("⚠️ 未找到任何报告文件（关键词匹配：报告/research/report/主报告/尽调/估值）")
        return "\n".join(lines)

    lines.append("### 各报告详情\n")
    lines.append("| 报告文件 | 文件大小 | 总引用 | A 级 | B 级 | C 级 | Unknown | A 占比 | 判定 |")
    lines.append("|:---------|---------:|------:|----:|----:|----:|--------:|------:|:----:|")

    for r in audit["reports"]:
        if r.get("audit_status") == "error":
            lines.append(f"| `{Path(r['file_path']).name}` | - | - | - | - | - | - | - | ❌ 错误 |")
        else:
            lines.append(
                f"| `{Path(r['file_path']).name}` "
                f"| {r['file_size_bytes']:,} "
                f"| {r['total_citations']} "
                f"| {r['by_level'].get('A', 0)} "
                f"| {r['by_level'].get('B', 0)} "
                f"| {r['by_level'].get('C', 0)} "
                f"| {r['by_level'].get('Unknown', 0)} "
                f"| **{r['A_ratio_pct']}** "
                f"| {'✅' if r['critical_passed'] else '❌'} |"
            )

    lines.append("")
    overall = "✅ 全部通过" if audit["overall_passed"] else "❌ 有报告未通过"
    lines.append(f"### 整体判定：{overall}\n")

    # 列出所有未通过报告的警告
    failed_reports = [r for r in audit["reports"] if r.get("audit_status") == "success" and not r.get("critical_passed", False)]
    if failed_reports:
        lines.append("### ⚠️ 未通过报告的警告")
        for r in failed_reports:
            lines.append(f"\n**{Path(r['file_path']).name}**")
            for w in r.get("warnings", []):
                lines.append(f"- {w}")
            for rec in r.get("recommendations", []):
                lines.append(f"  💡 {rec}")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="hv-analysis 报告数据源质量自动审计")
    parser.add_argument("--report", type=str, help="单个报告 MD 文件")
    parser.add_argument("--project", type=str, help="项目目录（自动扫描所有报告）")
    parser.add_argument("--json", action="store_true", help="输出 JSON")
    parser.add_argument("--strict", action="store_true", help="严格模式（任一未通过即 exit 1）")
    args = parser.parse_args()

    if args.report:
        result = audit_report(Path(args.report))
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(mod_data_quality.format_markdown(result))
        if args.strict and not result.get("critical_passed", False):
            sys.exit(1)
    elif args.project:
        result = audit_project(args.project)
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(format_markdown_audit(result))
        if args.strict and not result.get("overall_passed", False):
            sys.exit(1)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()