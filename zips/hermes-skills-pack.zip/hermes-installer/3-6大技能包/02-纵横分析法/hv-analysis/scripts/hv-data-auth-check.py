#!/usr/bin/env python3
"""
hv-data-auth-check.py — 纵横分析法 V3.49 数据权威性核查（Phase 0 节点 1）

功能：
1. 检测 iFind Finance / iFind News / iFind Announcement / iFind Investment 等 6 个 ifind-repilot 技能的 token 状态
2. 检测 MX Data / MX Search 的可达性
3. 检测 AKShare / Tushare 的环境可用性
4. 输出标准化检测报告，作为 Phase 0 强制门禁

门禁规则：
- iFind Finance + News 任一无效 → 报告标记"未达 A 级"，必须修复 token 才能继续
- MX 不可用 → 标记"MX 降级路径"
- 输出 JSON 格式的检测结果，供其他 hv-* 脚本调用

用法：
    python3 hv-data-auth-check.py
    python3 hv-data-auth-check.py --json          # 输出 JSON
    python3 hv-data-auth-check.py --strict        # 严格模式（任一 iFind 不可用即退出码 1）
    python3 hv-data-auth-check.py --report-md     # 输出 Markdown 报告片段
"""
import subprocess
import sys
import json
import argparse
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

# iFind-repilot 系列技能路径（每个技能标注主脚本和检测方式）
IFIND_SKILLS = {
    "ifind-finance-data-search": {
        "script": "~/.openclaw/workspace-research/skills/ifind-repilot-finance-data-search/scripts/fetch_data.py",
        "check_mode": "token",  # 用 --check-token 检测
    },
    "ifind-news-search": {
        "script": "~/.openclaw/workspace-research/skills/ifind-repilot-news-search/scripts/fetch_data.py",
        "check_mode": "token",
    },
    "ifind-announcement-search": {
        "script": "~/.openclaw/workspace-research/skills/ifind-repilot-announcement-search/scripts/fetch_data.py",
        "check_mode": "token",
    },
    "ifind-company-investment-research": {
        "script": "~/.openclaw/workspace-research/skills/ifind-company-investment-research/scripts/company_investment_research_async.py",
        "check_mode": "import_only",  # 仅检测能否 import
    },
    "ifind-chain-analysis": {
        "script": "~/.openclaw/workspace-research/skills/ifind-chain-analysis/scripts/chain_analysis_async.py",
        "check_mode": "import_only",
    },
}

# MX / AKShare / Tushare 环境检测脚本（修复为真实路径）
ENV_CHECK_SCRIPTS = {
    "akshare-finance": {
        "skill_name": "akshare-finance",
        "script": "~/.openclaw/workspace-research/skills/akshare-finance/scripts/stock_price.py",
        "check_mode": "env_test",
        "venv": "~/.openclaw/workspace-research/venvs/mx-skills/bin/python3",
    },
    "tushare-finance": {
        "skill_name": "tushare-finance",
        "script": "~/.openclaw/workspace-research/skills/tushare-finance/scripts/api_client.py",
        "check_mode": "env_test",
        "venv": "~/.openclaw/workspace-research/venvs/mx-skills/bin/python3",
    },
}

# MX 服务候选端点（按优先级尝试）
MX_SERVICE_ENDPOINTS = [
    "http://localhost:8080/health",
    "http://localhost:8080/api/health",
    "http://localhost:8080/v1/health",
    "http://localhost:7999/health",
    "http://mx.local:8080/health",
]


def check_ifind_skill(skill_path: str, check_mode: str = "token", timeout: int = 10) -> Dict[str, Any]:
    """检测单个 iFind skill 的状态

    Args:
        skill_path: 脚本路径
        check_mode: token（用 --check-token）/ import_only（仅检测能否 import）
        timeout: 超时秒数
    """
    path = Path(skill_path).expanduser()
    if not path.exists():
        return {
            "available": False,
            "status": "❌ 脚本不存在",
            "active_token": None,
            "error": f"路径不存在: {skill_path}"
        }

    if check_mode == "import_only":
        # 仅检测脚本能否被 python 解析（语法检查 + 关键 import）
        try:
            result = subprocess.run(
                ["python3", "-c", f"import ast; ast.parse(open('{path}').read()); print('PARSE_OK')"],
                capture_output=True, text=True, timeout=timeout
            )
            if "PARSE_OK" in result.stdout:
                return {
                    "available": True,
                    "status": "✅ 可用（异步脚本）",
                    "active_token": None,
                    "error": None
                }
            else:
                return {
                    "available": False,
                    "status": "❌ 语法错误",
                    "active_token": None,
                    "error": result.stderr[:200] or result.stdout[:200]
                }
        except Exception as e:
            return {
                "available": False,
                "status": "❌ 异常",
                "active_token": None,
                "error": str(e)
            }

    # check_mode == "token"
    try:
        result = subprocess.run(
            ["python3", str(path), "--check-token"],
            capture_output=True,
            text=True,
            timeout=timeout
        )
        output = result.stdout + result.stderr
        if any(s in output for s in ["Token 有效", "当前Token有效", "当前 token 有效", "✅ 当前 Token 有效"]):
            # 提取活跃 token 信息
            active_token = ""
            for line in output.split("\n"):
                if "当前使用:" in line:
                    active_token = line.split("当前使用:")[-1].strip()
                    break
            return {
                "available": True,
                "status": "✅ 可用",
                "active_token": active_token,
                "error": None
            }
        elif "请先配置 auth_token" in output:
            return {
                "available": False,
                "status": "❌ Token 未配置",
                "active_token": None,
                "error": "Token 未配置，请运行 --set-token 配置"
            }
        else:
            return {
                "available": False,
                "status": "⚠️ 检测异常",
                "active_token": None,
                "error": output[:200]
            }
    except subprocess.TimeoutExpired:
        return {
            "available": False,
            "status": "⚠️ 超时",
            "active_token": None,
            "error": f"检测超时（{timeout}s）"
        }
    except Exception as e:
        return {
            "available": False,
            "status": "❌ 异常",
            "active_token": None,
            "error": str(e)
        }


def check_env_script_unused(script_path: str, timeout: int = 10) -> Dict[str, Any]:
    """兼容旧调用（已废弃，保留以防外部调用）"""
    path = Path(script_path).expanduser()
    if not path.exists():
        return {
            "available": False,
            "status": "❌ 脚本不存在",
            "error": f"路径不存在: {script_path}"
        }
    try:
        result = subprocess.run(
            ["python3", str(path), "--check"],
            capture_output=True, text=True, timeout=timeout
        )
        output = result.stdout + result.stderr
        return {
            "available": result.returncode == 0,
            "status": "✅ 可用" if result.returncode == 0 else "❌ 不可用",
            "error": None if result.returncode == 0 else output[:200]
        }
    except Exception as e:
        return {
            "available": False,
            "status": "❌ 异常",
            "error": str(e)
        }


def check_mx_search_direct() -> Dict[str, Any]:
    """直接检测 MX 服务可达性（按优先级尝试多个端点）"""
    for endpoint in MX_SERVICE_ENDPOINTS:
        try:
            result = subprocess.run(
                ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", endpoint],
                capture_output=True, text=True, timeout=3
            )
            http_code = result.stdout.strip()
            if http_code == "200":
                return {
                    "available": True,
                    "status": f"✅ MX 服务在线（{endpoint}）",
                    "error": None,
                    "endpoint": endpoint
                }
        except Exception:
            continue

    return {
        "available": False,
        "status": "⚠️ MX 服务不可达（尝试 5 个端点全部失败）",
        "error": "MX 服务可能未启动，或需要修改 MX_SERVICE_ENDPOINTS 配置",
        "endpoint": None
    }


def check_env_script(env_config: Dict[str, Any], timeout: int = 10) -> Dict[str, Any]:
    """检测 AKShare / Tushare 等环境脚本

    检查策略：
    1. 先检测 venv 中是否安装了依赖包（akshare / tushare）
    2. 再检测环境变量（akshare 无要求，tushare 需 TUSHARE_TOKEN）
    3. 最后检测脚本能否被 python 解析
    """
    script_path = Path(env_config["script"]).expanduser()
    venv = env_config.get("venv")
    script_name = script_path.name

    # 1. 检查脚本是否存在
    if not script_path.exists():
        return {
            "available": False,
            "status": "❌ 脚本不存在",
            "error": f"路径不存在: {env_config['script']}"
        }

    # 2. 检查 venv 是否存在
    if venv and not Path(venv).expanduser().exists():
        return {
            "available": False,
            "status": "⚠️ venv 不存在",
            "python_bin": "python3",
            "error": f"venv 路径不存在: {venv}"
        }

    python_bin = venv if venv else "python3"

    # 3. 检测关键依赖包是否安装
    package_to_check = "akshare" if "akshare" in env_config.get("skill_name", "") else "tushare"
    try:
        check_result = subprocess.run(
            [python_bin, "-c", f"import {package_to_check}; print('IMPORT_OK')"],
            capture_output=True, text=True, timeout=5
        )
        if "IMPORT_OK" not in check_result.stdout:
            return {
                "available": False,
                "status": f"❌ {package_to_check} 未安装",
                "python_bin": python_bin,
                "error": check_result.stderr[:200]
            }
    except Exception as e:
        return {
            "available": False,
            "status": f"❌ {package_to_check} 检测异常",
            "python_bin": python_bin,
            "error": str(e)
        }

    # 4. 检查环境变量（tushare 需要 TUSHARE_TOKEN）
    if "tushare" in env_config.get("skill_name", ""):
        import os
        if not os.environ.get("TUSHARE_TOKEN"):
            return {
                "available": False,
                "status": "⚠️ TUSHARE_TOKEN 未设置",
                "python_bin": python_bin,
                "error": "需要设置环境变量 TUSHARE_TOKEN（获取: https://tushare.pro）"
            }

    # 5. 通过基础检查，标记为可用
    return {
        "available": True,
        "status": "✅ 可用（依赖已安装）",
        "python_bin": python_bin,
        "error": None
    }


def run_check(strict: bool = False) -> Dict[str, Any]:
    """执行完整的数据源可用性检测"""
    result = {
        "check_time": datetime.now().isoformat(),
        "ifind_skills": {},
        "env_scripts": {},
        "summary": {
            "ifind_available_count": 0,
            "ifind_total_count": len(IFIND_SKILLS),
            "critical_passed": True,
            "warnings": []
        }
    }

    # 1. 检测 iFind-repilot 系列（关键 A 级）
    print("🔍 检测 iFind-repilot 系列技能...")
    for skill_name, config in IFIND_SKILLS.items():
        check = check_ifind_skill(config["script"], config["check_mode"])
        result["ifind_skills"][skill_name] = check
        if check["available"]:
            result["summary"]["ifind_available_count"] += 1
        print(f"  {'✅' if check['available'] else '❌'} {skill_name}: {check['status']}")

    # 2. 检测 MX / AKShare / Tushare
    print("\n🔍 检测 MX / AKShare / Tushare...")
    result["env_scripts"]["mx-search-direct"] = check_mx_search_direct()
    print(f"  {'✅' if result['env_scripts']['mx-search-direct']['available'] else '❌'} "
          f"mx-search-direct: {result['env_scripts']['mx-search-direct']['status']}")

    for env_name, config in ENV_CHECK_SCRIPTS.items():
        check = check_env_script(config)
        result["env_scripts"][env_name] = check
        print(f"  {'✅' if check['available'] else '❌'} {env_name}: {check['status']}")

    # 3. 汇总判定
    if result["summary"]["ifind_available_count"] == 0:
        result["summary"]["critical_passed"] = False
        result["summary"]["warnings"].append(
            "🔴 P0: iFind-repilot 系列全部不可用，必须先修复 token 配置才能进入 Phase 1"
        )
    elif result["summary"]["ifind_available_count"] < result["summary"]["ifind_total_count"]:
        result["summary"]["warnings"].append(
            f"⚠️ iFind-repilot 部分不可用（{result['summary']['ifind_available_count']}/"
            f"{result['summary']['ifind_total_count']}），Phase 1-2 数据采集将受限"
        )

    if not result["env_scripts"]["mx-search-direct"]["available"]:
        result["summary"]["warnings"].append(
            "⚠️ MX 服务不可达：MX 数据路径降级，建议改用 iFind Finance / AKShare 补位"
        )

    return result


def format_markdown(check_result: Dict[str, Any]) -> str:
    """格式化 Markdown 报告片段"""
    lines = ["## 📊 数据源可用性检测报告", ""]
    lines.append(f"**检测时间**：{check_result['check_time']}")
    lines.append("")

    lines.append("### iFind-repilot 系列（A 级专业金融数据）")
    for skill, info in check_result["ifind_skills"].items():
        status = info["status"]
        token = f"（{info['active_token']}）" if info.get("active_token") else ""
        lines.append(f"- {status} **{skill}** {token}")

    lines.append("")
    lines.append("### 环境脚本（MX / AKShare / Tushare）")
    for env, info in check_result["env_scripts"].items():
        lines.append(f"- {info['status']} **{env}**")

    lines.append("")
    summary = check_result["summary"]
    lines.append("### 汇总")
    lines.append(f"- iFind 可用：{summary['ifind_available_count']}/{summary['ifind_total_count']}")
    lines.append(f"- 关键检查：{'✅ 通过' if summary['critical_passed'] else '❌ 未通过'}")
    if summary["warnings"]:
        lines.append("")
        lines.append("### ⚠️ 警告")
        for w in summary["warnings"]:
            lines.append(f"- {w}")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="hv-analysis 数据源可用性检测")
    parser.add_argument("--json", action="store_true", help="输出 JSON 格式")
    parser.add_argument("--strict", action="store_true", help="严格模式（任一 iFind 不可用即 exit 1）")
    parser.add_argument("--report-md", action="store_true", help="输出 Markdown 报告片段")
    args = parser.parse_args()

    result = run_check(strict=args.strict)

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.report_md:
        print(format_markdown(result))
    else:
        # 默认人类可读格式
        print("\n" + "=" * 60)
        print(format_markdown(result))
        print("=" * 60)

    if args.strict and not result["summary"]["critical_passed"]:
        sys.exit(1)


if __name__ == "__main__":
    main()