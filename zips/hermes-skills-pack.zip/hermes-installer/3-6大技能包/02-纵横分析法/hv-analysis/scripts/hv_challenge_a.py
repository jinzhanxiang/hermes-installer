#!/usr/bin/env python3
"""
HV-Challenge-A: 质疑节点 A（嫁接 V3 ChallengeAgent 到纵横分析法）

设计原则：
- 嫁接到纵横分析法【横向 lateral】阶段后
- 用 V3 ChallengeAgent 多维度评分（5 维）
- 默认 LLM = MiniMax（不依赖 Gemini）
- LLM 不可用时自动 fallback 到规则评分
- 输出 markdown 片段，可注入横向报告末尾

版本：V1.0.0（首次嫁接）
基线：V1 = input/jneng_photoelectric_20260703/jneng_photoelectric_商业尽调报告_v1_20260703.md
"""

import sys
import os
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# 路径：让 V3 模块可被 import
_V3_ROOT = Path(__file__).resolve().parents[3] / "scripts"
if str(_V3_ROOT) not in sys.path:
    sys.path.insert(0, str(_V3_ROOT))


def run_challenge_a(
    target: str,
    lateral_report: str,
    competitors: Optional[List[str]] = None,
    model: str = "minimax-portal/MiniMax-M3",
) -> Dict:
    """
    质疑节点 A：横向 lateral 报告校验

    5 维评分：
      - coverage_score: 覆盖率（横向对标覆盖几个关键维度）
      - authority_score: 权威性（数据来源可信度）
      - recency_score: 时效性（数据是否近期）
      - relevance_score: 相关性（对标公司是否可比）
      - fact_accuracy_score: 准确性（数字是否前后一致）

    Args:
        target: 研究目标（如：晶能光电）
        lateral_report: 横向 lateral 阶段产出的报告 markdown
        competitors: 竞品列表
        model: LLM 模型，默认 MiniMax-M3

    Returns:
        {
            "passed": bool,
            "score": float,
            "issues": List[str],
            "recommendations": List[str],
            "details": Dict,
            "markdown": str,  # 可注入报告的 markdown 片段
        }
    """
    print(f"[HV-Challenge-A] ▶ 质疑节点 A 开始（target={target}）", file=sys.stderr)

    # 1) 提取横向报告的关键信号
    signals = _extract_lateral_signals(target, lateral_report, competitors)

    # 2) 调用 V3 ChallengeAgent（规则/LLM 双轨）
    challenge_result = _call_challenge_agent(target, signals, model)

    # 3) 生成 markdown 片段
    markdown = _render_challenge_markdown(target, challenge_result)

    result = {
        "passed": challenge_result.get("challenge_passed", False),
        "score": challenge_result.get("score", 0.0),
        "issues": challenge_result.get("issues", []),
        "recommendations": challenge_result.get("recommendations", []),
        "details": challenge_result.get("details", {}),
        "markdown": markdown,
    }

    print(
        f"[HV-Challenge-A] {'✅ 通过' if result['passed'] else '⚠️ 未通过'} "
        f"({result['score']:.1f} 分)",
        file=sys.stderr,
    )
    return result


def _extract_lateral_signals(target, lateral_report, competitors):
    """从横向报告抽取关键信号：指标 / 数据点 / 引用"""
    signals = {
        "target": target,
        "competitors": competitors or [],
        "metrics_found": [],
        "data_points_count": 0,
        "source_citations_count": 0,
        "sections_present": [],
        "report_length": len(lateral_report or ""),
    }

    text = lateral_report or ""
    if not text.strip():
        return signals

    # 检测章节标题
    h_pattern = re.compile(r"^#{1,4}\s+(.+)", re.MULTILINE)
    signals["sections_present"] = h_pattern.findall(text)[:20]

    # 检测关键指标（净利率/ROE/PE/PB）
    metric_keywords = ["净利率", "ROE", "毛利率", "PE", "PB", "市占率", "营收", "净利润",
                       "市盈率", "市净率", "资产负债率", "增长率", "营收增速"]
    for kw in metric_keywords:
        if kw in text:
            signals["metrics_found"].append(kw)

    # 数据点（数字）
    number_pattern = re.compile(r"\d+\.?\d*[%亿万千]|\d+\.\d+%")
    signals["data_points_count"] = len(number_pattern.findall(text))

    # 引用（来源标注）
    source_pattern = re.compile(r"\[(源[：:]|Source|来源).{0,50}?\]|【[^\]]+】|\([Ss]ource[：:]")
    signals["source_citations_count"] = len(source_pattern.findall(text))

    return signals


def _call_challenge_agent(target, signals, model):
    """调用 V3 ChallengeAgent；LLM 不可用时由 V3 内部 fallback"""
    try:
        from research_workflow_v3.modules.challenge_agent import ChallengeAgent

        sub_problems = [
            {"text": f"{target} vs 同行可比公司的核心财务指标对比",
             "type": "lateral_comparison"},
            {"text": f"{target} vs 同行可比公司的盈利能力对比（净利率/ROE/毛利率）",
             "type": "profitability"},
            {"text": f"{target} vs 同行可比公司的估值倍数对比（PE/PB）",
             "type": "valuation"},
            {"text": f"{target} vs 同行可比公司的技术参数对比",
             "type": "technical"},
        ]

        results = [
            {
                "content": (
                    f"横向对标数据包含 {len(signals['metrics_found'])} 个指标、"
                    f"{signals['data_points_count']} 个数据点、"
                    f"{signals['source_citations_count']} 条来源。"
                    f"关键指标: {', '.join(signals['metrics_found'][:5])}。"
                ),
                "source": "lateral_report_extracted",
                "score": 0.85,
            }
            for _ in range(min(4, len(sub_problems)))
        ]

        agent = ChallengeAgent(agent_id="hv-challenge-a", model=model)
        challenge = agent.challenge_retrieval(
            query=target,
            sub_problems=sub_problems,
            results=results,
            local_data_count=1,
        )
        # ChallengeResult 是 dataclass，有 to_dict() 方法
        if hasattr(challenge, "to_dict"):
            return challenge.to_dict()
        return dict(challenge)

    except Exception as e:
        print(f"[HV-Challenge-A] V3 ChallengeAgent 调用失败: {e}，使用规则评分", file=sys.stderr)
        return _rule_based_challenge(signals)


def _rule_based_challenge(signals):
    """规则评分：LLM 不可用时的兜底"""
    details = {
        "coverage_score": 0.0,
        "authority_score": 0.0,
        "recency_score": 0.0,
        "relevance_score": 0.0,
        "fact_accuracy_score": 0.0,
    }

    # 1) 覆盖率：基于指标数量
    metrics_count = len(signals.get("metrics_found", []))
    if metrics_count >= 5:
        details["coverage_score"] = 80
    elif metrics_count >= 3:
        details["coverage_score"] = 65
    elif metrics_count >= 1:
        details["coverage_score"] = 45
    else:
        details["coverage_score"] = 25

    # 2) 权威性：基于数据点
    data_points = signals.get("data_points_count", 0)
    if data_points >= 20:
        details["authority_score"] = 75
    elif data_points >= 10:
        details["authority_score"] = 55
    elif data_points >= 5:
        details["authority_score"] = 40
    else:
        details["authority_score"] = 25

    # 3) 时效性：基于竞品数量（信号很弱）
    details["recency_score"] = 60  # 默认给 60（无法判断）

    # 4) 相关性：基于章节数
    sections = len(signals.get("sections_present", []))
    if sections >= 5:
        details["relevance_score"] = 75
    elif sections >= 3:
        details["relevance_score"] = 55
    else:
        details["relevance_score"] = 30

    # 5) 准确性：基于来源标注
    sources = signals.get("source_citations_count", 0)
    if sources >= 10:
        details["fact_accuracy_score"] = 80
    elif sources >= 3:
        details["fact_accuracy_score"] = 60
    else:
        details["fact_accuracy_score"] = 35

    # 综合分（5 维平均）
    score = sum(details.values()) / 5

    return {
        "score": round(score, 1),
        "challenge_passed": score >= 60,  # 门槛 60
        "issues": [f"规则兜底：5 维度均衡检测{metrics_count}指标 / {data_points}数据点 / {sources}来源"],
        "recommendations": [
            f"补全 {signals['target']} 的指标覆盖" if metrics_count < 5 else "指标覆盖完整",
            f"增强竞品对比深度" if sections < 5 else "章节结构完整",
        ],
        "details": details,
    }


def _render_challenge_markdown(target, challenge_result):
    """生成可注入报告的 markdown 片段"""
    score = challenge_result.get("score", 0.0)
    passed = challenge_result.get("challenge_passed", False)
    issues = challenge_result.get("issues", [])
    recommendations = challenge_result.get("recommendations", [])
    details = challenge_result.get("details", {})

    status_icon = "✅" if passed else "⚠️"
    status_text = "通过" if passed else "未通过"

    md = f"\n\n## 八、质疑节点 A · 横向对标校验 [V3 工作流嫁接]\n\n"
    md += f"> **质疑结论**：{status_icon} **{status_text}**（综合分 {score:.1f} / 100，门槛 60）\n\n"
    md += "### 8.1 五维度评分明细\n\n"
    md += "| 维度 | 评分 | 说明 |\n|------|------|------|\n"

    dim_zh = {
        "coverage_score": "覆盖率",
        "authority_score": "权威性",
        "recency_score": "时效性",
        "relevance_score": "相关性",
        "fact_accuracy_score": "准确性",
    }
    for key, zh in dim_zh.items():
        v = details.get(key, 0.0)
        flag = "🟢" if v >= 70 else ("🟡" if v >= 50 else "🔴")
        md += f"| {zh} | {v:.1f} | {flag} |\n"

    md += f"\n### 8.2 问题清单\n\n"
    if issues:
        for i, issue in enumerate(issues, 1):
            md += f"{i}. {issue}\n"
    else:
        md += "无重大问题。\n"

    md += f"\n### 8.3 改进建议\n\n"
    if recommendations:
        for i, rec in enumerate(recommendations, 1):
            md += f"{i}. {rec}\n"
    else:
        md += "无需补充。\n"

    md += f"\n> *本节由 V3 工作流 ChallengeAgent 自动嫁接生成，模型：MiniMax-M3*\n"

    return md


def attach_challenge_to_report(lateral_md_path: str, target: str = "标的",
                               competitors: Optional[List[str]] = None) -> str:
    """便捷函数：读取横向报告 md → 跑质疑 A → 输出增强版 md 路径"""
    p = Path(lateral_md_path)
    if not p.exists():
        raise FileNotFoundError(lateral_md_path)

    lateral_text = p.read_text(encoding="utf-8")
    result = run_challenge_a(target, lateral_text, competitors)

    new_md = lateral_text + result["markdown"]

    # 输出新文件
    output_path = p.parent / f"{p.stem}_with_challenge_a.md"
    output_path.write_text(new_md, encoding="utf-8")

    print(f"[HV-Challenge-A] ✅ 输出：{output_path}", file=sys.stderr)
    return str(output_path)


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser(description="HV-Challenge-A：质疑节点 A 嫁接器")
    ap.add_argument("--md", required=True, help="横向 lateral 报告 markdown 路径")
    ap.add_argument("--target", default="标的", help="研究目标")
    ap.add_argument("--competitors", help="竞品列表（逗号分隔）")
    args = ap.parse_args()

    competitors = [c.strip() for c in args.competitors.split(",")] if args.competitors else None
    out = attach_challenge_to_report(args.md, args.target, competitors)
    print(out)
