#!/usr/bin/env python3
"""
hv-auto-research.py - 纵横分析法（hv-analysis V3.47.0）一键主入口

V3.47.0 整改（2026-07-09）：
  - 解决 V3.43.0（8K 字）→ V3.45+（21K 字）标准提升带来的工作流不匹配
  - 新增 --write-report 子命令：调用 hv-write-report.py 按 Phase 分块生成报告
  - 保留原渲染/嵌入/推送链路

用法（5 个 Phase 完整流程）：
  # Step 1: 生成 Phase 1 提示词
  python3 hv-auto-research.py 汇天网络科技 --write-report --phase 1 --out-md output/汇天IDC_v3_phase1.md

  # Step 2: 把 Phase 1 提示词发给 LLM，让 LLM 写报告（人工或自动）

  # Step 3: 生成 Phase 2/3/4 提示词，重复 Step 2

  # Step 4: 合并 4 个 Phase 文件 → 最终报告
  python3 hv-auto-research.py 汇天网络科技 --merge-phases \
    output/汇天IDC_v3_phase1.md \
    output/汇天IDC_v3_phase2.md \
    output/汇天IDC_v3_phase3.md \
    output/汇天IDC_v3_phase4.md \
    --final output/汇天IDC_v3_final.md

  # Step 5: 跑门禁校验
  python3 hv-auto-research.py 汇天网络科技 --gate --md output/汇天IDC_v3_final.md --enforce

  # Step 6: 渲染 HTML（可选）
  python3 hv-auto-research.py 汇天网络科技 --render-html --md output/汇天IDC_v3_final.md --title "汇天IDC V3"

  # Step 7: 推送部署（可选）
  python3 hv-auto-research.py 汇天网络科技 --push-deploy --html output/汇天IDC_v3_final_prechart.html

新增子命令（V3.47.0）：
  --write-report     调用 hv-write-report.py 生成指定 Phase 的 LLM 提示词
  --merge-phases     合并多个 Phase 文件 → 最终报告
  --gate             调用 hv-gate.py 校验报告
  --list-chapters    列出 §三 25 章模板

设计哲学：
  - 流程编排层（hv-auto-research.py）：协调各 Phase 的提示词生成 → LLM 写报告 → 合并 → 校验 → 渲染 → 部署
  - 提示词生成层（hv-write-report.py）：按 §三 25 章模板输出 LLM 提示词
  - 报告生成层（LLM）：按提示词写各 Phase 报告（人工/自动调度）
  - 门禁校验层（hv-gate.py）：10 项硬约束强制校验
  - 渲染层（report-html-publish/md_to_html_v3422.py）：V3.42.2+ HTML 渲染
"""
import sys
import os
import argparse
import subprocess
from datetime import datetime
from pathlib import Path

WORKSPACE_B = Path(os.path.expanduser("~/Documents/OpenClaw-Workspace-research"))
SKILL_ROOT = Path(os.path.expanduser("~/.openclaw/workspace-research/skills/hv-analysis"))
SCRIPTS_DIR = SKILL_ROOT / "scripts"
CHARTS_DIR = SCRIPTS_DIR / "charts"
HTML_PUBLISH = Path(os.path.expanduser("~/.openclaw/workspace-research/skills/report-html-publish/scripts"))


def banner(text):
    bar = "=" * 70
    print(f"\n{bar}\n  {text}\n{bar}")


def step(name):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"\n[{ts}] ▶ {name}")


def run(cmd, cwd=None, check=True):
    """Run shell command and return CompletedProcess."""
    if isinstance(cmd, str):
        cmd = cmd.split()
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, check=check)


def call_python_script(script_path: Path, args: list, description: str = "") -> int:
    """通用 Python 脚本调用"""
    cmd = ["/usr/bin/python3", str(script_path)] + args
    if description:
        print(f"   命令: {description}")
    print(f"   {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.stdout:
        print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)
    return result.returncode


def cmd_write_report(project: str, phase: int, output_md: str):
    """调用 hv-write-report.py 生成 Phase 提示词"""
    step(f"生成 Phase {phase} 提示词")
    
    write_script = SCRIPTS_DIR / "hv-write-report.py"
    rc = call_python_script(
        write_script,
        ["--phase", str(phase), "--project", project, "--output", output_md],
        description=f"Phase {phase} → {output_md}"
    )
    
    if rc != 0:
        print(f"❌ 生成失败")
        return rc
    
    # 检查文件
    p = Path(output_md)
    if not p.exists() or p.stat().st_size < 1000:
        print(f"❌ 提示词文件未生成或过小: {p}")
        return 1
    
    print(f"✅ 提示词已生成: {p.name}")
    print(f"   字数: {p.stat().st_size:,} bytes")
    print()
    print(f"📖 下一步（人工/自动）:")
    print(f"   1. 读取提示词: cat {p}")
    print(f"   2. 发给 LLM（Claude Code / Cursor / 直接调用）让 LLM 写报告")
    print(f"   3. 保存 LLM 输出到: output/汇天IDC_v3_phase{phase}_content.md")
    print(f"   4. 完成后跑下一 Phase（--phase {phase+1}）")
    return 0


def cmd_merge_phases(project: str, phase_files: list, final_md: str):
    """合并多个 Phase 文件 → 最终报告"""
    step(f"合并 {len(phase_files)} 个 Phase 文件")
    
    write_script = SCRIPTS_DIR / "hv-write-report.py"
    rc = call_python_script(
        write_script,
        ["--merge"] + phase_files + ["--final", final_md],
        description=f"合并 → {final_md}"
    )
    return rc


def cmd_gate(project: str, md_file: str, mode: str, html: str, enforce: bool):
    """调用 hv-gate.py 校验报告"""
    step("跑门禁校验")
    
    gate_script = SCRIPTS_DIR / "hv-gate.py"
    args = [project, md_file, "--mode", mode]
    if enforce:
        args.append("--enforce")
    if html:
        args.extend(["--html", html])
    
    rc = call_python_script(
        gate_script,
        args,
        description=f"门禁校验 → {md_file}"
    )
    
    if rc == 0:
        print(f"\n🎉 门禁通过！")
    else:
        print(f"\n❌ 门禁未通过（退出码 {rc}）")
    return rc


def cmd_render_html(project: str, md_file: str, title: str):
    """HTML 渲染（V3.42.2+ 极简单色）"""
    step("HTML 渲染：md_to_html_v3422.py")
    
    md_p = Path(md_file)
    if not md_p.exists():
        print(f"❌ MD 文件不存在: {md_p}")
        return 1
    
    html_out = md_p.with_name(md_p.stem + "_prechart.html")
    
    cmd = [
        "/usr/bin/python3",
        str(HTML_PUBLISH / "md_to_html_v3422.py"),
        str(md_p),
        "-o", str(html_out),
        "-t", title or md_p.stem,
    ]
    print(f"   命令: {' '.join(cmd)}")
    result = run(cmd, check=False)
    if result.returncode != 0:
        print(f"   ❌ 渲染失败: {result.stderr[:500]}")
        return result.returncode
    
    size = html_out.stat().st_size
    print(f"   ✅ HTML 生成: {html_out.name} ({size/1024:.1f} KB)")
    
    # 自动注入图表（如有 charts/ 目录）
    charts_dir = md_p.parent.parent / "charts"
    if charts_dir.exists():
        svgs = list(charts_dir.glob("*.svg"))
        if svgs:
            print(f"   📊 发现 {len(svgs)} 张 SVG，自动注入")
            inject_cmd = ["/usr/bin/python3", str(CHARTS_DIR / "inject_charts_into_html.py"), str(html_out)]
            inject_result = run(inject_cmd, check=False)
            if inject_result.returncode == 0:
                print(f"   ✅ 图表已注入")
            else:
                print(f"   ⚠️ 图表注入失败（可能非关键）")
    
    return 0


def cmd_fusion_trigger(project: str, target: str, deadline_minutes: int = 30, blocking: bool = True):
    """V3.48.0+ 自动触发 Hermes 融合（必调用，除非已手工跑过）"""
    step(f"触发 Hermes 并行融合：{project} → {target}")

    fusion_script = SCRIPTS_DIR / "hv_fusion_trigger.py"
    if not fusion_script.exists():
        print(f"❌ hv_fusion_trigger.py 不存在: {fusion_script}")
        return 1

    if blocking:
        # 派单 + 阻塞等待（30 分钟超时）
        args = [
            "dispatch",
            "--project", project,
            "--target", target,
            "--deadline-minutes", str(deadline_minutes),
        ]
        print(f"   模式：派单 + 阻塞等待（最多 {deadline_minutes}min）")
    else:
        # 仅派单（不阻塞，Phase 3 末尾再单独 poll）
        args = [
            "trigger",
            "--project", project,
            "--target", target,
            "--deadline-minutes", str(deadline_minutes),
        ]
        print(f"   模式：仅派单（非阻塞）")

    cmd = ["/usr/bin/python3", str(fusion_script)] + args
    print(f"   {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=False, text=True)
    if result.returncode != 0 and result.returncode != 2:
        # 2 = 超时（不视为致命失败）
        print(f"⚠️ Hermes 派单异常 (returncode={result.returncode})，但 Phase 3 主流程继续")
    return 0


def cmd_fusion_check(project: str):
    """检查项目是否已有 in-flight Hermes 任务"""
    step(f"检查 Hermes in-flight 任务：{project}")
    fusion_script = SCRIPTS_DIR / "hv_fusion_trigger.py"
    if not fusion_script.exists():
        print(f"❌ hv_fusion_trigger.py 不存在")
        return 1
    cmd = ["/usr/bin/python3", str(fusion_script), "check", "--project", project]
    return subprocess.run(cmd).returncode


def cmd_push_deploy(project: str, html_file: str, report_type: str = "decision"):
    """推送 project 代理部署（仅打印指令，实际 sessions_send 由调用方执行）"""
    step(f"推送部署：{html_file}")
    print(f"   sessions_send sessionKey='agent:project:feishu:group:oc_bcd1c4e14cf7eda119b8236d76691edc'")
    print(f"   message:")
    print(f"""   【部署任务 · V3.47.0】
- 项目名：{project}
- 报告类型：{report_type}
- 本地文件路径：{html_file}
- 部署要求：GH Pages {project}-report 仓库""")
    return 0


def cmd_list_chapters():
    """列出 25 章模板"""
    write_script = SCRIPTS_DIR / "hv-write-report.py"
    rc = call_python_script(write_script, ["--list-chapters"], description="列出 25 章模板")
    return rc


def main():
    parser = argparse.ArgumentParser(
        description="hv-auto-research.py - 纵横分析法 V3.47.0 一键主入口",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
[V3.47.0 新增子命令]
  --write-report   生成指定 Phase 的 LLM 提示词
  --merge-phases   合并多个 Phase 文件
  --gate           门禁校验
  --list-chapters  列出 25 章模板

[V3.48.0 新增子命令 — Hermes 并行融合]
  --fusion-trigger  触发 Hermes 独立研究（默认阻塞 30min）
  --fusion-check    检查项目是否已有 in-flight Hermes 任务

[默认 Hermes 触发提醒]
  Phase 3 完成后必须跑：
    python3 hv-auto-research.py <项目> --fusion-trigger \\
        --target "<公司全称>" --deadline-minutes 30
  报告完成后轮询：
    python3 hv_fusion_trigger.py list
    python3 hv_fusion_trigger.py poll --task-id <id> --timeout-minutes 30

[典型工作流]
  1) python3 hv-auto-research.py <项目> --write-report --phase 1 --out-md output/p1.md
  2) 把 p1.md 提示词发给 LLM，LLM 写报告 → 保存到 output/p1_content.md
  3) 重复 1-2 步骤完成 Phase 2/3/4
  4) python3 hv-auto-research.py <项目> --merge-phases p1.md p2.md p3.md p4.md --final output/final.md
  5) python3 hv-auto-research.py <项目> --gate --md output/final.md --enforce
  6) python3 hv-auto-research.py <项目> --render-html --md output/final.md
  7) python3 hv-auto-research.py <项目> --push-deploy --html output/final_prechart.html
        """
    )
    parser.add_argument("project", help="项目名称（如 汇天网络科技）")
    parser.add_argument("--mode", choices=["analysis", "decision"], default="decision",
                        help="报告模式：decision（决策 25 章，默认）或 analysis（研究 21 章）")
    
    # V3.47.0 新增子命令
    sub_cmd = parser.add_mutually_exclusive_group(required=True)
    sub_cmd.add_argument("--write-report", action="store_true", help="生成 Phase 提示词")
    sub_cmd.add_argument("--merge-phases", action="store_true", help="合并多个 Phase 文件")
    sub_cmd.add_argument("--gate", action="store_true", help="门禁校验")
    sub_cmd.add_argument("--render-html", action="store_true", help="HTML 渲染")
    sub_cmd.add_argument("--push-deploy", action="store_true", help="推送部署（仅打印指令）")
    sub_cmd.add_argument("--list-chapters", action="store_true", help="列出 25 章模板")
    sub_cmd.add_argument("--fusion-trigger", action="store_true", help="V3.48.0+ 触发 Hermes 融合")
    sub_cmd.add_argument("--fusion-check", action="store_true", help="检查项目 Hermes in-flight 任务")
    
    # 各子命令参数
    parser.add_argument("--phase", type=int, choices=[1, 2, 3, 4], help="Phase 编号（仅 --write-report 用）")
    parser.add_argument("--out-md", help="提示词输出文件路径（仅 --write-report 用）")
    parser.add_argument("--md", help="MD 文件路径（--gate/--render-html 用）")
    parser.add_argument("--html", help="HTML 文件路径（--gate/--push-deploy 用）")
    parser.add_argument("--enforce", action="store_true", help="门禁失败时退出码非 0")
    parser.add_argument("--title", help="HTML 标题（--render-html 用）")
    parser.add_argument("--final", help="最终输出文件路径（--merge-phases 用）")
    parser.add_argument("--target", help="标的（如 汇天网络科技有限公司，--fusion-trigger 用）")
    parser.add_argument("--deadline-minutes", type=int, default=30, help="Hermes 任务时限（--fusion-trigger 用）")
    parser.add_argument("--non-blocking", action="store_true", help="仅派单不阻塞（--fusion-trigger 用）")
    parser.add_argument("phase_files", nargs="*", help="Phase 文件列表（--merge-phases 用）")
    
    args = parser.parse_args()
    
    banner(f"hv-analysis V3.47.0 - {args.project} - {args.mode.upper()} 模式")
    
    # 路由到对应子命令
    if args.list_chapters:
        return cmd_list_chapters()
    
    elif args.write_report:
        if not args.phase or not args.out_md:
            print("❌ --write-report 必须配合 --phase 和 --out-md")
            return 1
        return cmd_write_report(args.project, args.phase, args.out_md)
    
    elif args.merge_phases:
        if len(args.phase_files) < 2 or not args.final:
            print("❌ --merge-phases 必须指定 ≥2 个 phase 文件 + --final")
            return 1
        return cmd_merge_phases(args.project, args.phase_files, args.final)
    
    elif args.gate:
        if not args.md:
            print("❌ --gate 必须配合 --md")
            return 1
        return cmd_gate(args.project, args.md, args.mode, args.html or "", args.enforce)
    
    elif args.render_html:
        if not args.md:
            print("❌ --render-html 必须配合 --md")
            return 1
        return cmd_render_html(args.project, args.md, args.title)
    
    elif args.push_deploy:
        if not args.html:
            print("❌ --push-deploy 必须配合 --html")
            return 1
        return cmd_push_deploy(args.project, args.html, args.mode)

    elif args.fusion_trigger:
        if not args.target:
            print("❌ --fusion-trigger 必须配合 --target")
            return 1
        return cmd_fusion_trigger(
            project=args.project,
            target=args.target,
            deadline_minutes=args.deadline_minutes,
            blocking=not args.non_blocking,
        )

    elif args.fusion_check:
        return cmd_fusion_check(args.project)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())