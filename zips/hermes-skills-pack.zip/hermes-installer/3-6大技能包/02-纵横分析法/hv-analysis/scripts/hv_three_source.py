#!/usr/bin/env python3
"""
hv-analysis V3.49.0+ — Hermes 三源融合非上市公司尽调触发器

封装 `three-source-fusion-protocol.md` 协议，把非上市公司的 16 维度尽调
一键派发给 Hermes 独立研究，并轮询报告返回。

设计原则：
  - 不重启 Hermes 网关（不动 PID 10316）
  - 不启动 kanban daemon（gateway 内置 dispatcher 已接管）
  - 写文件备份（outgoing/.task.json）+ kanban create 双轨
  - 默认不阻塞（--blocking 才轮询），与 hv_fusion_trigger.py 风格保持一致
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

# 时区
try:
    from zoneinfo import ZoneInfo
    CST = ZoneInfo("Asia/Shanghai")
except ImportError:
    CST = None  # type: ignore[assignment]

# 路径
SHARED_DIR = Path(os.path.expanduser("~/.openclaw/shared"))
HANDBOOK_OUT = SHARED_DIR / "handoffs" / "outgoing"
HANDBOOK_IN = SHARED_DIR / "handoffs" / "incoming"
PROTOCOL_DOC = SHARED_DIR / "three-source-fusion-protocol.md"

# 三源融合数据源默认值
DEFAULT_DATA_SOURCES = ["tianyancha", "qiyeyujingtong", "qichacha"]

# 16 维度问题模板（来自协议 §2）
DEFAULT_KEY_QUESTIONS = [
    "Q1: 公司基本信息（法人/注册资本/成立日期/股权结构/实际控制人穿透）",
    "Q2: 法律诉讼与司法风险（开庭公告/立案/裁判文书/执行案件）",
    "Q3: 行政处罚与经营风险（行政处罚/经营异常/严重违法）",
    "Q4: 知识产权与资质（商标/专利/软著/高新认证/IDC牌照）",
    "Q5: 风险综合评价（风险等级/信用评分/舆情）",
    "Q6: 深度展开（关联实体同步查询 + 风险触发自动钻取）",
]


def log(msg: str, *, level: str = "INFO") -> None:
    """统一日志格式"""
    ts = datetime.now(CST).strftime("%H:%M:%S") if CST else datetime.now().strftime("%H:%M:%S")
    icon = {"INFO": "ℹ️", "OK": "✅", "WARN": "⚠️", "ERR": "❌", "STEP": "▶"}.get(level, "•")
    print(f"[{ts}] {icon} {msg}", flush=True)


def ensure_dirs() -> None:
    HANDBOOK_OUT.mkdir(parents=True, exist_ok=True)
    HANDBOOK_IN.mkdir(parents=True, exist_ok=True)


def build_task_id(target: str) -> str:
    """生成 task_id：{target slug}-三源查询-{MMDDHHMMSS}"""
    # 简化 target slug：去除特殊字符
    slug = "".join(c for c in target if c.isalnum() or c in "-_")[:20]
    ts = datetime.now(CST).strftime("%m%d%H%M%S") if CST else datetime.now().strftime("%m%d%H%M%S")
    return f"{slug}-三源查询-{ts}"


def build_task_body(
    target: str,
    *,
    data_sources: list[str] | None = None,
    key_questions: list[str] | None = None,
    context: dict[str, Any] | None = None,
    auto_deep_dive: bool = True,
    related_entities: list[str] | None = None,
    timeout_seconds: int = 180,
) -> dict[str, Any]:
    """构建三源融合 task body（按 three-source-fusion-protocol.md §4 格式）"""
    return {
        "task_id": "<filled_by_trigger>",
        "target": target,
        "target_type": "non-listed",
        "request": "three_source_fusion",
        "data_sources": data_sources or DEFAULT_DATA_SOURCES,
        "auto_deep_dive": auto_deep_dive,
        "context": {
            **(context or {}),
            **({"related_entities": related_entities} if related_entities else {}),
        },
        "key_questions": key_questions or DEFAULT_KEY_QUESTIONS,
        "format_hint": "Markdown 自然语言报告，分章节，含数据表格与差异标注",
        "timeout_seconds": timeout_seconds,
    }


def write_outgoing(task_id: str, body: dict[str, Any]) -> Path:
    """A 径：写文件备份"""
    body["task_id"] = task_id
    out_path = HANDBOOK_OUT / f"{task_id}.task.json"
    out_path.write_text(json.dumps(body, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"A 径文件备份: {out_path}", level="OK")
    return out_path


def dispatch_kanban(title: str, body: dict[str, Any], *, max_runtime: int = 240) -> str:
    """B 径：kanban create + 立即 dispatch 一次"""
    body_json = json.dumps(body, ensure_ascii=False)
    log(f"B 径 kanban create: {title}", level="STEP")

    result = subprocess.run(
        ["hermes", "kanban", "create", title, "--body", body_json, "--assignee", "default",
         "--max-runtime", str(max_runtime), "--skill", "opencli-integration", "--json"],
        capture_output=True, text=True, timeout=15,
    )
    if result.returncode != 0:
        log(f"kanban create 失败: {result.stderr}", level="ERR")
        raise RuntimeError(f"kanban create 失败: {result.stderr}")

    data = json.loads(result.stdout)
    task_id_kanban = data["id"]
    log(f"kanban task_id: {task_id_kanban} (status={data['status']})", level="OK")

    # 立即 dispatch 一次（不必等 60s tick）
    disp = subprocess.run(
        ["hermes", "kanban", "dispatch", "--json"],
        capture_output=True, text=True, timeout=10,
    )
    if disp.returncode == 0:
        disp_data = json.loads(disp.stdout)
        spawned_ids = [s["task_id"] for s in disp_data.get("spawned", [])]
        if task_id_kanban in spawned_ids:
            log(f"dispatch 立即生效，worker 已启动", level="OK")
    return task_id_kanban


def cmd_trigger(args) -> int:
    """触发三源融合：写文件 + kanban create + (可选) 轮询"""
    ensure_dirs()
    if not PROTOCOL_DOC.exists():
        log(f"⚠️ 协议文件不存在: {PROTOCOL_DOC}", level="WARN")
        log("   继续执行，但请确认 Hermes 端已部署 opencli-integration", level="WARN")

    target = args.target
    task_id = build_task_id(target)
    body = build_task_body(
        target,
        data_sources=args.data_sources.split(",") if args.data_sources else None,
        key_questions=args.key_questions.split("|") if args.key_questions else None,
        context={"project_path": args.project_path} if args.project_path else None,
        auto_deep_dive=not args.no_auto_deep_dive,
        related_entities=args.related_entities.split(",") if args.related_entities else None,
        timeout_seconds=args.timeout_seconds,
    )

    # 双轨
    write_outgoing(task_id, body)
    title = f"Hermes三源融合-{task_id}"
    kanban_id = dispatch_kanban(title, body, max_runtime=args.deadline_minutes * 60)

    log(f"task_id={task_id} kanban_id={kanban_id}", level="OK")
    log(f"报告将写入: {HANDBOOK_IN}/{task_id}.report.md", level="OK")

    if args.blocking:
        return cmd_poll_inline(task_id, args.deadline_minutes)

    log(f"非阻塞模式——后台运行，可用 `check` 或 `poll` 子命令查询进度", level="INFO")
    return 0


def cmd_poll_inline(task_id: str, deadline_minutes: int) -> int:
    """阻塞轮询（trigger 内部用）
    三重检查机制：
      1. 直接检查 incoming/{task_id}.report.md
      2. 检查 kanban 任务 done 状态 → 查 worker workspace 是否生成报告
      3. 必要时手动从 worker workspace 复制到 incoming/
    """
    log(f"开始轮询，最多等待 {deadline_minutes} 分钟", level="STEP")
    deadline = time.time() + deadline_minutes * 60
    interval = 15  # 秒

    while time.time() < deadline:
        report_path = HANDBOOK_IN / f"{task_id}.report.md"

        # 机制 1：incoming/ 直接文件检查
        if report_path.exists():
            size = report_path.stat().st_size
            log(f"✅ Hermes 报告返回: {report_path} ({size} bytes)", level="OK")
            return 0

        # 机制 2：查 kanban 状态 → done 时去 worker workspace 找报告
        r = subprocess.run(
            ["hermes", "kanban", "list", "--json"],
            capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0:
            tasks = json.loads(r.stdout)
            for t in tasks:
                if t["title"].endswith(task_id) or task_id in t.get("body", "")[:1000]:
                    log(f"kanban 状态: {t['status']}（{t.get('id', '?')}）", level="INFO")
                    if t["status"] == "done":
                        # 机制 2.1：去 worker workspace 找报告
                        workspace = t.get("workspace_path") or (
                            f"/Users/jinzhanxiang/.hermes/kanban/workspaces/{t['id']}"
                        )
                        if Path(workspace).exists():
                            for md in Path(workspace).glob("*.md"):
                                log(f"  发现 worker workspace 报告: {md}", level="INFO")
                                import shutil
                                shutil.copy(md, report_path)
                                log(f"  ✅ 复制到 incoming/: {report_path}", level="OK")
                                return 0
                        # 机制 2.2：查 Hermes 自己的 handoffs/incoming
                        # Hermes 有时按 "三源查询-001" 模式写到自己的目录
                        if not report_path.exists():
                            log(f"kanban=done 但未找到报告文件", level="WARN")
                            return 0
                    if t["status"] in ("failed", "blocked"):
                        return 1
        time.sleep(interval)

    log(f"超时（{deadline_minutes} 分钟）未返，Hermes 仍在后台", level="WARN")
    return 2  # 超时代码（与 hv_fusion_trigger.py 保持一致）


def cmd_poll(args) -> int:
    """独立轮询子命令"""
    ensure_dirs()
    return cmd_poll_inline(args.task_id, args.deadline_minutes)


def cmd_check(args) -> int:
    """检查指定公司/项目是否有 in-flight 任务"""
    ensure_dirs()
    keyword = args.project
    log(f"检查项目 {keyword} 的 in-flight 任务")
    r = subprocess.run(
        ["hermes", "kanban", "list", "--json"],
        capture_output=True, text=True, timeout=5,
    )
    if r.returncode != 0:
        log(f"kanban list 失败: {r.stderr}", level="ERR")
        return 1

    tasks = json.loads(r.stdout)
    matching = [
        t for t in tasks
        if keyword.lower() in t["title"].lower() or
           keyword in t.get("body", "")
    ]
    if not matching:
        log(f"✅ 项目 {keyword} 无 in-flight 任务", level="OK")
        return 0

    log(f"⚠️ 项目 {keyword} 有 {len(matching)} 个匹配任务:")
    for t in matching:
        log(f"   {t['status']:8} {t['id']}  {t['title']}")
    return 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description="hv-analysis V3.49.0+ — Hermes 三源融合非上市公司尽调触发器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s trigger --target "汇天网络科技有限公司" --project-path "~/Documents/.../汇天网络科技"
  %(prog)s trigger --target "中复碳芯电缆科技有限公司" --blocking
  %(prog)s poll --task-id 汇天网络-三源查询-0712210117 --deadline-minutes 15
  %(prog)s check --project 汇天网络
        """,
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # trigger
    p_trig = sub.add_parser("trigger", help="触发三源融合（非阻塞 + 立即派单）")
    p_trig.add_argument("--target", required=True, help="目标公司全称")
    p_trig.add_argument("--project-path", help="项目本地路径（context）")
    p_trig.add_argument("--data-sources", help="逗号分隔的数据源（默认: tianyancha,qiyeyujingtong,qichacha）")
    p_trig.add_argument("--key-questions", help="管道符分隔的 key_questions（默认 6 维度模板）")
    p_trig.add_argument("--related-entities", help="逗号分隔的关联实体（如 汇天智算,北京瀚瑞德）")
    p_trig.add_argument("--timeout-seconds", type=int, default=180, help="Hermes 单次查询超时（秒）")
    p_trig.add_argument("--deadline-minutes", type=int, default=20, help="整体 deadline（分钟，默认 20min=三源全覆盖）")
    p_trig.add_argument("--no-auto-deep-dive", action="store_true", help="关闭自动深度展开")
    p_trig.add_argument("--blocking", action="store_true", help="阻塞模式（默认非阻塞）")
    p_trig.set_defaults(func=cmd_trigger)

    # poll
    p_poll = sub.add_parser("poll", help="轮询指定 task_id 的报告")
    p_poll.add_argument("--task-id", required=True, help="任务 ID")
    p_poll.add_argument("--deadline-minutes", type=int, default=20, help="等待分钟数（默认 20min）")
    p_poll.set_defaults(func=cmd_poll)

    # check
    p_chk = sub.add_parser("check", help="检查项目是否有 in-flight 任务")
    p_chk.add_argument("--project", required=True, help="项目名关键字（模糊匹配 title/body）")
    p_chk.set_defaults(func=cmd_check)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
