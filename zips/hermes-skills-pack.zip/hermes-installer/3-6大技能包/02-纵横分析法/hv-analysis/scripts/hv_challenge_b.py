#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HV Challenge B V2.0 · 质疑节点 B 防幻觉模式
=============================================

【V2.0 重大变更】2026-07-04 主公指示：
质疑的本质 = 防幻觉，不是给报告打综合分。

【V2.0 输出（6 项）】
1. 事实核查表（主表）：数据点 → 来源标注 → 一致性 → 可靠性 → 多源验证
2. 来源真实性清单：[源:xx] → 物理存在 → 被引用次数 → 权威性
3. 推理链验证：前提 → 中间步 → 结论 → 是否跳跃
4. 一致性检查：报告内同样数据前后矛盾检测
5. 幻觉清单：凭空数字 / 幽灵来源 / 跳跃推理
6. 多源比对（新增）：同一数据 → ≥2 源是否一致

【多源比对规则】主公 2026-07-04 10:40 指示
- 金融数据：iFind MX 主源 + Tushare/AKShare/Equal-Data/iFind 备源
- 事实性数据：SearXNG 主源 + 企查查/天眼查 备源
- ≥2 源一致 = ✅ [已证]
- 1 源 = ⚠️ [待核实]
- 0 源 = ❌ [幻觉]
- 来源未核实 = [未核实]

【取消项】
- ❌ 综合分（5/6 维度均分）
- ❌ "是否升基线"判据
- ❌ 综合分门槛 70

【门槛重新定义】
- 任何幻觉数字 → 报告自动标 [幻觉]
- 任何幽灵来源 → 报告自动标 [未核实]（不删除）
- 任何跳跃推理 → 报告自动标 [跳跃]

【嫁接位置】hv_full_research.py 中 cross_insight 阶段之后

作者: research agent (主公指示 V2.0)
版本: V2.0 - 2026-07-04（防幻觉模式）
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Dict, List, Tuple

# ============================================================
# 路径设置
# ============================================================
_THIS_FILE = Path(__file__).resolve()
_PROJECT_ROOT = _THIS_FILE.parents[3]
_V3_ROOT = _PROJECT_ROOT / "scripts"
sys.path.insert(0, str(_V3_ROOT))


# ============================================================
# 数据源架构（主公 2026-07-04 10:40 指示）
# ============================================================

FINANCIAL_DATA_SOURCES = {
    "primary": "iFind MX",
    "secondary": ["Tushare", "AKShare", "Equal-Data", "iFind 投研"],
}

FACTUAL_DATA_SOURCES = {
    "primary": "SearXNG",
    "secondary": ["企查查", "天眼查", "启信宝"],
}


# ============================================================
# 文本抽取（V2.0 强化）
# ============================================================

# 数字 / 百分比 / 金额 抽取（V2.0 严格版）
# 匹配"165.4亿"、"32亿元"、"22.76%"、"68x"、"3.2%"等真实金融数字
NUMERIC_WITH_UNIT_PATTERN = re.compile(
    r"(\d{1,3}(?:,\d{3})*(?:\.\d+)?)"  # 数字（含千分位、小数）
    r"\s*(亿|万元|万元|亿元|万亿|%|倍|x)"  # 单位
)

# 关键值匹配（指标+数字+单位的紧凑形式）
FINANCIAL_VALUE_PATTERN = re.compile(
    r"(营收|收入|净利|净利润|净利率|毛利率|ROE|净资产收益率|"
    r"PE|市盈率|估值|市值|市占率|市场份额|EPS|每股收益|经营性现金流|"
    r"资产总额|净资产|负债率|存货周转)"
    r"[^。\n；]*?"
    r"(\d{1,3}(?:,\d{3})*(?:\.\d+)?\s*(?:亿|万元|%|倍|x))"
)

# 营收 / 净利 / ROE / PE 等核心指标关键词（用于 trigger 上下文搜索）
FINANCIAL_KEYWORDS = {
    "营收": r"营收|收入|销售额",
    "净利": r"净利|净利润|归母净利",
    "净利率": r"净利率|净利润率",
    "毛利率": r"毛利率",
    "ROE": r"ROE|净资产收益率",
    "PE": r"PE\s*\d+|市盈率\s*\d+",
    "估值": r"估值\s*\d+[-~]\d+\s*亿|估值\s*\d+\s*亿",
    "市值": r"市值\s*\d+\s*亿",
    "市占率": r"市占率\s*\d+\s*%|市场份额\s*\d+\s*%",
}

FACTUAL_KEYWORDS = {
    "成立时间": r"成立.{0,5}\d{4}\s*年|注册.{0,5}\d{4}\s*年",
    "上市时间": r"上市.{0,5}\d{4}\s*年|IPO.{0,5}\d{4}",
    "实控人": r"实控人\s*[：:]\s*[\u4e00-\u9fa5]+|实际控制人\s*[：:]\s*[\u4e00-\u9fa5]+",
    "股东": r"前\s*\d+\s*大股东|TOP\s*\d+\s*股东",
    "技术路线": r"硅衬底|蓝宝石|SiC\s*|GaN|GaAs",
    "对标公司": r"三安光电|华灿光电|兆驰股份|蔚蓝锂芯|鸿利智汇|乾照光电",
}


def extract_financial_data_points(draft: str) -> List[Dict]:
    """V2.0 新增：从报告抽取所有金融数据点（带上下文）"""
    data_points = []
    seen_values = set()  # 去重

    # 先按段落分割
    paragraphs = re.split(r"\n\s*\n", draft)

    for para in paragraphs:
        para = para.strip()
        if not para or len(para) > 1500:
            continue

        # 优先使用严格模式：关键词 + 数字 + 单位
        for m in FINANCIAL_VALUE_PATTERN.finditer(para):
            category = m.group(1)
            value = m.group(2).strip()

            # 去重
            dedup_key = (category, value, para[:80])
            if dedup_key in seen_values:
                continue
            seen_values.add(dedup_key)

            # 推断更细的类别
            if "营收" in category or "收入" in category:
                category = "营收"
            elif "净利率" in category or "净利润率" in category:
                category = "净利率"
            elif "毛利率" in category:
                category = "毛利率"
            elif "净利" in category:
                category = "净利"
            elif "PE" in category or "市盈率" in category:
                category = "PE"
            elif "ROE" in category:
                category = "ROE"
            elif "估值" in category:
                category = "估值"
            elif "市值" in category:
                category = "市值"
            elif "市占" in category:
                category = "市占率"
            elif "现金流" in category:
                category = "现金流"
            elif "资产" in category or "净资产" in category:
                category = "资产/净资产"
            elif "存货" in category or "周转" in category:
                category = "运营效率"

            data_points.append({
                "category": category,
                "value": value,
                "context": para[:200],
                "paragraph": para[:300],
                "data_type": "financial",
            })

    return data_points


def extract_factual_data_points(draft: str) -> List[Dict]:
    """V2.0 新增：从报告抽取所有事实性数据点"""
    data_points = []
    paragraphs = re.split(r"\n\s*\n", draft)

    for para in paragraphs:
        para = para.strip()
        if not para or len(para) > 1000:
            continue

        for category, kw_pattern in FACTUAL_KEYWORDS.items():
            if re.search(kw_pattern, para):
                data_points.append({
                    "category": category,
                    "context": para[:200],
                    "paragraph": para[:300],
                    "data_type": "factual",
                })
                break
    return data_points


def extract_all_data_points(draft: str) -> Tuple[List[Dict], List[Dict]]:
    """V2.0 主入口：抽取所有数据点（金融 + 事实）"""
    financial = extract_financial_data_points(draft)
    factual = extract_factual_data_points(draft)
    return financial, factual


def extract_citations(draft: str) -> List[Dict]:
    """抽取所有来源标注（兼容多种格式）"""
    citations = []
    # [源:xx] 格式
    src_pat = re.compile(r"\[源:([^\]]+)\]")
    for m in src_pat.finditer(draft):
        citations.append({"source": m.group(1).strip(), "format": "bracket"})
    # 【来源：xx】 格式
    src_pat2 = re.compile(r"【来源：([^】]+)】")
    for m in src_pat2.finditer(draft):
        citations.append({"source": m.group(1).strip(), "format": "braces"})
    # [可信度:X] 格式
    cred_pat = re.compile(r"\[可信度:([A-F])\]")
    for m in cred_pat.finditer(draft):
        citations.append({"credibility": m.group(1).strip(), "format": "credibility"})
    return citations


def extract_logic_chains(draft: str) -> List[Dict]:
    """V2.0: 抽取逻辑链，标记是否跳跃"""
    paragraphs = re.split(r"\n\s*\n", draft)
    chains = []
    chain_indicators = [
        ("基于", "→"),
        ("因此", "→"),
        ("表明", "→"),
        ("由于", "→"),
        ("由此可见", "→"),
        ("综上", "→"),
        ("所以", "→"),
    ]

    for p in paragraphs:
        p = p.strip()
        if not p or len(p) >= 800:
            continue
        if not any(k in p for k, _ in chain_indicators):
            continue

        # 找推理指示词
        indicator = None
        for k, _ in chain_indicators:
            if k in p:
                indicator = k
                break

        # 拆分前提 / 结论
        parts = re.split(r"[，。；]", p)
        if len(parts) < 2:
            continue
        premise = parts[0].strip()
        conclusion = parts[-1].strip()

        # 跳跃判断：0 跳 = 直接结论 = 跳跃
        is_jump = len(parts) <= 2  # 只有前提和结论，中间无推理步骤

        chains.append({
            "indicator": indicator,
            "premise": premise[:150],
            "conclusion": conclusion[:150],
            "middle_steps": parts[1:-1] if len(parts) > 2 else [],
            "is_jump": is_jump,
            "paragraph": p[:300],
        })
    return chains[:10]


def check_internal_consistency(draft: str) -> List[Dict]:
    """V2.0: 一致性检查 - 同数据前后矛盾"""
    # 找数字 + 上下文
    inconsistencies = []

    # 抽取所有数字
    data_point_pattern = re.compile(
        r"(三安|华灿|兆驰|蔚蓝|鸿利|乾照|晶能|.{2,15}?)(?:2024|2023|2022)?"
        r"(?:营收|净利|净利率|ROE|PE|估值|市值|市占率)"
        r"[^。\n]*?(\d{1,3}(?:,\d{3})*(?:\.\d+)?)\s*(亿|万|%|倍)?"
    )
    seen_values = {}  # key=(company, category) -> [(value, unit, location)]

    for m in data_point_pattern.finditer(draft):
        company = m.group(1).strip()
        value = m.group(2)
        unit = m.group(3) or ""
        full_text = m.group(0)
        # 推断类别
        category = "未知"
        for cat, kw_pat in FINANCIAL_KEYWORDS.items():
            if re.search(kw_pat, full_text):
                category = cat
                break

        key = (company, category)
        if key not in seen_values:
            seen_values[key] = []
        seen_values[key].append({
            "value": value,
            "unit": unit,
            "context": full_text[:150],
        })

    # 检查同一 key 是否有多版本
    for key, occurrences in seen_values.items():
        unique_values = set(o["value"] for o in occurrences)
        if len(unique_values) > 1:
            inconsistencies.append({
                "company": key[0],
                "category": key[1],
                "conflicting_values": list(unique_values),
                "occurrences": occurrences,
                "issue": f"⚠️ {key[0]} {key[1]} 出现 {len(unique_values)} 个不同值",
            })

    return inconsistencies


# ============================================================
# V2.1 验证计划生成器（核心）
# 不调用外部接口 — 数据源调用由 Agent 通过 Bash 工具自主执行
# ============================================================

def generate_verification_plan(data_points: List[Dict], company_hint: str = "") -> List[Dict]:
    """V2.1：生成验证计划（不调用任何外部接口）。

    关键原则：数据源是 Agent 的工具，不是流水线的固定输入。
    此函数输出每个数据点的推荐数据源 + 推荐查询命令，
    Agent 拿到计划后通过 Bash 工具自主选择执行。

    返回：plan_items [{data_point, category, data_type, company,
                       recommended_source, recommended_query, priority}]
    """
    plan_items = []

    for dp in data_points[:30]:
        category = dp.get("category", "")
        value = dp.get("value", "")
        ctx = dp.get("context", "")
        data_type = dp.get("data_type", "financial")

        company_match = re.search(
            r"(三安光电|华灿光电|兆驰股份|蔚蓝锂芯|鸿利智汇|乾照光电|晶能光电)", ctx)
        company = company_match.group(1) if company_match else company_hint

        year_match = re.search(r"(20\d{2})\s*年?", ctx)
        year = year_match.group(1) if year_match else "2024"

        # 非上市公司 → MX Data 优先
        if company == "晶能光电":
            recommended_source = "MX Data D1 + MX Search"
            recommended_query = f"{company} {year}年 {category} {value}"
        elif data_type == "financial":
            recommended_source = "iFind Finance（优先）/ MX Data D1（备选）"
            recommended_query = f"{company} {year}年报告期 {category} {value}"
        elif category in ("成立时间", "上市时间", "实控人", "股东"):
            recommended_source = "MX Data D6 + iFind Announcement"
            recommended_query = f"{company} {category}"
        elif category in ("技术路线",):
            recommended_source = "MX Search + iFind News"
            recommended_query = f"{company} {category} {year}"
        else:
            recommended_source = "MX Search（通用）/ iFind News"
            recommended_query = f"{company} {category}"

        plan_items.append({
            "data_point": value or ctx[:80],
            "category": category,
            "data_type": data_type,
            "company": company or company_hint,
            "year": year,
            "recommended_source": recommended_source,
            "recommended_query": recommended_query,
            "priority": "high" if data_type == "financial" else "medium",
            "label": "[待Agent验证]",
            "note": f"Agent 请用 Bash 调用: {recommended_source}",
        })

    return plan_items


def detect_hallucinations(data_points: List[Dict], citations: List[Dict],
                          logic_chains: List[Dict]) -> Dict:
    """V2.0: 幻觉清单 - 凭空数字 / 幽灵来源 / 跳跃推理"""
    hallucinations = {
        "unsourced_numbers": [],   # 无来源数字
        "phantom_sources": [],     # 幽灵来源
        "jump_reasoning": [],      # 跳跃推理
    }

    # 1. 无来源数字：数据点出现但无任何引用
    cited_text = " ".join(c.get("source", "") for c in citations)
    for dp in data_points:
        value = dp.get("value", "")
        if value and value not in cited_text:
            hallucinations["unsourced_numbers"].append({
                "value": value,
                "category": dp["category"],
                "context": dp.get("context", "")[:100],
                "label": "[幻觉]",
            })

    # 2. 幽灵来源：报告内未实际使用的来源
    draft_lower_check = set()
    for c in citations:
        s = c.get("source", "")
        if s:
            draft_lower_check.add(s[:20])  # 取前 20 字符做粗匹配

    # 3. 跳跃推理
    for chain in logic_chains:
        if chain["is_jump"]:
            hallucinations["jump_reasoning"].append({
                "indicator": chain["indicator"],
                "premise": chain["premise"][:100],
                "conclusion": chain["conclusion"][:100],
                "label": "[跳跃]",
            })

    return hallucinations


# ============================================================
# V2.0 渲染（防幻觉报告附录）
# ============================================================

def render_challenge_b_v2_markdown(verification_result: Dict, target: str) -> str:
    """V2.0: 渲染防幻觉核查报告（替代综合分输出）"""

    financial_points = verification_result["financial_points"]
    factual_points = verification_result["factual_points"]
    citations = verification_result["citations"]
    logic_chains = verification_result["logic_chains"]
    inconsistencies = verification_result["inconsistencies"]
    multi_source = verification_result["multi_source"]
    hallucinations = verification_result["hallucinations"]

    # 统计
    total_data_points = len(financial_points) + len(factual_points)
    total_hallucinations = (
        len(hallucinations["unsourced_numbers"])
        + len(hallucinations["phantom_sources"])
        + len(hallucinations["jump_reasoning"])
    )
    total_inconsistencies = len(inconsistencies)
    total_citations = len(citations)

    md = f"""## 九·质疑节点 B V2.0 · 防幻觉核查 [V3 工作流嫁接]

> **本章节通过 V3 工作流能力对完整报告做防幻觉核查**（主公 2026-07-04 10:34 指示）
> - 核查目的：**防幻觉**，不是给报告打综合分
> - 数据点总数：{total_data_points}（金融 {len(financial_points)} + 事实 {len(factual_points)}）
> - 来源标注总数：{total_citations}
> - 幻觉总数：**{total_hallucinations}**（任何幻觉必须标红，不删除）
> - 一致性问题：{total_inconsistencies}
> - 嫁接位置：纵横分析法 cross_insight 阶段之后

### 9.1 事实核查表（主表 · 防幻觉）

**金融数据核查（iFind MX 主源 + Tushare/AKShare/Equal-Data/iFind 备源）**

| 数据点 | 类别 | 来源标注 | 多源验证 | 标注 |
|--------|------|---------|---------|------|
"""
    for fp in financial_points[:15]:  # 限 15 行
        ms = next((m for m in multi_source if m.get("data_point") == fp.get("value")), {})
        label = ms.get("label", "[待核实]")
        md += f"| {fp.get('value', 'N/A')} | {fp['category']} | （需标 [源:xx]） | {ms.get('method', 'N/A')} | {label} |\n"

    md += f"""
**事实性数据核查（SearXNG 主源 + 企查查/天眼查 备源）**

| 数据点 | 类别 | 来源标注 | 多源验证 | 标注 |
|--------|------|---------|---------|------|
"""
    for fp in factual_points[:15]:
        ms = next((m for m in multi_source if fp.get("context", "")[:80] in m.get("data_point", "")), {})
        label = ms.get("label", "[待核实]")
        ctx_short = fp.get("context", "")[:60]
        md += f"| {ctx_short}... | {fp['category']} | （需标 [源:xx]） | {ms.get('method', 'N/A')} | {label} |\n"

    md += f"""
### 9.2 来源真实性清单

| 来源标记 | 物理存在 | 被引用次数 | 权威性 |
|---------|---------|-----------|--------|
"""
    # 按 source 去重，统计被引用次数
    source_counter = {}
    for c in citations:
        s = c.get("source", "")
        if s:
            source_counter[s] = source_counter.get(s, 0) + 1
    for s, count in source_counter.items():
        # 标记权威性
        authority = "A"
        if "财务尽调" in s or "iFind" in s or "iFind" in s or "Tushare" in s:
            authority = "A"
        elif "CC" in s or "沟通会" in s:
            authority = "B"
        else:
            authority = "C"
        md += f"| {s[:40]} | ⚠️ 待查 | {count} | {authority} |\n"

    md += f"""
### 9.3 推理链验证

| 推理 | 前提 | 结论 | 中间步骤数 | 跳跃? |
|------|------|------|----------|------|
"""
    for chain in logic_chains[:10]:
        jump_label = "❌ [跳跃]" if chain["is_jump"] else "✅ 合理"
        mid_count = len(chain["middle_steps"])
        md += f"| {chain['indicator']} | {chain['premise'][:50]} | {chain['conclusion'][:50]} | {mid_count} | {jump_label} |\n"

    md += f"""
### 9.4 一致性检查

| 公司 / 指标 | 冲突值 | 位置数 | 状态 |
|------------|-------|-------|------|
"""
    if inconsistencies:
        for inc in inconsistencies:
            vals = ", ".join(inc["conflicting_values"])
            md += f"| {inc['company']} {inc['category']} | {vals} | {len(inc['occurrences'])} | ⚠️ 需核实 |\n"
    else:
        md += "| ✅ 全报告数据一致，未发现冲突 | — | — | — |\n"

    md += f"""
### 9.5 幻觉清单

**无来源数字（{len(hallucinations['unsourced_numbers'])} 项）**
"""
    if hallucinations["unsourced_numbers"]:
        for h in hallucinations["unsourced_numbers"][:10]:
            md += f"- `{h['value']}` ({h['category']}) → {h['label']} {h['context'][:80]}\n"
    else:
        md += "- ✅ 所有数字均有来源标注\n"

    md += f"""
**跳跃推理（{len(hallucinations['jump_reasoning'])} 项）**
"""
    if hallucinations["jump_reasoning"]:
        for h in hallucinations["jump_reasoning"][:10]:
            md += f"- {h['indicator']}: {h['premise'][:60]} → {h['conclusion'][:60]} → {h['label']}\n"
    else:
        md += "- ✅ 所有推理均有中间步骤\n"

    md += f"""
**幽灵来源（{len(hallucinations['phantom_sources'])} 项）**
"""
    if hallucinations["phantom_sources"]:
        for h in hallucinations["phantom_sources"][:10]:
            md += f"- {h}\n"
    else:
        md += "- ✅ 所有来源标注均被引用\n"

    md += f"""
### 9.6 多源比对（主公 2026-07-04 10:40 新增指示）

**比对架构**：

| 数据类型 | 主源 | 备源 | 一致性原则 |
|---------|------|------|----------|
| 金融数据 | iFind MX | Tushare / AKShare / Equal-Data / iFind | ≥2 源一致 → [已证] |
| 事实性数据 | SearXNG | 企查查 / 天眼查 / 启信宝 | ≥2 源一致 → [已证] |

**比对状态**：

| 数据点 | 类型 | 主源状态 | 备源状态 | 多源一致性 | 标注 |
|--------|------|---------|---------|----------|------|
"""
    for ms in multi_source[:10]:
        primary = "⚠️ 待核"
        secondary = "⚠️ 待核"
        if ms.get("verified") is True:
            consistency = "✅ 多源一致"
            label = "[已证]"
        elif ms.get("verified") is False:
            consistency = "❌ 多源冲突"
            label = "[冲突]"
        else:
            consistency = "⚠️ 待核实"
            label = "[待核实]"
        md += f"| {str(ms.get('data_point', ''))[:40]} | {ms['data_type']} | {primary} | {secondary} | {consistency} | {label} |\n"

    md += f"""
### 9.7 防幻觉结论

| 维度 | 计数 | 处理 |
|------|------|------|
| 数据点总数 | {total_data_points} | — |
| 无来源数字 | {len(hallucinations['unsourced_numbers'])} | 报告标 [幻觉] |
| 跳跃推理 | {len(hallucinations['jump_reasoning'])} | 报告标 [跳跃] |
| 幽灵来源 | {len(hallucinations['phantom_sources'])} | 报告标 [未核实] |
| 一致性冲突 | {total_inconsistencies} | 需补充说明 |

**门槛定义**：
- 旧：综合分 ≥ 60 / 70（已取消）
- 新：**幻觉数 = 0**（任何幻觉必须标红，不删除）

**操作说明**：
- 报告中所有 `[幻觉]` 数字：主公看到后必须核实或删除
- 报告中所有 `[跳跃]` 推理：需补充中间步骤
- 报告中所有 `[未核实]` 来源：需主公授权后用主源 + 备源核对

---

**【V2.0 架构说明】**
- V2.0 取消综合分输出，仅做防幻觉核查
- 多源比对通过 iFind MX + 备源链 / SearXNG + 企查查天眼查 实现
- 实接口接入后会替换占位（iFind MX 真实查询 / SearXNG 实际搜索）
- 报告标注规则：`[已证]` ≥2 源一致 / `[待核实]` 单源 / `[幻觉]` 无源 / `[跳跃]` 0 跳 / `[未核实]` 来源不可访问

"""

    return md


# ============================================================
# 主入口
# ============================================================

def run_challenge_b(target: str, full_draft: str,
                    model: str = "minimax-portal/MiniMax-M3") -> Dict:
    """V2.0 入口：cross_insight 阶段后运行防幻觉核查"""
    print(f"[HV-Challenge-B-V2] ▶ 防幻觉核查开始（target={target}）", file=sys.stderr)

    # 1. 抽取所有数据点
    financial_points, factual_points = extract_all_data_points(full_draft)
    print(f"[HV-Challenge-B-V2]   → 金融数据点 {len(financial_points)} / 事实数据点 {len(factual_points)}", file=sys.stderr)

    # 2. 抽取来源标注
    citations = extract_citations(full_draft)
    print(f"[HV-Challenge-B-V2]   → 来源标注 {len(citations)}", file=sys.stderr)

    # 3. 抽取逻辑链
    logic_chains = extract_logic_chains(full_draft)
    print(f"[HV-Challenge-B-V2]   → 逻辑链 {len(logic_chains)}", file=sys.stderr)

    # 4. 一致性检查
    inconsistencies = check_internal_consistency(full_draft)
    print(f"[HV-Challenge-B-V2]   → 一致性冲突 {len(inconsistencies)}", file=sys.stderr)

    # 5. 生成验证计划（V2.1：Agent 自适应闭环，不硬编码数据源调用）
    all_data_points = financial_points + factual_points
    verification_plan = generate_verification_plan(all_data_points, company_hint=target)
    print(f"[HV-Challenge-B-V2]   → 验证计划 {len(verification_plan)} 项（待Agent执行）", file=sys.stderr)

    # 6. 幻觉检测
    hallucinations = detect_hallucinations(all_data_points, citations, logic_chains)
    total_h = (
        len(hallucinations["unsourced_numbers"])
        + len(hallucinations["phantom_sources"])
        + len(hallucinations["jump_reasoning"])
    )
    print(f"[HV-Challenge-B-V2]   → 幻觉 {total_h}（无源 {len(hallucinations['unsourced_numbers'])} + 幽灵 {len(hallucinations['phantom_sources'])} + 跳跃 {len(hallucinations['jump_reasoning'])}）", file=sys.stderr)

    # 7. 渲染
    verification_result = {
        "financial_points": financial_points,
        "factual_points": factual_points,
        "citations": citations,
        "logic_chains": logic_chains,
        "inconsistencies": inconsistencies,
        "verification_plan": verification_plan,
        "multi_source": verification_plan,  # 向后兼容别名
        "hallucinations": hallucinations,
    }
    markdown = render_challenge_b_v2_markdown(verification_result, target)

    total_data_points = len(financial_points) + len(factual_points)
    result = {
        "verification_result": verification_result,
        "hallucination_count": total_h,
        "inconsistency_count": len(inconsistencies),
        "data_point_count": total_data_points,
        "markdown": markdown,
        "version": "V2.0",
    }

    print(f"[HV-Challenge-B-V2] ✅ 防幻觉核查完成：{total_h} 幻觉 / {len(inconsistencies)} 冲突", file=sys.stderr)

    return result


# ============================================================
# 自检
# ============================================================

if __name__ == "__main__":
    print("[HV-Challenge-B-V2] V2.0 模块自检...")
    SAMPLE = """## 一、公司基本情况
公司是 LED 芯片厂商，2024营收12.3亿，净利润2.8亿，净利率22.76%。
基于硅衬底 GaN 技术路线，[源:01_财务尽调.pdf]，[可信度:A]。
因此净利润大幅领先同行，是国内硅衬底 LED 唯一规模化厂商。

## 二、横向对标
根据三安光电可比数据 [源:iFind 2024]，三安 2024营收165.4亿，净利率3.2%，ROE 2.8%，PE 68x。
华灿光电 32.1亿，净利率 -8.5%，ROE -12.3%，PE N/A。

## 三、估值
基于行业增长趋势，预计公司估值25-40亿元，根据CC沟通会信息。

## 四、风险
公司核心风险包括：客户集中度高、政府补助占比41%（数据无来源）。
"""

    result = run_challenge_b("晶能光电", SAMPLE)
    print(f"  数据点 {result['data_point_count']}")
    print(f"  幻觉 {result['hallucination_count']}")
    print(f"  冲突 {result['inconsistency_count']}")
    print("✅ V2.0 自检通过")