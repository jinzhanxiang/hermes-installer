#!/usr/bin/env python3
"""
embed_charts_into_md.py — 把 manifest.json 里的 base64 SVG 嵌入 MD 报告占位符
"""
import json
import re
import sys
from pathlib import Path

MD_PATH = "/Users/jinzhanxiang/Documents/OpenClaw-Workspace-research/projects/汇天网络科技/output/汇天IDC_天保能源持股34%控制并表方案_20260709.md"
MANIFEST_PATH = "/Users/jinzhanxiang/Documents/OpenClaw-Workspace-research/projects/汇天网络科技/charts/manifest.json"

with open(MANIFEST_PATH) as f:
    manifest = json.load(f)

md = Path(MD_PATH).read_text(encoding='utf-8')

# 把所有 base64 重新读一遍以确保一致
for chart in manifest["charts"]:
    name = chart["name"]
    light = chart["light_b64"]
    dark = chart["dark_b64"]
    md = md.replace("{{CHART1_LIGHT}}", light, 1) if name == "chart1_huitian_finance" else md
    md = md.replace("{{CHART1_DARK}}", dark, 1) if name == "chart1_huitian_finance" else md
    md = md.replace("{{CHART2_LIGHT}}", light, 1) if name == "chart2_valuation_compare" else md
    md = md.replace("{{CHART2_DARK}}", dark, 1) if name == "chart2_valuation_compare" else md
    md = md.replace("{{CHART3_LIGHT}}", light, 1) if name == "chart3_radar_compare" else md
    md = md.replace("{{CHART3_DARK}}", dark, 1) if name == "chart3_radar_compare" else md
    md = md.replace("{{CHART4_LIGHT}}", light, 1) if name == "chart4_property_pie" else md
    md = md.replace("{{CHART4_DARK}}", dark, 1) if name == "chart4_property_pie" else md
    md = md.replace("{{CHART5_LIGHT}}", light, 1) if name == "chart5_irr_scenarios" else md
    md = md.replace("{{CHART5_DARK}}", dark, 1) if name == "chart5_irr_scenarios" else md
    md = md.replace("{{CHART6_LIGHT}}", light, 1) if name == "chart6_power_rate" else md
    md = md.replace("{{CHART6_DARK}}", dark, 1) if name == "chart6_power_rate" else md
    md = md.replace("{{CHART7_LIGHT}}", light, 1) if name == "chart7_kpi_dashboard" else md
    md = md.replace("{{CHART7_DARK}}", dark, 1) if name == "chart7_kpi_dashboard" else md
    md = md.replace("{{CHART8_LIGHT}}", light, 1) if name == "chart8_business_stack" else md
    md = md.replace("{{CHART8_DARK}}", dark, 1) if name == "chart8_business_stack" else md

# 检查是否还有未替换的占位符
remaining = re.findall(r'\{\{CHART\d+_(?:LIGHT|DARK)\}\}', md)
if remaining:
    print(f"⚠️  还有 {len(remaining)} 个未替换占位符: {set(remaining)}")
else:
    print("✅ 所有 16 个占位符（8 浅+8 暗）已全部替换")

Path(MD_PATH).write_text(md, encoding='utf-8')
print(f"📝 MD 报告已更新：{MD_PATH}")
print(f"📊 文件大小：{len(md.encode('utf-8'))/1024:.1f} KB")
