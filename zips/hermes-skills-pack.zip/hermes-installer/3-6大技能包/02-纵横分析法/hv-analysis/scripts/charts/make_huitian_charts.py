#!/usr/bin/env python3
"""
make_huitian_charts.py — 汇天 IDC 报告专属图表生成器（V3.46.0 升级版）
基于 hv_charts.py + 实测数据，生成 8 张图（浅+暗 = 16 个 SVG）+ manifest.json

数据基准日：2026-07-09
数据来源：港交所公告（天保能源）/ iFind 同业 / Tavily 补充
"""
import os
import sys
import json
import base64
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
from hv_charts import (
    chart_financial_timeline,
    chart_horizontal_bar,
    chart_radar_compare,
    chart_pie_structure,
    chart_scenario_irr,
    chart_line_trend,
    chart_kpi_dashboard,
    chart_stacked_bar,
    _save_svg_base64,
)

OUT_DIR = '/Users/jinzhanxiang/Documents/OpenClaw-Workspace-research/projects/汇天网络科技/charts'
os.makedirs(OUT_DIR, exist_ok=True)


def save_dual(fig_func, name: str, out_dir: str = OUT_DIR):
    """生成浅+暗两版 SVG 文件 + 返回 base64"""
    fig_light = fig_func(dark_mode=False)
    fig_dark = fig_func(dark_mode=True)
    light_b64 = _save_svg_base64(fig_light, dark_mode=False)
    dark_b64 = _save_svg_base64(fig_dark, dark_mode=True)
    Path(out_dir, f"{name}_light.svg").write_bytes(base64.b64decode(light_b64))
    Path(out_dir, f"{name}_dark.svg").write_bytes(base64.b64decode(dark_b64))
    return light_b64, dark_b64


# ============================================================
# 图 1：汇天网络 2021-2025 财务时序
# ============================================================
years1 = [2021, 2022, 2023, 2024, 2025]
huitian_revenue = [0, 0, 0.2942, 0.1672, 0.7843]
huitian_netprofit = [0, 0, -0.0156, 0.0102, 0.0467]

def _fig1(dark_mode):
    return chart_financial_timeline(
        years=years1,
        revenue=huitian_revenue,
        net_profit=huitian_netprofit,
        title="图 1：汇天网络 2021-2025 营收/归母净利时序（亿元）",
        revenue_label="汇天网络营业收入（亿元）",
        net_profit_label="汇天网络归母净利润（亿元）",
        dark_mode=dark_mode,
    )

l1, d1 = save_dual(_fig1, "chart1_huitian_finance")
print("✅ chart1 OK")

# ============================================================
# 图 2：IDC 同业 PB 估值对标
# ============================================================
labels2 = ["数据港(603881)", "光环新网(300383)", "汇天IDC(标的)", "润泽科技(300442)", "宝信软件(600845)"]
pb2 = [8.85, 1.79, 3.50, 4.13, 7.20]

def _fig2(dark_mode):
    return chart_horizontal_bar(
        labels=labels2,
        values=pb2,
        title="图 2：IDC 同业 2025 市净率（PB）估值倍数对标",
        xlabel="P/B（倍）",
        value_format="{:.2f}x",
        highlight_index=2,
        dark_mode=dark_mode,
    )

l2, d2 = save_dual(_fig2, "chart2_valuation_compare")
print("✅ chart2 OK")

# ============================================================
# 图 3：5 家 IDC 同业 6 维度雷达
# ============================================================
dimensions = ['机柜规模', '客户质量', '运营效率', '财务健康', '区位优势', '技术壁垒']
runze = [9.0, 9.0, 8.0, 9.0, 9.0, 9.5]
guanghuan = [6.0, 7.5, 5.0, 3.0, 8.0, 6.0]
shujugang = [5.5, 7.0, 5.5, 4.5, 7.0, 6.5]
baoxin = [7.0, 8.0, 7.0, 7.5, 7.0, 8.0]
huitian = [5.0, 6.0, 4.5, 4.0, 7.5, 5.0]

def _fig3(dark_mode):
    return chart_radar_compare(
        categories=dimensions,
        series={
            "润泽科技(龙头)": runze,
            "光环新网": guanghuan,
            "数据港": shujugang,
            "宝信软件": baoxin,
            "汇天IDC(标的)": huitian,
        },
        title="图 3：5 家 IDC 同业 6 维度能力雷达对标",
        dark_mode=dark_mode,
    )

l3, d3 = save_dual(_fig3, "chart3_radar_compare")
print("✅ chart3 OK")

# ============================================================
# 图 4：东八栋物业估值结构
# ============================================================
properties4 = ["3号楼", "4号楼", "7号楼", "11号楼", "12号楼", "13号楼", "14号楼", "17号楼"]
values4 = [12.0, 13.5, 12.5, 14.0, 12.0, 11.5, 12.0, 12.5]

def _fig4(dark_mode):
    return chart_pie_structure(
        labels=properties4,
        sizes=values4,
        title="图 4：汇天 IDC 东八栋物业估值结构（亿元）",
        dark_mode=dark_mode,
    )

l4, d4 = save_dual(_fig4, "chart4_property_pie")
print("✅ chart4 OK")

# ============================================================
# 图 5：IRR 三情景
# ============================================================
scenarios5 = ["保守 (80%询价)", "中性 (100%询价)", "乐观 (120%询价)"]
irr5 = [11.8, 16.5, 22.3]

def _fig5(dark_mode):
    return chart_scenario_irr(
        scenarios=scenarios5,
        irr_values=irr5,
        title="图 5：汇天 IDC 出资方案 IRR 三情景测算（%）",
        dark_mode=dark_mode,
    )

l5, d5 = save_dual(_fig5, "chart5_irr_scenarios")
print("✅ chart5 OK")

# ============================================================
# 图 6：上电率趋势
# ============================================================
years6 = [2023, 2024, 2025, 2026]
huitian_power = [95, 88, 80, 75]
peers_power = [78, 76, 74, 72]

def _fig6(dark_mode):
    return chart_line_trend(
        x_data=years6,
        y_series={
            "汇天 IDC 上电率（%）": huitian_power,
            "同业均值上电率（%）": peers_power,
        },
        title="图 6：汇天 IDC 上电率 vs 同业均值（2023-2026E）",
        ylabel="上电率（%）",
        dark_mode=dark_mode,
    )

l6, d6 = save_dual(_fig6, "chart6_power_rate")
print("✅ chart6 OK")

# ============================================================
# 图 7：KPI 仪表盘
# ============================================================
def _fig7(dark_mode):
    return chart_kpi_dashboard(
        kpi_data=[
            {"label": "标的估值", "value": "42.02", "unit": "亿元", "color": "primary"},
            {"label": "天保出资", "value": "4.43", "unit": "亿元", "color": "accent"},
            {"label": "中性 IRR", "value": "16.5", "unit": "%", "color": "success"},
            {"label": "VDA 比率", "value": "137.5", "unit": "%", "color": "danger"},
        ],
        title="图 7：汇天 IDC 出资方案 KPI 核心指标（情景 A 100% 询价）",
        dark_mode=dark_mode,
    )

l7, d7 = save_dual(_fig7, "chart7_kpi_dashboard")
print("✅ chart7 OK")

# ============================================================
# 图 8：业务收入结构堆叠
# ============================================================
companies8 = ["润泽科技", "光环新网", "数据港", "宝信软件", "汇天网络"]
a8 = [25.1, 51.0, 0.4, 71.6, 68.6]
b8 = [31.6, 20.9, 16.8, 37.7, 9.9]
c8 = [0, 0.6, 0, 0.5, 0]

def _fig8(dark_mode):
    return chart_stacked_bar(
        x_data=companies8,
        y_series={
            "AIDC/智算/软件开发（亿元）": a8,
            "IDC 主营/批发（亿元）": b8,
            "系统集成/其他（亿元）": c8,
        },
        title="图 8：5 家 IDC 同业 2025 业务收入结构堆叠（亿元）",
        ylabel="金额（亿元）",
        dark_mode=dark_mode,
    )

l8, d8 = save_dual(_fig8, "chart8_business_stack")
print("✅ chart8 OK")

# ============================================================
# 生成 manifest.json（嵌 MD 用的 base64 数据）
# ============================================================
manifest = {
    "version": "V3.46.0",
    "report": "汇天IDC_天保能源持股34%控制并表方案",
    "date": "2026-07-09",
    "data_baseline": "2026-07-09 实测数据（港交所公告 / iFind / Tavily 补充）",
    "charts": []
}

chart_titles = {
    "chart1_huitian_finance": "图 1：汇天网络 2021-2025 营收/归母净利时序",
    "chart2_valuation_compare": "图 2：IDC 同业 2025 市净率（PB）估值倍数对标",
    "chart3_radar_compare": "图 3：5 家 IDC 同业 6 维度能力雷达对标",
    "chart4_property_pie": "图 4：汇天 IDC 东八栋物业估值结构",
    "chart5_irr_scenarios": "图 5：汇天 IDC 出资方案 IRR 三情景测算",
    "chart6_power_rate": "图 6：汇天 IDC 上电率 vs 同业均值",
    "chart7_kpi_dashboard": "图 7：汇天 IDC 出资方案 KPI 核心指标",
    "chart8_business_stack": "图 8：5 家 IDC 同业 2025 业务收入结构",
}

for name, l_b64, d_b64 in [
    ("chart1_huitian_finance", l1, d1),
    ("chart2_valuation_compare", l2, d2),
    ("chart3_radar_compare", l3, d3),
    ("chart4_property_pie", l4, d4),
    ("chart5_irr_scenarios", l5, d5),
    ("chart6_power_rate", l6, d6),
    ("chart7_kpi_dashboard", l7, d7),
    ("chart8_business_stack", l8, d8),
]:
    light_path = Path(OUT_DIR) / f"{name}_light.svg"
    dark_path = Path(OUT_DIR) / f"{name}_dark.svg"
    manifest["charts"].append({
        "name": name,
        "title": chart_titles[name],
        "light_b64": l_b64,
        "dark_b64": d_b64,
        "light_size": light_path.stat().st_size if light_path.exists() else 0,
        "dark_size": dark_path.stat().st_size if dark_path.exists() else 0,
    })

with open(f"{OUT_DIR}/manifest.json", "w") as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)

total = sum(c['light_size'] + c['dark_size'] for c in manifest['charts'])
print(f"\n📁 输出目录：{OUT_DIR}")
print(f"📋 manifest.json：8 张图（浅+暗 = 16 个 SVG）")
print(f"📊 总数据量：{total/1024:.1f} KB")
