#!/usr/bin/env python3
"""
hv_charts.py — HV Analysis 通用图表生成器（V3.46.0）

设计哲学：
  1. 数据驱动：调用方传入 dict 配置（标题、数据、维度），脚本生成 SVG
  2. 中文字体：macOS STHeiti Medium.ttc（与 report-html-publish 一致）
  3. 大字号：标题 22 / 轴标 16 / 刻度 14 / 数值 13（V3.42.9+ 标准）
  4. 双版本：浅色 + 暗色，输出 base64 嵌入 HTML（CSS media query 切换）
  5. 可复用：图表类型为函数模板，传入任意数据集即可生成

调用示例：
  from hv_charts import chart_financial_timeline, chart_radar_compare, save_chart_pair
  fig1 = chart_financial_timeline(years=[2020,2021,2022,2023,2024,2025],
                                   revenue=[2937,5931,7843,...],
                                   net_profit=[...],
                                   title="汇天网络财务时序")
  save_chart_pair(fig1, 'chart_huitian_finance', out_dir='./charts')

图表类型（V3.46.0 首批 8 种）：
  1. chart_financial_timeline       - 营收/净利 时序双柱
  2. chart_horizontal_bar           - 横向柱状（对标排名）
  3. chart_radar_compare            - 雷达图（多维度对标）
  4. chart_pie_structure            - 饼图（结构占比）
  5. chart_scenario_irr             - 场景柱状（IRR 三情景）
  6. chart_line_trend               - 折线（多年趋势）
  7. chart_industry_chain_flow      - 产业链 SVG 流程图（CSS grid 风格）
  8. chart_kpi_dashboard            - KPI 数字仪表盘
"""

import os
import sys
import base64
from pathlib import Path
from io import BytesIO

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np

# ── 中文字体 ──────────────────────────────────────────────
CHINESE_FONT_PATH = '/System/Library/Fonts/STHeiti Medium.ttc'
if not Path(CHINESE_FONT_PATH).exists():
    CHINESE_FONT_PATH = '/System/Library/Fonts/STHeiti Light.ttc'
fm.fontManager.addfont(CHINESE_FONT_PATH)
chinese_font = fm.FontProperties(fname=CHINESE_FONT_PATH)

# ── 全局字号配置（V3.42.9+ 标准） ──────────────────────
FONT_SIZE = {
    'title': 22,
    'subtitle': 16,
    'axis_label': 14,
    'tick': 12,
    'legend': 12,
    'bar_value': 12,
    'annotation': 11,
}

# ── 配色（V3.42.9c 极简商务尽调） ───────────────────────
COLORS_LIGHT = {
    'primary': '#1a365d',     # 深蓝
    'secondary': '#2c5282',   # 中蓝
    'accent': '#d69e2e',      # 琥珀金
    'accent_light': '#fbd38d', # 浅琥珀
    'success': '#2f855a',     # 绿
    'danger': '#c53030',      # 红
    'warning': '#dd6b20',     # 橙
    'info': '#3182ce',        # 蓝
    'neutral': '#718096',     # 灰
    'bg': '#ffffff',
    'text': '#1a202c',
    'grid': '#cbd5e0',
}

COLORS_DARK = {
    'primary': '#63b3ed',
    'secondary': '#4299e1',
    'accent': '#fbd38d',
    'accent_light': '#fef3c7',
    'success': '#68d391',
    'danger': '#fc8181',
    'warning': '#f6ad55',
    'info': '#63b3ed',
    'neutral': '#a0aec0',
    'bg': '#1a202c',
    'text': '#e2e8f0',
    'grid': '#4a5568',
}


def _setup_matplotlib(dark_mode=False):
    """配置 matplotlib 全局参数"""
    plt.rcParams['font.family'] = chinese_font.get_name()
    plt.rcParams['font.size'] = FONT_SIZE['axis_label']
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['figure.dpi'] = 100
    plt.rcParams['savefig.dpi'] = 120
    plt.rcParams['savefig.format'] = 'svg'


def _save_svg_base64(fig, dark_mode=False):
    """保存 fig 为 base64 SVG"""
    buf = BytesIO()
    bg = COLORS_DARK['bg'] if dark_mode else COLORS_LIGHT['bg']
    fig.savefig(buf, format='svg', bbox_inches='tight', facecolor=bg)
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode('ascii')


# ============================================================
# 图 1：财务时序（营收 + 净利 双柱，2019-2025）
# ============================================================
def chart_financial_timeline(
    years: list,
    revenue: list,
    net_profit: list,
    title: str = "财务时序",
    revenue_label: str = "营业收入（亿元）",
    net_profit_label: str = "归母净利润（亿元）",
    dark_mode: bool = False,
):
    """
    财务时序：营收 + 归母净利 双柱图。
    Args:
        years: 年份列表
        revenue: 营收列表（与 years 等长）
        net_profit: 净利列表（与 years 等长）
        title: 图标题
    """
    _setup_matplotlib(dark_mode)
    c = COLORS_DARK if dark_mode else COLORS_LIGHT
    bg = c['bg']
    text = c['text']
    grid = c['grid']

    fig, ax = plt.subplots(figsize=(12, 5.5))
    x = range(len(years))
    width = 0.36

    bars1 = ax.bar([i - width/2 for i in x], revenue, width,
                   label=revenue_label, color=c['primary'], alpha=0.92)
    bars2 = ax.bar([i + width/2 for i in x], net_profit, width,
                   label=net_profit_label, color=c['accent'], alpha=0.92)

    # 数值标签
    for bar in bars1:
        h = bar.get_height()
        va = 'bottom' if h >= 0 else 'top'
        offset = 0.03 * max(abs(max(revenue or [1])), abs(min(revenue or [0]))) or 0.3
        ax.text(bar.get_x() + bar.get_width()/2, h + (offset if h >= 0 else -offset),
                f'{h:.1f}', ha='center', va=va,
                fontsize=FONT_SIZE['bar_value'], color=text, fontweight='bold')
    for bar in bars2:
        h = bar.get_height()
        va = 'bottom' if h >= 0 else 'top'
        offset = 0.03 * max(abs(max(net_profit or [1])), abs(min(net_profit or [0]))) or 0.3
        ax.text(bar.get_x() + bar.get_width()/2, h + (offset if h >= 0 else -offset),
                f'{h:.1f}', ha='center', va=va,
                fontsize=FONT_SIZE['bar_value'], color=text, fontweight='bold')

    ax.axhline(y=0, color=grid, linewidth=1.2, linestyle='--')
    ax.set_title(title, fontsize=FONT_SIZE['title'], color=text, fontweight='bold', pad=18)
    ax.set_xticks(list(x))
    ax.set_xticklabels(years, fontsize=FONT_SIZE['tick'], color=text)
    ax.set_ylabel('金额', fontsize=FONT_SIZE['axis_label'], color=text)
    ax.tick_params(axis='y', labelsize=FONT_SIZE['tick'], colors=text)
    ax.legend(fontsize=FONT_SIZE['legend'], loc='upper left')
    ax.grid(axis='y', alpha=0.3, color=grid)
    ax.set_facecolor(bg)
    fig.patch.set_facecolor(bg)
    for spine in ['top', 'right']:
        ax.spines[spine].set_visible(False)
    ax.spines['left'].set_color(grid)
    ax.spines['bottom'].set_color(grid)
    return fig


# ============================================================
# 图 2：横向柱状（对标排名）
# ============================================================
def chart_horizontal_bar(
    labels: list,
    values: list,
    title: str = "对标排名",
    xlabel: str = "数值",
    value_format: str = "{:.1f}",
    highlight_index: int = None,  # 高亮某个 bar（标金色）
    dark_mode: bool = False,
):
    """
    横向柱状图：用于对标排名。
    Args:
        labels: 标签列表
        values: 数值列表
        title: 标题
        xlabel: x 轴标签
        value_format: 数值格式化字符串
        highlight_index: 高亮第几个 bar（用于突出本公司）
    """
    _setup_matplotlib(dark_mode)
    c = COLORS_DARK if dark_mode else COLORS_LIGHT
    bg = c['bg']
    text = c['text']
    grid = c['grid']

    # 按值降序
    sorted_data = sorted(zip(labels, values), key=lambda x: x[1], reverse=False)
    sorted_labels, sorted_values = zip(*sorted_data)
    sorted_labels = list(sorted_labels)
    sorted_values = list(sorted_values)

    fig, ax = plt.subplots(figsize=(11, max(4, 0.7 * len(labels) + 2)))
    colors_list = []
    for i in range(len(sorted_labels)):
        orig_idx = labels.index(sorted_labels[i])
        if highlight_index is not None and orig_idx == highlight_index:
            colors_list.append(c['accent'])
        else:
            colors_list.append(c['primary'])

    bars = ax.barh(sorted_labels, sorted_values, color=colors_list, alpha=0.92)
    vmax = max(sorted_values) if sorted_values else 1
    for bar, val in zip(bars, sorted_values):
        ax.text(val + vmax * 0.01, bar.get_y() + bar.get_height()/2,
                value_format.format(val), va='center', ha='left',
                fontsize=FONT_SIZE['bar_value'], color=text, fontweight='bold')

    ax.set_xlabel(xlabel, fontsize=FONT_SIZE['axis_label'], color=text)
    ax.set_title(title, fontsize=FONT_SIZE['title'], color=text, fontweight='bold', pad=18)
    ax.tick_params(axis='both', labelsize=FONT_SIZE['tick'], colors=text)
    ax.set_facecolor(bg)
    fig.patch.set_facecolor(bg)
    for spine in ['top', 'right']:
        ax.spines[spine].set_visible(False)
    ax.spines['left'].set_color(grid)
    ax.spines['bottom'].set_color(grid)
    ax.set_xlim(0, vmax * 1.15)
    return fig


# ============================================================
# 图 3：雷达图（多维度对标）
# ============================================================
def chart_radar_compare(
    categories: list,
    series: dict,  # {'公司A': [v1,v2,...], '公司B': [v1,v2,...]}
    title: str = "多维度对标",
    dark_mode: bool = False,
):
    """
    雷达图：多维度对标。
    Args:
        categories: 维度名称列表（如['毛利率','ROE','增速','负债率','市场份额','技术壁垒']）
        series: {公司名: 评分列表}
        title: 标题
    """
    _setup_matplotlib(dark_mode)
    c = COLORS_DARK if dark_mode else COLORS_LIGHT
    bg = c['bg']
    text = c['text']
    grid = c['grid']

    N = len(categories)
    angles = [n / N * 2 * np.pi for n in range(N)]
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(9, 9), subplot_kw=dict(polar=True))
    color_pool = [c['primary'], c['accent'], c['success'], c['danger'], c['secondary']]
    for i, (name, values) in enumerate(series.items()):
        vals = list(values) + list(values[:1])
        color = color_pool[i % len(color_pool)]
        ax.plot(angles, vals, color=color, linewidth=2.5, label=name)
        ax.fill(angles, vals, color=color, alpha=0.18)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=FONT_SIZE['tick'], color=text)
    ax.tick_params(axis='y', labelsize=FONT_SIZE['tick']-1, colors=text)
    ax.set_title(title, fontsize=FONT_SIZE['title'], color=text, fontweight='bold', pad=24)
    ax.legend(loc='upper right', bbox_to_anchor=(1.32, 1.10), fontsize=FONT_SIZE['legend'])
    ax.set_facecolor(bg)
    fig.patch.set_facecolor(bg)
    ax.spines['polar'].set_color(grid)
    ax.grid(color=grid, alpha=0.4)
    return fig


# ============================================================
# 图 4：饼图（结构占比）
# ============================================================
def chart_pie_structure(
    labels: list,
    sizes: list,
    title: str = "结构占比",
    dark_mode: bool = False,
):
    """饼图"""
    _setup_matplotlib(dark_mode)
    c = COLORS_DARK if dark_mode else COLORS_LIGHT
    bg = c['bg']
    text = c['text']

    color_pool = [c['primary'], c['accent'], c['success'], c['danger'],
                  c['secondary'], c['info'], c['warning'], c['neutral']]

    fig, ax = plt.subplots(figsize=(10, 6.5))
    wedges, texts, autotexts = ax.pie(
        sizes, labels=labels, colors=color_pool[:len(labels)], autopct='%1.1f%%',
        startangle=90, textprops={'fontsize': FONT_SIZE['axis_label'], 'color': text},
        wedgeprops={'edgecolor': bg, 'linewidth': 2},
    )
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontsize(FONT_SIZE['bar_value'])
        autotext.set_fontweight('bold')

    ax.set_title(title, fontsize=FONT_SIZE['title'], color=text, fontweight='bold', pad=18)
    fig.patch.set_facecolor(bg)
    return fig


# ============================================================
# 图 5：场景柱状（IRR 三情景）
# ============================================================
def chart_scenario_irr(
    scenarios: list,    # ['保守', '中性', '乐观']
    irr_values: list,   # [12.5, 18.3, 24.6]
    title: str = "IRR 情景分析",
    ylabel: str = "IRR (%)",
    dark_mode: bool = False,
):
    """IRR 三情景对比"""
    _setup_matplotlib(dark_mode)
    c = COLORS_DARK if dark_mode else COLORS_LIGHT
    bg = c['bg']
    text = c['text']
    grid = c['grid']

    # 三种颜色
    color_map = [c['danger'], c['accent'], c['success']]
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.bar(scenarios, irr_values,
                  color=[color_map[i] for i in range(len(scenarios))],
                  alpha=0.92, width=0.55)
    for bar, val in zip(bars, irr_values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(irr_values) * 0.02,
                f'{val:.1f}%', ha='center', va='bottom',
                fontsize=FONT_SIZE['bar_value']+1, color=text, fontweight='bold')

    ax.set_ylabel(ylabel, fontsize=FONT_SIZE['axis_label'], color=text)
    ax.set_title(title, fontsize=FONT_SIZE['title'], color=text, fontweight='bold', pad=18)
    ax.tick_params(axis='both', labelsize=FONT_SIZE['tick'], colors=text)
    ax.set_facecolor(bg)
    fig.patch.set_facecolor(bg)
    for spine in ['top', 'right']:
        ax.spines[spine].set_visible(False)
    ax.spines['left'].set_color(grid)
    ax.spines['bottom'].set_color(grid)
    ax.set_ylim(0, max(irr_values) * 1.18)
    ax.grid(axis='y', alpha=0.3, color=grid)
    return fig


# ============================================================
# 图 6：折线（多年趋势）
# ============================================================
def chart_line_trend(
    x_data: list,
    y_series: dict,  # {'指标A': [v1,v2,...], '指标B': [...]}
    title: str = "趋势",
    xlabel: str = "年份",
    ylabel: str = "数值",
    dark_mode: bool = False,
):
    """折线趋势（多指标）"""
    _setup_matplotlib(dark_mode)
    c = COLORS_DARK if dark_mode else COLORS_LIGHT
    bg = c['bg']
    text = c['text']
    grid = c['grid']

    color_pool = [c['primary'], c['accent'], c['success'], c['danger'], c['secondary']]
    fig, ax = plt.subplots(figsize=(12, 5.5))
    for i, (name, values) in enumerate(y_series.items()):
        color = color_pool[i % len(color_pool)]
        ax.plot(x_data, values, marker='o', markersize=8, linewidth=2.5,
                color=color, label=name)
        # 数值标签
        for x, y in zip(x_data, values):
            ax.annotate(f'{y:.1f}', (x, y), textcoords='offset points',
                        xytext=(0, 8), ha='center',
                        fontsize=FONT_SIZE['annotation'], color=color, fontweight='bold')

    ax.set_title(title, fontsize=FONT_SIZE['title'], color=text, fontweight='bold', pad=18)
    ax.set_xlabel(xlabel, fontsize=FONT_SIZE['axis_label'], color=text)
    ax.set_ylabel(ylabel, fontsize=FONT_SIZE['axis_label'], color=text)
    ax.tick_params(axis='both', labelsize=FONT_SIZE['tick'], colors=text)
    ax.legend(fontsize=FONT_SIZE['legend'], loc='best')
    ax.grid(True, alpha=0.3, color=grid)
    ax.set_facecolor(bg)
    fig.patch.set_facecolor(bg)
    for spine in ['top', 'right']:
        ax.spines[spine].set_visible(False)
    ax.spines['left'].set_color(grid)
    ax.spines['bottom'].set_color(grid)
    return fig


# ============================================================
# 图 7：KPI 数字仪表盘（4 个核心指标）
# ============================================================
def chart_kpi_dashboard(
    kpi_data: list,  # [{'label': '估值', 'value': '42.02', 'unit': '亿', 'color': 'primary'}, ...]
    title: str = "核心 KPI",
    dark_mode: bool = False,
):
    """
    KPI 数字仪表盘（4 个 KPI 横排）。
    """
    _setup_matplotlib(dark_mode)
    c = COLORS_DARK if dark_mode else COLORS_LIGHT
    bg = c['bg']
    text = c['text']
    grid = c['grid']

    n = len(kpi_data)
    fig, axes = plt.subplots(1, n, figsize=(4.5 * n, 4.2))
    if n == 1:
        axes = [axes]

    for ax, kpi in zip(axes, kpi_data):
        color_key = kpi.get('color', 'primary')
        color = c.get(color_key, c['primary'])

        ax.set_facecolor(bg)
        ax.text(0.5, 0.65, kpi.get('value', ''),
                ha='center', va='center',
                fontsize=42, color=color, fontweight='bold',
                transform=ax.transAxes)
        if kpi.get('unit'):
            ax.text(0.85, 0.65, kpi.get('unit', ''),
                    ha='left', va='center',
                    fontsize=18, color=color, fontweight='bold',
                    transform=ax.transAxes)
        ax.text(0.5, 0.30, kpi.get('label', ''),
                ha='center', va='center',
                fontsize=14, color=text,
                transform=ax.transAxes)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_color(color)
            spine.set_linewidth(2.5)

    fig.suptitle(title, fontsize=FONT_SIZE['title'], color=text, fontweight='bold', y=1.02)
    fig.patch.set_facecolor(bg)
    return fig


# ============================================================
# 图 8：堆叠柱状（多类目多年对比）
# ============================================================
def chart_stacked_bar(
    x_data: list,
    y_series: dict,  # {'机房运维': [v1,v2,...], '智算业务': [...]}
    title: str = "业务结构",
    xlabel: str = "年份",
    ylabel: str = "金额",
    dark_mode: bool = False,
):
    """堆叠柱状图"""
    _setup_matplotlib(dark_mode)
    c = COLORS_DARK if dark_mode else COLORS_LIGHT
    bg = c['bg']
    text = c['text']
    grid = c['grid']

    color_pool = [c['primary'], c['accent'], c['success'], c['danger'],
                  c['secondary'], c['info']]
    fig, ax = plt.subplots(figsize=(11, 6))
    x = np.arange(len(x_data))
    width = 0.55
    bottom = np.zeros(len(x_data))
    for i, (name, values) in enumerate(y_series.items()):
        color = color_pool[i % len(color_pool)]
        bars = ax.bar(x, values, width, bottom=bottom, color=color, label=name, alpha=0.92)
        # 段内数值
        for j, (xi, vi) in enumerate(zip(x, values)):
            if vi > 0:
                ax.text(xi, bottom[j] + vi/2, f'{vi:.1f}', ha='center', va='center',
                        fontsize=FONT_SIZE['annotation'], color='white', fontweight='bold')
        bottom += np.array(values)
    # 总数标签
    for j, total in enumerate(bottom):
        ax.text(j, total + total * 0.02, f'合计 {total:.1f}', ha='center', va='bottom',
                fontsize=FONT_SIZE['bar_value'], color=text, fontweight='bold')

    ax.set_xticks(x)
    ax.set_xticklabels(x_data, fontsize=FONT_SIZE['tick'], color=text)
    ax.set_title(title, fontsize=FONT_SIZE['title'], color=text, fontweight='bold', pad=18)
    ax.set_xlabel(xlabel, fontsize=FONT_SIZE['axis_label'], color=text)
    ax.set_ylabel(ylabel, fontsize=FONT_SIZE['axis_label'], color=text)
    ax.tick_params(axis='y', labelsize=FONT_SIZE['tick'], colors=text)
    ax.legend(fontsize=FONT_SIZE['legend'], loc='upper left')
    ax.set_facecolor(bg)
    fig.patch.set_facecolor(bg)
    for spine in ['top', 'right']:
        ax.spines[spine].set_visible(False)
    ax.spines['left'].set_color(grid)
    ax.spines['bottom'].set_color(grid)
    ax.grid(axis='y', alpha=0.3, color=grid)
    return fig


# ============================================================
# 工具函数：保存图表对（浅色+暗色 → base64 嵌入 HTML）
# ============================================================
def save_chart_pair(fig, name: str, out_dir: str = './charts'):
    """
    保存单张图为浅色+暗色两个 base64 SVG 文件。
    返回：{'light': b64_str, 'dark': b64_str, 'svg_files': [...], 'embedded_html': '...'}
    """
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    # 浅色 SVG（直接写文件 + 返回 base64）
    light_b64 = _save_svg_base64(fig, dark_mode=False)
    light_file = out_path / f"{name}_light.svg"
    light_file.write_bytes(base64.b64decode(light_b64))

    return {
        'light_base64': light_b64,
        'light_file': str(light_file),
    }


def save_chart_pair_dual(fig_light, fig_dark, name: str, out_dir: str = './charts'):
    """
    保存浅色 + 暗色 双版本 SVG。
    Args:
        fig_light: 浅色版 fig（dark_mode=False）
        fig_dark: 暗色版 fig（dark_mode=True）
    """
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    light_b64 = _save_svg_base64(fig_light, dark_mode=False)
    dark_b64 = _save_svg_base64(fig_dark, dark_mode=True)

    light_file = out_path / f"{name}_light.svg"
    dark_file = out_path / f"{name}_dark.svg"
    light_file.write_bytes(base64.b64decode(light_b64))
    dark_file.write_bytes(base64.b64decode(dark_b64))

    return {
        'light_base64': light_b64,
        'dark_base64': dark_b64,
        'light_file': str(light_file),
        'dark_file': str(dark_file),
    }


# ============================================================
# 嵌入 HTML 的工具：生成 chart-data 容器
# ============================================================
def make_chart_html_block(
    name: str,
    light_base64: str,
    dark_base64: str,
    data_table_html: str = "",
    caption: str = "",
) -> str:
    """
    生成可直接嵌入 markdown/HTML 的图表容器。
    双图叠加（light/dark）+ 可选 data_table。
    """
    return f'''<figure class="chart-figure" id="{name}">
  <div class="chart-pair">
    <img class="chart-light" src="data:image/svg+xml;base64,{light_base64}" alt="{name} 浅色图" />
    <img class="chart-dark" src="data:image/svg+xml;base64,{dark_base64}" alt="{name} 暗色图" />
  </div>
  {f'<figcaption class="chart-caption">{caption}</figcaption>' if caption else ''}
  {f'<div class="chart-data-table">{data_table_html}</div>' if data_table_html else ''}
</figure>'''


# ============================================================
# 简洁测试入口
# ============================================================
if __name__ == '__main__':
    # 测试：汇天财务时序
    years = [2023, 2024, 2025]
    revenue = [2937.93, 5931.63, 7843.14]
    net_profit = [-156, 102, 467]  # 万元

    fig = chart_financial_timeline(
        years=years,
        revenue=revenue,
        net_profit=net_profit,
        title="汇天网络科技 2023-2025 财务时序",
    )
    print("✅ chart_financial_timeline 测试通过")
    fig2 = chart_radar_compare(
        categories=['营收规模', '增速', '毛利率', '客户质量', '技术壁垒', '运营效率'],
        series={'汇天': [70, 80, 65, 85, 75, 80], '同业均值': [60, 50, 55, 65, 60, 60]},
        title="汇天 vs 同业 雷达对标",
    )
    print("✅ chart_radar_compare 测试通过")
    fig3 = chart_scenario_irr(
        scenarios=['保守\n(7折认购)', '中性\n(5折认购)', '乐观\n(全额)'],
        irr_values=[11.2, 16.8, 22.5],
        title="天保能源 IRR 三情景",
    )
    print("✅ chart_scenario_irr 测试通过")
    print("\n所有图表测试通过。可在 hv-analysis 流程中导入并使用。")