# 纵横分析法（hv-analysis）V3.46.0

**研究代理唯一方法论**。所有涉及具体公司/并购/估值/尽调/竞争分析的研报任务，统一走此流程。

## 一句话总结

```
Phase 0（读本地+预热）→ Phase 1（纵向 8 章）→ Phase 2（横向 6 章）→ Phase 3（交叉 7 章）→ Phase 4（决策 4 章）→ 图表 ≥5 张 → HTML 渲染 → 部署推送
```

## 入口

| 入口 | 类型 | 用法 |
|------|------|------|
| **`hv-start.sh`** | Shell 一键入口 | `./hv-start.sh 汇天网络科技 --render-html --push-deploy` |
| **`scripts/hv-auto-research.py`** | Python 一键入口 | `python3 scripts/hv-auto-research.py 汇天网络科技 --render-html --push-deploy` |
| **`SKILL.md`** | 方法论文档（1053 行） | Phase 0→1→2→3→4 + §十二自检 |

## 关键流程

1. **Phase 0**：读 `~/Documents/OpenClaw-Workspace-research/projects/<项目>/extracted/` 本地文件
2. **Phase 1-3**：纵向→横向→交叉分析（Agent 写 MD）
3. **Phase 4**（决策模式）：交易结构 + 退出路径 + 约束 + 情景推演
4. **图表 ≥5 张**：调用 `scripts/charts/hv_charts.py`（V3.46.0 强制）
5. **嵌入**：调用 `scripts/charts/embed_charts_into_md.py`
6. **HTML 渲染**：调用 `report-html-publish/scripts/md_to_html_v3422.py`
7. **部署推送**：`sessions_send` 给 project 代理

## 脚本索引

| 脚本 | 字节 | 职责 |
|------|-----:|------|
| `hv-start.sh` | 800 | Shell 一键入口 |
| `scripts/hv-auto-research.py` | 9.5K | Python 一键入口（主） |
| `scripts/charts/hv_charts.py` | 23.5K | V3.46.0 图表生成（8 种）|
| `scripts/charts/make_huitian_charts.py` | 9.5K | 实战案例参考 |
| `scripts/charts/embed_charts_into_md.py` | 2.6K | MD 占位符 → base64 嵌入 |
| `scripts/hv_render_wrapper.py` | 9K | HTML 渲染包装 |
| `scripts/hv_challenge_a_v2.py` | 20K | 质疑节点 A（数据召回）|
| `scripts/hv_challenge_b_v3.py` | 29K | 质疑节点 B（幻觉检测）|

## 配置规范引用

- **AGENTS.md**（行 73）：研究任务强制路由 → hv-analysis
- **AGENTS.md**（行 660+）：V3.46.0 图表强制规则
- **TOOLS.md**（行 11）：唯一方法论声明
- **MEMORY.md**：Lesson 40（无图）、41（数据源）、42（主入口）教训

## 反模式（绝对禁止）

- ❌ 直接调 `tavily_search` / `web_search` 作为主数据源
- ❌ 跳 Phase（0→1→2→3→4 必须全走）
- ❌ 报告 0 张图（违反 V3.46.0 强制 ≥5 张）
- ❌ 港股数据用"业内传言"（必须港交所原文为准）
- ❌ 主入口删除不留替代（Lesson 42 教训：hv-full-research.py 删了 → 流程断了 5 天）
