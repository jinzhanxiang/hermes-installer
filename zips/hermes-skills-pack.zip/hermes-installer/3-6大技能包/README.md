# Hermes Shared Skills Pack

> 打包自 [Hermes Agent](https://hermes-agent.nousresearch.com) 配置，2026-07-16
> 包含 3 个精华技能：browser-automation / opencli-integration / daily-briefing-combo

## 安装方法

### 方式一：直接解压到 skills 目录（推荐）

```bash
# 1. 解压到 Hermes skills 目录
tar xzf hermes-skills-pack.tar.gz -C ~/.hermes/skills/

# 2. 确认安装成功
hermes skills list | grep -E "browser-automation|opencli-integration|daily-briefing"

# 3. 按各 skill 的 SETUP.md 配置依赖
```

### 方式二：逐个安装（按需加载）

```bash
# 每个 skill 独立安装在对应分类目录下
# 然后按各 SETUP.md 配置
```

### 方式三：发布到 GitHub 后通过 URL 安装

```bash
# 先上传到 GitHub
# 然后朋友安装
hermes skills install https://raw.githubusercontent.com/你的用户名/hermes-shared-skills/main/browser-automation/SKILL.md
hermes skills install https://raw.githubusercontent.com/你的用户名/hermes-shared-skills/main/opencli-integration/SKILL.md
```

## 包含的技能

| # | 技能 | 目录 | 说明 | 依赖 |
|:-:|:----|:----|:----|:----|
| 1 | **browser-automation** | `autonomous-ai-agents/browser-automation/` | ⭐ 多路径浏览器编排器，5 条路径自动切换，HITL 人机协作 | CloakBrowser（可选） |
| 2 | **opencli-integration** | `autonomous-ai-agents/opencli-integration/` | ⭐ 164 个站点一站查询，三源融合企业尽调 | OpenCLI + Chrome 扩展 |
| 3 | **daily-briefing + domain-watcher** | `productivity/daily-briefing-combo/` | 多源融合晨报 + 关键人物动态追踪 | 无 |

## 前置要求

- Hermes Agent（最新版）
- 各 skill 的 SETUP.md 说明见对应目录

---

> 如需完整 Hermes 配置（config.yaml + .env + cron jobs），请联系原作者。