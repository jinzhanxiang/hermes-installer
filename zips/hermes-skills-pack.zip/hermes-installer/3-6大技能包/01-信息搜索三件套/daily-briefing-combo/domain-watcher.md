---
name: domain-watcher
description: 多领域关键人物动态追踪 — 根据 YAML 配置自动追踪多个领域（AI、创新药、小米等）的关键人物动态，支持新增领域自动扩展。用于晨报的"关键人物动态"板块。
---

# Domain Watcher — 多领域关键人物动态追踪

## 用途

根据 `~/.hermes/domain-watcher.yaml` 的配置，自动追踪多个领域的关键人物动态。每个领域可配置：
- 追踪的关键人物名单
- 搜索关键词
- X/Twitter 账号（可选，需配合 OpenCLI）

## 配置文件

位置：`~/.hermes/domain-watcher.yaml`

```yaml
domains:
  pharma:
    name: "创新药"
    people:
      - 王晓东    # 百济神州创始人
      - 孙飘扬    # 恒瑞医药董事长
    keywords:
      - 创新药
      - 新药获批
    x_accounts: []
```

新增领域只需在 `domains` 下加一个 entry，第二天晨报自动生效。

## 工作流程

### Step 1: 读取配置

```python
import yaml
with open(os.path.expanduser('~/.hermes/domain-watcher.yaml')) as f:
    config = yaml.safe_load(f)
```

### Step 2: 遍历每个 domain

对每个 domain：

**如果 domain 有 `skill` 字段（如 `ai` → `follow-builders`）：**
- 加载该 skill 获取数据
- 直接使用该 skill 的输出

**如果 domain 有 `people` 列表：**
- 对每个人物，用 `web_search` 搜索 `"{人物名}" 最新动态 最近一周`
- 对每个关键词，用 `web_search` 搜索 `"{关键词}" 最新消息`
- 去重后按时间排序

**如果 domain 有 `x_accounts` 列表：**
- 可选：通过 OpenCLI 的 X/Twitter 命令获取指定账号最新推文
- 需要 OpenCLI 扩展支持

### Step 3: 输出格式

每个 domain 输出独立板块：

```markdown
## 💊 创新药动态

- **王晓东** — 百济神州宣布...  [来源链接]
- **孙飘扬** — 恒瑞医药...  [来源链接]
- **关键词热点** — 创新药板块...  [来源链接]
```

### Step 4: 合并到晨报

`daily-briefing` skill 会调用 `domain-watcher` 获取所有领域的人物动态，然后合并到晨报输出中。

## 用于晨报 cron

在 cron job 的 prompt 中，加载 `domain-watcher` skill 后：
1. 读取 `~/.hermes/domain-watcher.yaml` 配置文件
2. 遍历所有 domain
3. 对每个 domain 获取关键人物动态
4. 输出为晨报的"关键人物动态"板块

### Cron prompt 模板

各领域人物动态的 prompt 段落结构：

```
## 👥 各领域关键人物动态

{{#各领域}}
### {{domain.name}}

{{#domain.people}}
- **{{person}}**: 搜索 "{{person}} 最新动态 最近一周" 的结果
{{/domain.people}}

{{#domain.keywords}}
- **{{keyword}}**: 搜索 "{{keyword}} 最新消息" 的关键新闻
{{/domain.keywords}}
{{/各领域}}
```

### 实际执行格式

在 cron 中，prompt 应包含类似以下指令：

```
对于 domain-watcher.yaml 中的每个领域：
- 如果该领域有 skill 字段，加载该 skill 获取数据
- 如果该领域有 people 列表，对每个人物用 web_search 搜索最新动态
- 如果该领域有 keywords 列表，对每个关键词搜索最新新闻
- 去重后输出该领域的人物动态板块
```

## 新增领域

1. 编辑 `~/.hermes/domain-watcher.yaml`，在 `domains` 下添加新 entry
2. 指定人物名单、关键词
3. 第二天晨报自动生效

## 注意事项

- 人物搜索依赖 `web_search`，可能受搜索引擎结果质量影响
- 关键词搜索和人物搜索可能产生重复结果，需去重
- 如果是 cron 运行，不需要用户交互，直接输出结果
- 如果某个 domain 没有新内容，跳过该板块，不写"暂无数据"

## 参考文件

| 文件 | 内容 |
|:----|:------|
| [references/config-reference.md](references/config-reference.md) | YAML 配置结构详解、新增领域示例 |
| [references/search-queries.md](references/search-queries.md) | 各领域搜索查询模板和去重策略 |

## 在晨报 cron 中的使用

1. 确保 cron job 加载了 `domain-watcher` skill：`hermes cron edit <id> --add-skill domain-watcher`
2. cron prompt 中遍历 `~/.hermes/domain-watcher.yaml` 的所有 domain
3. 每个 domain 按配置获取人物动态或关键词新闻，输出独立板块