---
name: daily-briefing
description: 多源融合中文晨报 — 并行扇出多个来源（aihot/domain-watcher/web_search）后合成为一份结构化晨报
---

# Daily Briefing（每日简报）

## 分层架构（agent-skills 模式）

| 层 | 解释 | 在本 skill 中 |
|:--|:----|:-------------|
| **Skills** | 独立数据源工作流 | `aihot`、`domain-watcher`、`follow-builders`、`web_search` |
| **Personas** | 各来源的角色约束 | 每个 source 独立 fetch，无交叉污染 |
| **Orchestration** | 并行扇出 → 合成 | 同时触发所有来源 → 等待全部返回 → 合并排序去重 |

**核心原则：** Sources are independent. No source waits for another. Synthesis is final step only.

## 用途

将多个独立来源的信息合并为一份结构化中文晨报。每天定时生成涵盖 AI 圈动态、行业人物观点、特定板块新闻的综合简报。

## 数据来源

| 来源 | 负责技能 | 获取内容 |
|------|----------|----------|
| AI 中文资讯 | `aihot` | AI HOT 精选条目、热点话题、日报 |
| 多领域人物动态 | `domain-watcher` + `follow-builders` | 各领域关键人物动态（AI/创新药/小米等） |
| 行业新闻 | `web_search` + `domain-watcher` config | 根据 `~/.hermes/domain-watcher.yaml` 配置搜索 |

## 输出格式

```markdown
📰 AI 热点速览（aihot 精选条目，每条 1-2 行）
👥 <领域1> 关键人物动态（如 AI builders）
💊 <领域2> 关键人物动态（如创新药人物）
📱 <领域3> 关键人物动态（如小米人物）
⚡ 值得关注（精选 3 条最有价值信息，不限领域）
```

每个领域的人物动态板块自动根据 `~/.hermes/domain-watcher.yaml` 的配置生成。新增领域无需改 prompt。

## 工作流程

### Step 0: 读取 domain-watcher 配置
读取 `~/.hermes/domain-watcher.yaml`，获取所有配置的 domain 列表。
先确定哪些 domain 需要人物追踪（有 `people` 配置或有 `skill` 配置）。

### Step 1: 运行 AI HOT
加载 `aihot` 技能，执行版本自检，然后：
- 获取 `/api/public/items?mode=selected&since=<24h>` 获取精选条目
- 如热点明确，也可获取 `/api/public/hot-topics`
- 按发布时间倒序，精选最有价值的 5-8 条

### Step 2: 运行 domain-watcher（多领域人物动态追踪）
加载 `domain-watcher` 技能，然后遍历 `~/.hermes/domain-watcher.yaml` 中所有 domain：

**每个 domain 的处理方式：**
- 如果 domain 有 `skill` 字段（如 `ai` → `follow-builders`）：
  - 加载该 skill 获取数据，使用该 skill 的输出作为该领域的人物动态
- 如果 domain 有 `people` 列表（如 `pharma`、`xiaomi`）：
  - 对每个人物，用 `web_search` 搜索 `"{人物名}" 最新动态 最近一周`
  - 对每个关键词，用 `web_search` 搜索 `"{关键词}" 最新消息`
  - 去重并按时间排序，每个 domain 精选 3-5 条
- 如果某个 domain 没有新内容，跳过该板块

### Step 3: 合并整理
按输出格式组织，每节 3-8 条，每条 1-2 行中文。
人物动态板块按 `domain-watcher.yaml` 中 domain 的顺序排列。
最后 ⚡ 值得关注 选 3 条最有价值的信息并附简短点评。

## 注意事项

- **总字数控制在 2500 字以内**，不要超过。
- 时间是默认北京/中国时间，用"昨天"、"今天"等人话表达。
- 每条信息给出公开链接。
- 不编造 API 没返回的数据或因果关系。
- 如果某个来源没有新内容，直接跳过该节，不写"暂无数据"。
- 各节按重要性排序，不是固定顺序。
- 不加免责声明和冗余解释。

## Common rationalizations

| 常见借口 | Skill 的回应 |
|---------|------------|
| "aihot 没数据就跳过吧" | 跳过该节，但其他来源必须继续 |
| "先等 domain-watcher 回来再跑搜索" | 并行扇出，互不等待 |
| "昨天数据差不多" | 每天 sta 不同，重复是信息本身的问题，不是 skill 的问题 |
| "字数超了删掉一些" | 优先删最低价值来源，而非均匀裁剪 |

## Cron 场景

如果作为 cron 作业运行（无用户交互）：
1. 不要尝试引导（onboarding）或提问
2. 不要尝试投递 Telegram/Email
3. 直接输出 stdout，系统自动处理投递
4. 如果没有任何新内容，输出 `[SILENT]` 抑制空投递