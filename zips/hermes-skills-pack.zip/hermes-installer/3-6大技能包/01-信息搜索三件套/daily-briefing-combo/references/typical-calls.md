# 典型调用模式（基于 2026-07-14 会话）

以下是从本次成功会话中提取的具体 API 调用和工作流，供下一次 cron 运行参考。

## AI HOT

```bash
UA="aihot-skill/0.3.5 (+https://aihot.virxact.com/aihot-skill/)"

# 版本自检（每会话一次）
curl -sS --max-time 10 -H "User-Agent: $UA" "https://aihot.virxact.com/api/public/version"

# 最近 24 小时精选
since=$(date -u -v-24H +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '24 hours ago' +%Y-%m-%dT%H:%M:%SZ)
curl -sS --max-time 20 -H "User-Agent: $UA" "https://aihot.virxact.com/api/public/items?mode=selected&since=$since&take=50"
```

版本 0.3.5 匹配（2026-07-13）。需要检查线上版本是否更新。

## Follow-Builders（GitHub API 回退）

当 `~/.follow-builders/scripts/prepare-digest.js` 不存在时，通过 GitHub API 获取 feed：

```python
import urllib.request, json, base64

def decode_github_file(url):
    req = urllib.request.Request(url, headers={"User-Agent": "HermesAgent/1.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read())
        if 'content' in data:
            return base64.b64decode(data['content']).decode('utf-8')
        else:
            return json.dumps({"error": data.get('message', 'unknown')})

x_feed = json.loads(decode_github_file(
    "https://api.github.com/repos/zarazhangrui/follow-builders/contents/feed-x.json"))
p_feed = json.loads(decode_github_file(
    "https://api.github.com/repos/zarazhangrui/follow-builders/contents/feed-podcasts.json"))
b_feed = json.loads(decode_github_file(
    "https://api.github.com/repos/zarazhangrui/follow-builders/contents/feed-blogs.json"))
```

同样可获取 prompts 目录下的 remix 指令。

## Web Search 关键词策略

对于创新药/生物医药话题：

| 意图 | 搜索词 |
|------|--------|
| 板块行情 | `创新药板块 政策利好 暴涨` |
| 行业趋势 | `创新药 国产 出海 临床数据 BD` |
| 个股动态 | `创新药股票 最新消息` |
| 政策 | `生物医药 政策 基本药物目录` |

对于小米话题：

| 意图 | 搜索词 |
|------|--------|
| 汽车 | `小米汽车 澎程 N90` 或 `小米 SU7 最新` |
| 手机 | `小米17 Ultra 发布` |
| 综合 | `小米公司 最新消息` 或 `小米集团 动态` |

## 关键注意事项

1. **AI HOT 没有热点数据时不要慌** — `hot-topics` 可能返回空数组，此时用 `items?mode=selected` 代替。
2. **follow-builders feed-x 可能空** — 如果 `x` 数组为空，跳过人物动态节即可。
3. **web_search 的结果质量** — 优先用带日期的 SRP 片段判断时效性；如果 3 天内的结果太少，可适当放宽到 1 周。
4. **cron 作业不提问** — 任何需要用户输入的场景都跳过。
5. **输出长度** — 硬上限 2500 字，建议控制在 1800-2200 字为佳。
