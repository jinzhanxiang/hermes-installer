# domain-watcher.yaml 配置参考

位置: `~/.hermes/domain-watcher.yaml`

## 完整结构

```yaml
domains:
  # 每个 domain 是一个键值对
  <domain-key>:
    name: "<显示名称>"
    
    # 方案A: 复用现有 skill（如 follow-builders 的 AI builder 数据）
    skill: <skill-name>
    
    # 方案B: 追踪具体人物（需配置 people + keywords）
    people:
      - "<人物名1>"
      - "<人物名2>"
    keywords:
      - "<搜索关键词1>"
      - "<搜索关键词2>"
    x_accounts:
      - "<X/Twitter 账号名>"
```

## 当前配置的领域

| 领域 | key | 类型 | 配置 |
|:----|:----|:-----|:----|
| AI 人物动态 | `ai` | skill 复用 | 使用 `follow-builders` |
| 创新药动态 | `pharma` | 人物追踪 | 20 位关键人物 + 6 组关键词 |
| 小米动态 | `xiaomi` | 人物追踪 | 11 位关键人物 + 6 组关键词 |

## 新增领域示例

```yaml
domains:
  新能源:
    name: "新能源"
    people:
      - 曾毓群
      - 王传福
      - 李斌
    keywords:
      - 新能源 电池
      - 光伏 行业
      - 储能
```

新增后无需改代码，第二天晨报自动生效。

## 限制

- 每个 domain 的 `people` 和 `keywords` 通过 `web_search` 搜索，受搜索引擎结果质量影响
- 人物名越具体越好，避免同名歧义
- `x_accounts` 需要 OpenCLI X/Twitter 支持（可选）
- 一个 domain 不能同时使用 `skill` 和 `people`