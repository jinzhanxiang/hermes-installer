# Daily Briefing Combo 安装说明

> 包含两个技能：**daily-briefing**（多源融合晨报）+ **domain-watcher**（关键人物动态追踪）

## 技能文件

解压后放置在：`~/.hermes/skills/productivity/daily-briefing-combo/`

需手动拆分为两个独立技能：

```bash
# daily-briefing 本体
cp ~/.hermes/skills/productivity/daily-briefing-combo/SKILL.md \
   ~/.hermes/skills/productivity/daily-briefing/SKILL.md
cp ~/.hermes/skills/productivity/daily-briefing-combo/references/typical-calls.md \
   ~/.hermes/skills/productivity/daily-briefing/references/

# domain-watcher
cp ~/.hermes/skills/productivity/daily-briefing-combo/domain-watcher.md \
   ~/.hermes/skills/productivity/domain-watcher/SKILL.md
cp ~/.hermes/skills/productivity/daily-briefing-combo/references/config-reference.md \
   ~/.hermes/skills/productivity/domain-watcher/references/
cp ~/.hermes/skills/productivity/daily-briefing-combo/references/search-queries.md \
   ~/.hermes/skills/productivity/domain-watcher/references/
```

或直接使用以下命令一键拆分：

```bash
mkdir -p ~/.hermes/skills/productivity/daily-briefing/references
mkdir -p ~/.hermes/skills/productivity/domain-watcher/references
cp ~/.hermes/skills/productivity/daily-briefing-combo/SKILL.md ~/.hermes/skills/productivity/daily-briefing/
cp ~/.hermes/skills/productivity/daily-briefing-combo/references/typical-calls.md ~/.hermes/skills/productivity/daily-briefing/references/
cp ~/.hermes/skills/productivity/daily-briefing-combo/domain-watcher.md ~/.hermes/skills/productivity/domain-watcher/SKILL.md
cp ~/.hermes/skills/productivity/daily-briefing-combo/references/config-reference.md ~/.hermes/skills/productivity/domain-watcher/references/
cp ~/.hermes/skills/productivity/daily-briefing-combo/references/search-queries.md ~/.hermes/skills/productivity/domain-watcher/references/
```

## 依赖检查

✅ **无外部依赖** — 纯 skill 编排，不依赖任何第三方服务或 API Key

确认 Hermes 有以下工具可用：
- `web_search`（搜索服务）
- `delegate_task`（并行扇出任务）

## 核心功能

### daily-briefing

自动聚合多来源信息生成结构化晨报：

```
[用户] 生成今天的晨报
[Agent] 并行扇出多个来源：
  1. aihot → AI 热点速览
  2. domain-watcher → 关键人物动态
  3. web_search → 今天新闻摘要
[Agent] 合并为结构化晨报 → 推送
```

### domain-watcher

追踪多个领域关键人物的最新动态：

- **AI 领域**：Sam Altman、Dario Amodei、Demis Hassabis 等
- **创新药领域**：已配置追踪
- **小米领域**：雷军等
- 可通过 YAML 配置自定义扩展

### 配置 cron 自动推送

```bash
# 每天早上 7:00 自动生成并推送晨报到微信
hermes cron create "0 7 * * *"
# 输入 prompt：生成今天的每日晨报并推送到微信
```

## 使用示例

```bash
# 在 Hermes 中
"生成今天的每日晨报"

# 或查看特定领域人物动态
"雷军最近有什么动态？"

# 新增追踪领域
"帮我新增一个领域：新能源汽车，关注李斌、何小鹏、李想"
```

## 注意事项

- domain-watcher 的追踪依赖 web_search 搜索结果质量
- 建议配合 cron 使用，每天早上自动推送
- 可自定义 `references/config-reference.md` 中的领域配置