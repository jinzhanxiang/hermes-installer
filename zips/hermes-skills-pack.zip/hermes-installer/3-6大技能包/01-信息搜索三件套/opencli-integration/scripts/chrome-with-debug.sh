#!/bin/bash
# 自动重启Chrome并带远程调试端口，使OpenCLI能共享主Chrome登录态
# 用法: bash ~/.hermes/scripts/chrome-with-debug.sh
# 适用场景: Chrome双实例问题 — OpenCLI browser启动独立Chrome，不与主Chrome共享登录态
# 详见: opencli-integration skill → "Chrome 双实例与登录态隔离"章节

echo "[1/5] 正常退出Chrome（必须用osascript，禁止pkill -9）..."
osascript -e 'quit app "Google Chrome"'
sleep 2

echo "[2/5] 启动Chrome（带--remote-debugging-port=18800）..."
open -a "Google Chrome" --args \
  --remote-debugging-port=18800 \
  --user-data-dir="$HOME/Library/Application Support/Google/Chrome"
sleep 5

echo "[3/5] 重启OpenCLI daemon..."
export PATH="$HOME/.npm-global/bin:$PATH"
opencli daemon restart 2>/dev/null
sleep 3

echo "[4/5] 验证远程调试端口..."
pgrep -f "remote-debugging-port" > /dev/null && echo "  ✅ 端口18800已开启" || echo "  ❌ 端口未开启"

echo "[5/5] 验证OpenCLI连接状态..."
opencli doctor 2>&1 | head -5

echo ""
echo "完成！OpenCLI browser 现在将共享主Chrome的登录态。"
echo "注意：Chrome正常重启后此参数丢失，需重新运行此脚本。"