# opencli-integration 安装说明

## 技能目录

解压后放置在：`~/.hermes/skills/autonomous-ai-agents/opencli-integration/`

## 依赖安装

### 1. 安装 OpenCLI

```bash
# 全局安装
npm install -g opencli

# 确认安装
opencli --version
opencli doctor  # 检查 daemon + 扩展连接状态
```

### 2. 安装 OpenCLI Chrome 扩展

**方法 A — Chrome 应用商店（推荐）：**
打开 https://chromewebstore.google.com/detail/opencli/ildkmabpimmkaediidaifkhjpohdnifk 点击「添加至 Chrome」

**方法 B — 手动加载（被墙地区）：**
1. 从 GitHub Releases 下载扩展 ZIP：https://github.com/jackwener/opencli/releases
2. 解压后，打开 `chrome://extensions`，开启「开发者模式」
3. 点击「加载已解压的扩展程序」→ 选择解压的文件夹

### 3. 启动 OpenCLI Daemon

```bash
# 启动 daemon
opencli daemon start

# 验证连接
opencli doctor
# 应显示：Extension: connected, Daemon: running
```

### 4. PATH 配置

OpenCLI 通常安装在 `~/.npm-global/bin/`，不在默认 PATH 中。
每次使用前需要：

```bash
export PATH="$HOME/.npm-global/bin:$PATH"
```

建议添加到 `~/.bashrc` 或 `~/.zshrc`。

## 核心功能速查

### 164 个站点查询（public 模式无需登录）

| 类别 | 示例命令 |
|:----|:---------|
| AI/科技 | `opencli hackernews top -f json` |
| 热点 | `opencli 36kr hot -f json` |
| 论文 | `opencli arxiv search "RLHF" --limit 10 -f json` |
| 行情 | `opencli xueqiu stock <code> -f json` |
| 天气 | `opencli wttr current "Beijing" -f json` |

### cookie 模式（需登录的站点）

需要 Chrome + 扩展已连接 + 对应站点已登录：

| 站点 | 命令 |
|:----|:-----|
| 知乎 | `opencli zhihu hot -f json` |
| 微博 | `opencli weibo hot -f json` |
| B站 | `opencli bilibili hot -f json` |
| 小红书 | `opencli xiaohongshu search "关键词" -f json` |
| 抖音 | `opencli douyin hot -f json` |

### 三源融合企业尽调

当用户说「查一下XX公司」时，自动执行 16 维度尽调：

```
Step 1: 天眼查 → 工商/股东/诉讼/风险
Step 2: 企业预警通 → 行政处罚详情/近6月风险统计
Step 3: 企查查 → 交叉验证关键数据
Step 4: 自动深度展开 → 开庭公告/处罚详情/风险评价
```

### 浏览器驱动模式（无适配器的网站）

```bash
opencli browser <session-name> open "https://example.com" --window background
opencli browser <session-name> type <index> "搜索关键词"
opencli browser <session-name> click <index>
opencli browser <session-name> eval "document.body.innerText"
```

## 注意事项

- ⚠️ **Chrome 双实例问题**：`opencli browser` 默认启动独立 Chrome，不共享登录态。解决方案见 `references/chrome-dual-instance-root-cause.md`
- ⚠️ **永远不要 `pkill -9` 杀 Chrome**——用 `osascript -e 'quit app "Google Chrome"'` 正常退出
- ⚠️ **元素索引 [N] 不稳定**——每次加载后先用 `state` 确认当前索引，或 fallback 到 `eval` CSS 选择器
- ⚠️ **扩展断连恢复**——4 步流程：chrome://extensions → Cmd+R → opencli daemon restart → opencli doctor
- ⚠️ **cookie 命令超时**——terminal 超时建议 30-60s（首次可能较慢）
- ⚠️ **企业预警通搜索结果默认在「证券」tab**——需检查「全部」tab 获取企业结果