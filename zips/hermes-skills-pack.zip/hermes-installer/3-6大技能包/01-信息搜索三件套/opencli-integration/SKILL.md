---
name: opencli-integration
description: "三源融合尽调：天眼查(工商/股东/诉讼/IP) + 企业预警通(行政处罚/风险统计) + 企查查(交叉验证，需登录)。OpenCLI 1275 CLI命令覆盖164个网站+10桌面应用。知乎/微博/小红书/B站搜索、arXiv论文、HackerNews科技资讯、SearXNG搜索兜底"
tags:
  - company-query
  - equity-research
  - due-diligence
  - tianyancha
  - qichacha
  - enterprise-warning
  - business-info
  - web-scraping
  - browser-automation
  - search-fallback
version: 1.11.0
author: Hermes Agent
metadata:
  opencli:
    version: ">=1.7.22"
    path: "/Users/jinzhanxiang/.npm-global/bin/opencli"
    commands: 1275
    sites: 164
    apps: 10
    external_clis: 13
---

# OpenCLI 集成 Skill

## 概述

OpenCLI 提供 CLI 命令来查询 164 个网站的结构化数据（JSON 输出），复用 Chrome 登录态，无需手动解析 HTML。

**安装验证：**
```bash
export PATH="$HOME/.npm-global/bin:$PATH"
opencli --version   # → 1.8.6
opencli doctor      # 检查环境
```

**⚠️ PATH 注意：** npm global bin (`~/.npm-global/bin`) 不在默认 PATH 中。使用前必须：
```bash
export PATH="$HOME/.npm-global/bin:$PATH"
```

---

## 三种适配器模式

| 模式 | 适用场景 | 是否需要浏览器 | 示例 |
|------|---------|--------------|------|
| **public** | 公开 API 站点（无登录要求） | ❌ | `opencli hackernews top -f json` |
| **cookie** | 需要登录的站点（复用浏览器登录态） | ✅ 需 Chrome + opencli 扩展 | `opencli weibo hot -f json` |
| **ui** | 桌面应用 CDP 控制 | ✅ 需桌面应用运行 | `opencli cursor ask "..."` |

**Chrome 扩展设置（用于 cookie 模式）：**

Daemon 已自动运行在端口 19825，只需安装 Chrome 扩展即可连接：

**方法 A — Chrome 应用商店（推荐）：**
打开 https://chromewebstore.google.com/detail/opencli/ildkmabpimmkaediidaifkhjpohdnifk 点击「添加至 Chrome」

**方法 B — 手动加载：**
1. 从 GitHub Releases 下载 `opencli-extension-v{version}.zip`：https://github.com/jackwener/opencli/releases
2. 解压后，打开 `chrome://extensions`，开启「开发者模式」
3. 点击「加载已解压的扩展程序」→ 选择解压的文件夹

**验证连接：**
```bash
export PATH="$HOME/.npm-global/bin:$PATH"
opencli doctor    # 应显示 Extension: connected，Daemon: running
opencli daemon status  # 查看 daemon 运行状态
```

---

## 常用命令速查

### 中文平台

| 站点 | 常用命令 | 模式 |
|------|---------|------|
| **微博** | `opencli weibo hot -f json`（热搜榜）<br>`opencli weibo search "关键词" -f json` | cookie |
| **知乎** | `opencli zhihu hot -f json`（热榜）<br>`opencli zhihu search "关键词" -f json` | cookie |
| **B站** | `opencli bilibili hot -f json`（热门）<br>`opencli bilibili search "关键词" -f json`<br>`opencli bilibili video <bvid> -f json`（视频元数据） | cookie |
| **小红书** | `opencli xiaohongshu search "关键词" -f json`<br>`opencli xiaohongshu note <note_id> -f json`<br>`opencli rednote feed -f json`（首页推荐） | cookie |
| **抖音** | `opencli douyin hot -f json`（热搜）<br>`opencli douyin search "关键词" -f json` | cookie |
| **今日头条** | `opencli toutiao hot -f json`（热榜） | public |
| **36氪** | `opencli 36kr hot -f json`（热榜）<br>`opencli 36kr news -f json`（最新） | public |
| **虎扑** | `opencli hupu hot -f json` | cookie |
| **豆瓣** | `opencli douban hot -f json`<br>`opencli douban search "关键词" -f json` | cookie |
| **什么值得买** | `opencli smzdm search "关键词" -f json` | cookie |
| **东方财富** | `opencli eastmoney news -f json`（快讯） | cookie |
| **雪球** | `opencli xueqiu hot-stock -f json`（热门股票）<br>`opencli xueqiu stock <code> -f json`（实时行情） | cookie |
| **同花顺** | `opencli ths hot-rank -f json`（热股榜） | cookie |
| **京东** | `opencli jd search "关键词" -f json` | cookie |
| **淘宝** | `opencli taobao search "关键词" -f json`<br>`opencli taobao detail <id> -f json` | cookie |
| **闲鱼** | `opencli xianyu search "关键词" -f json` | cookie |
| **一亩三分地** | `opencli 1point3acres hot -f json`（热门）<br>`opencli 1point3acres digest -f json`（精华） | public |
| **V2EX** | `opencli v2ex hot -f json`<br>`opencli v2ex latest -f json` | public |
| **即刻** | `opencli jike hot -f json` | cookie |
| **微信** | `opencli weixin search "关键词" -f json`（搜狗搜微信文章）<br>`opencli weixin download <url>`（导出文章为 Markdown） | public / cookie |
| **微信公众号** | `opencli weixin create-draft -f json`（创建草稿）<br>`opencli weixin drafts -f json`（草稿列表） | cookie |

### 国际平台

| 站点 | 常用命令 | 模式 |
|------|---------|------|
| **HackerNews** | `opencli hackernews top --limit 10 -f json` | public |
| **arXiv** | `opencli arxiv search "RLHF" --limit 10 -f json`<br>`opencli arxiv recent cs.LG --limit 30 -f json` | public |
| **Reddit** | `opencli reddit hot -f json`<br>`opencli reddit search "关键词" -f json`<br>`opencli reddit subreddit <name> -f json` | cookie |
| **Twitter/X** | `opencli twitter trending -f json`（趋势）<br>`opencli twitter search "关键词" -f json`<br>`opencli twitter timeline --type following -f json`（关注时间线） | cookie |
| **ProductHunt** | `opencli producthunt today --limit 10 -f json` | public |
| **GitHub** | `opencli github trending -f json`（趋势）<br>`opencli github search repos "关键词" -f json`<br>`opencli github-trending -f json` | public |
| **YouTube** | `opencli youtube search "关键词" -f json`<br>`opencli youtube video <id> -f json` | cookie |
| **PubMed** | `opencli pubmed search "关键词" --limit 10 -f json` | public |
| **Semantic Scholar** | `opencli semanticscholar search "论文标题" -f json`<br>`opencli semanticscholar citations <paperId> -f json` | public |
| **HuggingFace** | `opencli hf top --period daily --limit 20 -f json` | public |
| **OpenReview** | `opencli openreview venue "NeurIPS 2025 oral" --limit 50 -f json` | public |
| **Stack Overflow** | `opencli stackoverflow hot -f json`<br>`opencli stackoverflow search "关键词" -f json` | public |
| **Binance 行情** | `opencli binance top -f json`（24h 成交额排行）<br>`opencli binance price BTCUSDT -f json` | public |
| **CoinGecko** | `opencli coingecko top -f json`（市值排行）<br>`opencli coingecko trending -f json` | public |
| **天气** | `opencli wttr current "Beijing" -f json` | public |
| **Wikipedia** | `opencli wikipedia summary "AI" -f json` | public |

### 开发者工具

| 命令 | 用途 |
|------|------|
| `opencli npm search <包名> -f json` | NPM 包搜索 |
| `opencli pypi search <包名> -f json` | PyPI 包搜索 |
| `opencli crates search <包名> -f json` | Crates.io (Rust) 包搜索 |
| `opencli dockerhub search <镜像名> -f json` | Docker Hub 镜像搜索 |
| `opencli homebrew search <包名> -f json` | Homebrew 包搜索 |
| `opencli rfc <编号> -f json` | IETF RFC 查询 |

### 金融/财经

| 命令 | 用途 |
|------|------|
| `opencli sinafinance news -f json` | 新浪财经 7x24 实时快讯 |
| `opencli sinafinance stock <code> -f json` | A股/港股/美股行情 |
| `opencli xueqiu stock <code> -f json` | 雪球实时行情 |
| `opencli barchart quote <symbol> -f json` | Barchart 美股行情 |
| `opencli barchart options <symbol> -f json` | Barchart 期权链 |
| `opencli yahoo-finance quote <symbol> -f json` | Yahoo Finance 行情 |
| `opencli reuters search "关键词" -f json` | 路透社新闻搜索 |

### 生活服务

| 命令 | 用途 |
|------|------|
| `opencli 12306 trains <from> <to> <date> -f json` | 12306 火车查询 |
| `opencli 12306 price <train> -f json` | 12306 票价 |
| `opencli ctrip search "目的地" --dates ... -f json` | 携程搜索 |
| `opencli booking search "城市" --dates ... -f json` | Booking 酒店搜索 |
| `opencli boss search "职位" -f json` | BOSS 直聘搜索 |

---

## 桌面应用控制

OpenCLI 可以通过 CDP 控制以下桌面应用（需要应用正在运行）：

| 应用 | 常用命令 |
|------|---------|
| **Cursor** | `opencli cursor ask "提示语"` — 向 Cursor 发送提示并等待回复<br>`opencli cursor read -f json` — 读取当前对话<br>`opencli cursor model` — 查看/切换模型 |
| **Codex** | `opencli codex ask "提示语"`<br>`opencli codex history -f json`<br>`opencli codex model` |
| **ChatGPT Desktop** | `opencli chatgpt-app ask "提示语"`<br>`opencli chatgpt-app model` |
| **Claude** | `opencli claude ask "提示语"`<br>`opencli claude read -f json` |
| **豆包桌面版** | `opencli doubao-app ask "提示语"` |
| **Discord** | `opencli discord-app read -f json`<br>`opencli discord-app send "消息"` |
| **Trae CN** | `opencli trae-cn ask "提示语"`<br>`opencli trae-cn approve`（审批权限弹窗） |

---

## 高级用法

### 批量信息聚合（管道模式）

```bash
# 一天的信息信号面
opencli arxiv recent cs.LG --limit 30 -f json > lg.json
opencli arxiv recent cs.AI --limit 30 -f json > ai.json
opencli openreview venue "NeurIPS 2025 oral" --limit 50 -f json > neurips.json
opencli hf top --period daily --limit 20 -f json > hf.json

# 压缩给 LLM 做 digest
# Hermes: 读取这些 JSON 文件，做摘要
```

### JSON 输出 + jq 过滤

```bash
# 只取标题和分数
opencli hackernews top --limit 10 -f json | jq '.[] | {title, score, url}'

# 过滤包含特定关键词的论文
opencli arxiv search "LLM agent" --limit 50 -f json | jq '.[] | select(.title | test("reasoning|planning"; "i")) | {title, id}'
```

### 不同输出格式

```bash
opencli <site> <command> -f json      # JSON 结构化输出（推荐给 Agent 使用）
opencli <site> <command> -f table     # 表格输出（人类友好）
opencli <site> <command>              # 默认文本输出
```

---

## Hermes 中的使用模式

在 Hermes 中，通过 `terminal` 工具调用 OpenCLI：

### 模式 A：直接查询 + 返回 JSON

```
用户：今天 HackerNews 有什么热门？
Agent 调用：
  terminal(command="export PATH=$HOME/.npm-global/bin:$PATH && opencli hackernews top --limit 5 -f json", timeout=15)
  → 得到 JSON，解析后回复用户
```

### 模式 B：查询后进一步分析

```
用户：帮我看看 arXiv 上关于 RLHF 的最近论文
Agent 调用：
  terminal(command="export PATH=$HOME/.npm-global/bin:$PATH && opencli arxiv search \"RLHF\" --limit 10 -f json", timeout=15)
  → 得到论文列表，选一篇感兴趣的读取详情
  terminal(command="export PATH=$HOME/.npm-global/bin:$PATH && opencli arxiv paper <id> -f json", timeout=15)
  → 读取详细信息
```

### 模式 C：跨平台信息聚合

```
用户：今天AI圈有什么大事？
Agent 调用（并行）：
  1. opencli hackernews top --limit 5 -f json
  2. opencli producthunt today --limit 5 -f json
  3. opencli arxiv recent cs.AI --limit 10 -f json
  4. opencli 36kr hot -f json
  → 合并分析，输出综合日报
```

### 模式 D：深入了解话题内容

```
用户：看看知乎热榜第一个话题
Agent 调用：
  terminal(command="export PATH=$HOME/.npm-global/bin:$PATH && opencli zhihu question <id> --limit 5 --sort default -f json", timeout=60)
  → 得到问题详情 + 高赞回答内容（含 content 字段）
```

### 预检流程（cookie 模式）

对于需要登录态的站点（cookie 模式），Hermes 应**主动**确保 Chrome 就绪，而非等失败后才处理：

```bash
# 1. 先确认 daemon 运行 + 扩展连接
opencli doctor

# 2. Daemon 离线 → 启动 daemon
opencli daemon start

# 3. 扩展未连接 → 检测 Chrome 是否运行
pgrep -i "Google Chrome" > /dev/null

# 4. Chrome 未运行 → 自动打开
open -a "Google Chrome"
sleep 5

# 5. 重启 daemon
opencli daemon restart
sleep 2

# 6. 再次确认
opencli doctor

# 7. **扩展仍断连 → 用 4 步恢复流程（2026-07-15 已验证）**\nosascript -e 'tell application "Google Chrome" to open location "chrome://extensions"'\nsleep 4\nosascript -e 'tell application "System Events" to tell process "Google Chrome" to keystroke "r" using command down'\nsleep 2\nopencli daemon restart\nsleep 3\nopencli doctor
sleep 2
opencli doctor

# 8. **仍不行 → 彻底重启 Chrome + daemon**
osascript -e 'quit app "Google Chrome"'
sleep 2
open -a "Google Chrome"
sleep 5
opencli daemon restart
sleep 3
opencli doctor
```

### ⚠️ 关键规则：永远不要 force-kill Chrome

```bash
# ✅ 正确：正常退出
osascript -e 'quit app "Google Chrome"'

# ❌ 错误：pkill -9 会丢失扩展注册
pkill -9 -f "Google Chrome"    # 不要这样做！SIGKILL 损坏 Preferences 文件
```

### 扩展断连恢复检查表

| 症状 | 操作 | 预期结果 |
|------|------|---------|
| **Chrome 打开但扩展断连** | `opencli daemon restart` → `opencli doctor` | 扩展重连 |
| **daemon 已重启仍断连** | **4 步恢复（2026-07-15 已验证）**：<br>① `osascript` 打开 `chrome://extensions`<br>② `System Events` 发送 `Cmd+R` 刷新扩展<br>③ `opencli daemon restart`<br>④ `opencli doctor` 验证 | 扩展重连 ✅ |
| **Chrome 被 pkill -9 杀过** | 用户需重新在 `chrome://extensions` 加载扩展文件夹（`~/Downloads/opencli-extension-v1/`） | 扩展注册已丢失，必须重加载 |
| **Chrome 正常重启后扩展未连** | 用 4 步恢复流程 | 自动唤醒 |
| **扩展重连后 cookie 命令仍 AUTH_REQUIRED** | 让用户登录对应站点 | 登录态过期 |

### ⚠️ 被墙环境下的扩展管理

**Chrome Web Store 和 GitHub 均被墙，无法在线安装/下载扩展。** 解决方案：

1. **避免问题发生** — 永远用 `osascript -e 'quit app "Google Chrome"'` 正常退出 Chrome，不用 `pkill -9`（已写入永久记忆）
2. **自动恢复** — 扩展断连时，执行 4 步恢复流程唤醒刷新扩展
3. **本地备份** — 扩展 ZIP 文件已本地解压至 `~/Downloads/opencli-extension-v1/`，内含 manifest.json + dist/ + icons/
4. **手动重加载（仅最坏情况）** — 如果扩展注册完全丢失，在 chrome://extensions → 开启开发者模式 → 「加载已解压的扩展程序」→ 选择 `~/Downloads/opencli-extension-v1/`

### 命令发现模式

不确定某个站点的命令用法时，先查帮助：

```bash
opencli <site> --help                    # 查看所有子命令
opencli <site> <command> --help          # 查看子命令参数
opencli <site> --help -f yaml            # 结构化输出（Agent 友好）
```

---

## 浏览器驱动模式（无适配器的网站）

当目标站点没有 OpenCLI 内置适配器时，用 `opencli browser` 命令手动驱动 Chrome 操作。

### 通用工作流

```bash
# 1. 打开站点首页（--window background 不干扰用户）
opencli browser <session-name> open "https://example.com" --window background

# 2. 获取页面状态，找到交互元素
opencli browser <session-name> state
# → 返回 URL、标题、交互元素 [N] 索引

# 3. 在搜索框输入关键词
opencli browser <session-name> type <element-index> "关键词"

# 4. 点击搜索/提交按钮
opencli browser <session-name> click <button-index>

# 5. 等待页面加载后检查状态
sleep 3
opencli browser <session-name> state

# 6. 提取页面结构化数据（eval JS 最可靠）
opencli browser <session-name> eval "document.querySelector('table')?.innerText"

# 7. scroll 查看更多内容
opencli browser <session-name> scroll down
```

### eval 数据提取技巧

```bash
# 提取特定表格
opencli browser <session> eval "document.querySelector('table')?.innerText"

# 提取所有可见文本
opencli browser <session> eval "document.body.innerText"

# 提取特定元素的属性（如链接）
opencli browser <session> eval "document.querySelector('a[href*=\"firm/\"]')?.href"

# 过滤包含关键词的表格
opencli browser <session> eval \
  "let tables=document.querySelectorAll('table'); \
   let r=[]; for(let t of tables){if(t.innerText.includes('持股比例'))r.push(t.innerText)}; r.join('\\n---\\n')"
```

### 注意
- `open` 后等待 2-3 秒让页面完全渲染
- `state` 返回的 [N] 索引对 `click`/`type` 命令是最可靠的
- `eval` JS 比 `extract` 更可靠，能拿到结构化表格数据
- cookie 模式的 browser 命令需要 Chrome 打开 + 扩展已连接
- 某些站点（如企查查）有 WAF 防护，不能用直接搜索 URL 方式打开

### bind 命令：绑定到现有标签页

`bind` 命令可以让 OpenCLI 浏览器 session 接管用户当前活动标签页，而不是打开新标签页：

```bash
# 1. 用户在 Chrome 中打开目标页面并登录
# 2. 确保该标签页是活动标签页
# 3. 绑定
opencli browser <session-name> bind

# 4. 绑定后，该 session 操作的是用户刚才打开的标签页
opencli browser <session-name> state
opencli browser <session-name> eval "document.title"
opencli browser <session-name> extract

# 5. 解绑（不关闭标签页）
opencli browser <session-name> unbind
```

**使用场景：**
- 用户已登录某站点（如企业预警通），但 OpenCLI 的 Chrome 没有登录态
- 某些站点需要复杂的验证码/滑块，用户手动完成验证后绑定
- 只需要读取页面数据，不需要 OpenCLI 自动导航

**注意：** `bind` 绑定的是**OpenCLI 扩展当前连接的 Chrome 实例**。如果 OpenCLI 启动的是独立 Chrome（见「Chrome 双实例与登录态隔离」），`bind` 绑定的是那个独立 Chrome，而非用户的主 Chrome。

---

## 企查查（qichacha.com）操作专项

企查查有 **WAF 防护 + 全站强制登录**。与天眼查不同（免登录可查基础信息），企查查**任何页面都需登录**，未登录直接跳转微信登录页。

### 前置条件：登录态确认

企查查的登录态与 Chrome 实例绑定（参见「Chrome 双实例与登录态隔离」）。

**⚠️ 登录检测逻辑：不要用 `includes('退出')` 做检测。** `includes('退出')` 在实际已登录状态下可能返回 false，造成误判为"未登录"。

```bash
# ✅ 正确的登录检测方式：检查无"登录"链接 + 有"消息"即已登录
opencli browser qcc open "https://www.qcc.com/" --window background
sleep 3
opencli browser qcc eval "
var txtQcc = document.body.innerText.substring(0, 500);
var hasLogin = txtQcc.includes('登录');
var hasMsg = txtQcc.includes('消息');
if(!hasLogin && hasMsg) '已登录✅';
else if(hasLogin) '未登录❌（显示登录按钮）';
else '不确定，需要进一步检查';
"

# ❌ 错误的检测方式（会误判）
# document.body.innerText.includes('退出') ? '已登录' : '未登录'
```

### 方案A（推荐）：主Chrome带远程调试（全自动，一次配置永久生效）

**用户明确要求全自动流程，bind依赖用户切换标签页不是可接受的方案。方案A是默认路径。**

```bash
# 1. 退出 Chrome
osascript -e 'quit app "Google Chrome"'
sleep 2

# 2. 启动主Chrome带远程调试 + 加载OpenCLI扩展
nohup /Applications/Google\\ Chrome.app/Contents/MacOS/Google\\ Chrome \\
  --remote-debugging-port=18800 \\
  --load-extension="$HOME/Downloads/opencli-extension-v1" \\
  > /dev/null 2>&1 &

sleep 5
opencli daemon restart
sleep 3
opencli doctor

# 3. 之后直接搜索（共享主Chrome的登录态）
opencli browser qcc open "https://www.qcc.com/" --window background
sleep 3

# 4. 搜索
opencli browser qcc state  # 找到搜索框索引
opencli browser qcc type <search-index> "公司名"
opencli browser qcc click <search-button-index>
sleep 4

# 5. 取详情页
opencli browser qcc eval "document.querySelector('a[href*=\"/firm/\"]')?.href"
opencli browser qcc open "<详情URL>" --window background
sleep 4

# 6. 提取数据
opencli browser qcc extract
```

### 方案B：eval搜索（兜底，当索引[N]不可用时）

当 `type`/`click` 因为索引变化而失败时，用 eval 方式搜索：

```bash
opencli browser qcc eval "
var inp = document.querySelector('input');
if(inp) {
  var ns = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  ns.call(inp, '公司名');
  inp.dispatchEvent(new Event('input', {bubbles: true}));
  var btns = document.querySelectorAll('button');
  for(var b=0; b<btns.length; b++) {
    if(btns[b].textContent.includes('查一下')) { btns[b].click(); break; }
  }
  '已搜索';
}
"
sleep 5
opencli browser qcc eval "window.location.href"
```

### 查看股权架构

```bash
# 提取股东持股表格（eval JS 最可靠）
opencli browser qcc eval \
  "let tables=document.querySelectorAll('table'); \
   let r=[]; for(let t of tables){if(t.innerText.includes('持股比例'))r.push(t.innerText)}; r.join('\\n---\\n')"

# 提取高管信息表
opencli browser qcc eval \
  "let tables=document.querySelectorAll('table'); \
   let r=[]; for(let t of tables){if(t.innerText.includes('职务'))r.push(t.innerText)}; r.join('\\n---\\n')"

# 提取公司基础信息表（统一社会信用代码、法人、注册资本等）
opencli browser qcc eval "document.querySelector('table')?.innerText"
```

### 股权架构数据解读模板

企查查股东信息包含的字段：

| 字段 | 说明 |
|------|------|
| 股东名称 | 法人股东/自然人股东 |
| 持股比例 | 百分比 |
| 认缴出资额 | 注册资本认缴金额（万元） |
| 认缴/实缴日期 | 出资时间线 |
| 性质 | 央企/国企/私募/个人/上市公司 |
| 间接持股比例 | 通过其他公司间接持股 |
| 首次持股日期 | 最早成为股东的时间 |
| 关联产品/机构 | 投资方品牌标识 |

**分析要点：**
- 国有资本合计比例（央企 + 国企股东）
- 管理团队持股（自然人 + 员工持股平台）
- 外部投资方结构（私募基金、上市公司、产业资本）
- 子公司布局（存续/注销状态）
- 历史融资轮次（如 A+ 轮）

### 注意

1. **WAF 绕过**：不要直接搜索 URL，必须通过首页搜索框交互
2. **登录限制**：股权穿透图、受益所有人等可能需要 VIP 会员
3. **搜索速度**：cookie 模式首次约 5-15s
4. **数据提取**：`eval` JS 比 `extract` 更可靠
5. **浏览器 session**：session 保持打开状态，多次调用共用同一个标签页

---

## 企查查 vs 天眼查 vs 企业预警通：非上市公司信息查询方案

**实测结果（2026-07-12，中复碳芯电缆科技有限公司）：**

### 三家对比

| 维度 | 企查查(qcc.com) | 天眼查(tyc.com) | 企业预警通(qyyjt.cn) |
|------|---------------|---------------|-------------------|
| **搜索同一公司** | ⚠️ 需登录 | ✅ 13条结果 | ✅ 可搜到（已验证中复碳芯） |
| **基础工商信息** | ✅ 完整（法人、注册资本、经营范围等） | ✅ 完整（+天眼评分86分） | ✅ 完整（科创分86.34/信用分800/营收14.51亿） |
| **股东信息（8名股东）** | ✅ 持股比例+日期 | ✅ **持股比例+认缴出资金额(万元)** | ✅ 持股比例+认缴金额+法人+成立日期 |
| **历史股东** | ❌ 未显示 | ✅ **有历史股东信息** | — |
| **对外投资** | ⚠️ 需手动查找 | ✅ **完整对外投资列表（含持股比例）** | — |
| **认缴/实缴金额** | ❌ 未显示具体金额 | ✅ **每项股东都有具体数字** | — |
| **股权穿透图** | ✅ 图表可看（实控人需SVIP） | ✅ 类似 | — |
| **高管信息** | ✅ 完整 | ✅ 完整（+个人简介链接） | — |
| **页面加载速度** | ⭐⭐⭐⭐ 传统HTML，快 | ⭐⭐⭐ React SPA，略慢 | ⭐⭐ 完全登录态 |
| **操作流畅度** | ⭐⭐⭐⭐ 直接交互 | ⭐⭐⭐ 需等待渲染 | ⭐⭐ |
| **风险监控** | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ 核心功能 |
| **金融数据(债券/城投)** | ⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐⭐ |
| **数据特色** | 操作流畅，数据够用 | **金额字段最详细**，有历史信息 | 风险预警+金融数据 |

### 适用场景

| 平台 | 最适合 | 不适合 |
|------|-------|-------|
| **天眼查** | 一次性深度查询（股东金额、历史信息、对外投资） | 需要快速反复查询 |
| **企查查** | 快速查询基础信息、股权结构概览 | 需要具体出资额、历史股东 |
| **企业预警通** | 持续监控风险变化、债券违约/城投数据 | 查工商信息、非上市公司 |

### 非上市公司查询首选方案

```
查非上市公司工商信息
  ↓
天眼查（首选）── 股东金额最详细，有历史信息
  ↓ 数据不够/需交叉验证
企查查（备选）── 操作快，数据互补
  ↓ 需持续监控风险
企业预警通（专项）── 风险预警、债券监控
```

### 天眼查操作流程

天眼查是 React SPA，需要先打开首页，通过搜索框交互：

```bash
# 第1步：打开首页
opencli browser tyc open "https://www.tianyancha.com/" --window background
sleep 5

# 第2步：找到搜索框（placeholder 通常含"请输入公司名称"）
opencli browser tyc state
# 搜索框索引 [N] 通常在页面顶部

# 第3步：输入公司名
opencli browser tyc type <search-index> "公司名"

# 第4步：点击"天眼一下"按钮
opencli browser tyc click <search-button-index>
sleep 5

# 第5步：检查是否跳转到搜索结果页
opencli browser tyc eval "document.title + ' | ' + window.location.href"

# 第6步：获取搜索结果中的公司链接
opencli browser tyc eval \
  "let links = document.querySelectorAll('a[href*=\"/company/\"]'); \
   let r = []; for(let l of links) { if(l.innerText.includes('公司简称')) r.push(l.href); } r.join('\\n')"

# 第7步：打开公司详情页
opencli browser tyc open "<公司URL>" --window background
sleep 8

# 第8步：提取基础信息表
opencli browser tyc eval "document.querySelector('table')?.innerText"

# 第9步：提取股东信息表（含持股比例+认缴金额）
opencli browser tyc eval \
  "let tables = document.querySelectorAll('table'); \
   let r = []; for(let t of tables) { if(t.innerText.includes('持股比例')) r.push(t.innerText); } \
   r.join('\\n---\\n')"

# 第10步：提取高管信息
opencli browser tyc eval \
  "let tables = document.querySelectorAll('table'); \
   let r = []; for(let t of tables) { if(t.innerText.includes('职务')) r.push(t.innerText); } \
   r.join('\\n---\\n')"

# 第11步：提取对外投资信息
opencli browser tyc eval \
  "let tables = document.querySelectorAll('table'); \
   let r = []; for(let t of tables) { if(t.innerText.includes('被投资企业')) r.push(t.innerText); } \
   r.join('\\n---\\n')"
```

### 天眼查风险信息提取

天眼查公司详情页包含完整的风险信息，通过 `eval "document.body.innerText"` 提取全页文本后解析。

**风险信息结构（天眼查页面）：**

```
自身风险: N     # 当前风险条目总数
周边风险: N     # 关联企业的风险
历史风险: N     # 已消除的历史风险
预警提醒: N     # 监控预警

法律诉讼（活性）：
├── 司法案件 N    # 总案件数
├── 开庭公告 N    # 活跃进行中的开庭
├── 裁判文书 N    # 已有判决文书
├── 限制消费令 N  # 0 = 安全
├── 失信被执行人 N # 0 = 安全
├── 被执行人 N    # 0 = 安全
├── 股权冻结 N    # 0 = 安全
├── 立案信息 N
├── 破产案件 N    # 0 = 安全

经营风险（活性）：
├── 行政处罚 N    # 0 = 安全
├── 环保处罚 N    # 非零说明有合规问题
├── 经营异常 N    # 0 = 安全
├── 欠税公告 N    # 0 = 安全
├── 严重违法 N    # 0 = 安全

历史风险：
├── 历史股权冻结 N
├── 历史经营异常 N
├── 历史行政处罚 N
├── 历史被执行人 N
├── 历史限制消费令 N
└── 历史失信被执行人 N
```

**提取命令：**

```bash
# 全量文本提取（推荐用于分析）
opencli browser tyc eval "document.body.innerText.substring(0, 8000)"

# 聚焦风险相关行
opencli browser tyc eval "document.querySelector('[class*=risk]')?.innerText"

# 获取最新动态（如最近的开庭/招投标）
opencli browser tyc eval \
  "[...document.querySelectorAll('[class*=dynamic]')].map(e=>e.innerText).join('\n')"
```

**风险分析要点：**

| 信号 | 严重程度 | 说明 |
|------|---------|------|
| 被执行人 > 0 | 🔴 高 | 法院强制执行 |
| 失信被执行人 > 0 | 🔴 高 | 被列入失信名单 |
| 限制消费令 > 0 | 🟡 中 | 法人被限高消费 |
| 开庭公告 > 10 | 🟡 中 | 大量诉讼，经营不稳定 |
| 案由含"损害公司债权人利益" | 🔴 高 | 债权人追索，偿债能力问题 |
| 股权冻结（历史）> 0 | 🟡 中 | 历史上股权被冻结过 |
| 行政处罚（历史）> 0 | 🟢 低 | 历史合规问题，已消除 |
| 环保处罚 > 0 | 🟡 中 | 环保合规风险 |

**最近动态监控：** 从页面文本中搜索 `2026-06`、`2026-05` 等日期前缀，可提取最近 1-2 个月的动态事件（新增开庭、招投标、新闻等）。

### 企业预警通操作流程（已验证可行 - 2026-07-12 实测）

企业预警通（qyyjt.cn）是 **React SPA**，**全站需要登录态**（任何页面都不可免登录访问）。经过实测（2026-07-12），已有可行方案。

#### 登录方式

企业预警通的登录方式是**企业预警通 APP 扫码登录**（不是微信扫码），无需手机号/验证码：

1. 打开浏览器到 `qyyjt.cn/user/login`
2. 页面上显示 Canvas 二维码 + 提示："打开 企业预警通 APP，在【我的-扫一扫】扫描二维码登录"
3. 用户用手机上的企业预警通 APP 扫描二维码即可登录

**推荐方案：Chrome CDP + 临时 profile（无需关闭已有的 Chrome）**

```bash
# 1. 创建临时 profile
mkdir -p /tmp/chrome-debug-profile-qyyjt

# 2. 启动 Chrome 调试实例
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --remote-debugging-port=9222 \
  --user-data-dir="/tmp/chrome-debug-profile-qyyjt" \
  --no-first-run --no-default-browser-check &

# 3. 等待启动后，通过 CDP 导航到登录页
sleep 5
curl -s -X PUT "http://localhost:9222/json/new?https://www.qyyjt.cn"

# 4. 通过 CDP 将窗口移到可见区域
python3 -c "
import requests, json, asyncio, websockets
async def move():
    targets = requests.get('http://localhost:9222/json').json()
    page = [t for t in targets if t['type']=='page'][0]
    async with websockets.connect(page['webSocketDebuggerUrl']) as ws:
        await ws.send(json.dumps({'id':1, 'method':'Browser.getWindowForTarget'}))
        r = json.loads(await ws.recv())
        wid = r['result']['windowId']
        await ws.send(json.dumps({'id':2, 'method':'Browser.setWindowBounds', 'params':{
            'windowId': wid, 'bounds': {'left':100, 'top':100, 'width':1200, 'height':900}
        }}))
asyncio.run(move())
"

# 5. 用户扫描二维码登录后，提取 cookies 并保存为 agent-browser restore
# 参见 browser-automation skill 的「方式 C：Chrome CDP + cookie 注入」
```

**注意：** 此方法是新开独立 Chrome 实例，不影响用户已有的 Chrome 窗口和标签页。用户扫码登录后 session 自动保存在该临时 profile 中。

#### ✅ 核心发现：搜索按钮点击 → 结果列表 → 详情页URL 流程可行

| 操作 | 结果 | 方法 |
|------|:----:|------|
| 打开页面并保持登录态 | ✅ 可行 | Cookie 持久化 |
| 搜索框输入关键词+**点击搜索按钮** | ✅ 可行 | 点击 `[92]` 按钮而非回车 |
| 搜索结果页面 | ✅ 可行 | URL变为 `/s?tab=securities&k=关键词` |
| 公司详情页URL获取 | ✅ 可行 | 搜索结果含 `<a href=/detail/enterprise/overview?code=...>` |
| **直接导航到公司详情页** | **✅ 可行** | 用完整URL导航 |
| 提取全量页面数据 | ✅ 可行 | `extract` 命令 |
| 导航风险模块（监管处罚等） | ✅ 可行 | 点击侧边菜单元素 |

#### ✅ 三步核心流程

**Step 1：搜索公司 → 获取公司CODE**

```bash
# 打开首页
opencli browser yujing open "https://www.qyyjt.cn/" --window background
sleep 3

# 在页面顶部的搜索框[97]（注意不是[90]）输入关键词
opencli browser yujing state
# 找到 <input placeholder="企业/证券/功能/集团户/区域/关键字"> 的 [N] 索引

# 输入 + 点击搜索按钮
opencli browser yujing click 100   # 点击搜索按钮旁边的图标触发搜索
# 或使用类型+回车
opencli browser yujing type <search-input-index> "公司名"
opencli browser yujing click <search-button-index>   # 搜索按钮
sleep 3

# 🔴 关键：企业预警通搜索默认显示"证券"tab，企业结果在"全部"tab中
# 如果不切换tab可能误判为"未收录"！必须先用 eval 检查所有链接
opencli browser yujing eval "\
var anchors = document.querySelectorAll('a');\
var out = [];\
for(var i=0; i<anchors.length; i++) {\
  var txt = anchors[i].textContent.trim().substring(0, 40);\
  if(txt.length > 2) out.push({text: txt, href: (anchors[i].href || '').substring(0,120)});\
}\
JSON.stringify(out.slice(0,10), null, 2);\
"

# 如果 eval 结果中无企业链接，尝试切换到"全部"tab
# 检查页面是否有 tab 切换按钮
opencli browser yujing eval "\
var tabs = document.querySelectorAll('[class*=tab]');\
var out = [];\
for(var i=0; i<tabs.length; i++) {\
  out.push(tabs[i].textContent.trim().substring(0,20));\
}\
JSON.stringify(out);\
"

# 提取企业详情页URL（从所有链接中筛选 /detail/enterprise/overview）
opencli browser yujing eval \
  "document.querySelector('a[href*=\"/detail/enterprise/overview\"]')?.href"
# → 返回类似 /detail/enterprise/overview?code=2B11C87F0620B20C246D9C92A8DF73DB&type=company
```

**Step 2：导航到公司详情页 → 提取全量数据**

```bash
# 打开公司详情页
opencli browser yujing open "https://www.qyyjt.cn/detail/enterprise/overview?code=XXXX&type=company" --window background
sleep 4

# 方法A：extract 提取全量文本数据
opencli browser yujing extract
# → 返回完整的公司页面内容（基础信息、股东、负面舆情、新闻等）

# 方法B：eval 提取特定元素
opencli browser yujing eval "document.body.innerText.substring(0, 10000)"
```

**Step 3：探索风险子模块**

```bash
# 点击侧边菜单项导航到具体风险模块
# 关键菜单项索引（根据页面状态确定）：
# 监管处罚 → 点击 [228] 或对应菜单
# 企业经营 → 点击 [287]
# 财务数据 → 点击 [295]
# 司法诉讼 → 点击 [305]

# 点击后URL变为 /detail/enterprise/creditData?code=...#监管处罚
sleep 3
opencli browser yujing extract  # 提取对应模块的数据
```

#### 🔍 数据可获取内容（已验证）

**基本信息区：**
- 公司全称、状态（在营/注销）、法定代表人、注册资本、实缴资本、成立日期
- 统一社会信用代码、企业类型、行业、员工人数、企业规模
- 科创分（86.34↑）、信用分（800↑）、融资轮次（A+轮）
- 企业标签：央企二级子公司、专精特新"小巨人"、高新技术企业等
- 营业收入（14.51亿/2025年报）、经营范围
- 所属集团（中建材联合投资、中国建材集团）

**风险舆情区（近六个月统计）：**
| 指标 | 数值 | 说明 |
|------|:----:|------|
| 违约/展期 | 0 ✅ | 无违约 |
| 立案调查 | 0 ✅ | 无立案 |
| 主体评级 | 0 | 无主体评级 |
| 税务信用 | 1 | 税务记录1条 |
| 开庭公告 | 1 🟡 | 有开庭 |
| 法院公告 | 3 🟡 | 有法院公告 |
| 招投标公告 | 54 | 活跃 |
| 知识产权 | 5 | |
| 财务提示类 | 1 🟡 | 财务提示 |
| 公司经营 | 5 🟡 | 经营类风险 |
| 关联方风险 | 1 🟡 | 关联方风险 |
| 其他新闻 | 4 | |

**行政处罚模块**（导航到「监管处罚」后可获取）：
- 行政处罚 6 条（总计罚没金额 340.56 万元）
- 行政监管措施 1 条
- 金融监管数据
- 每项含：披露日期、处罚日期、处罚类型、违规原因、文号、处理机关、法律依据

**股东信息：**
- 8名股东（名称、持股比例、认缴金额、法定代表人、成立日期）
- 疑似实际控制人（国务院国有资产监督管理委员会）
- 对外投资企业 5 家

**司法诉讼模块**（导航可获取）：
- 司法案件 26 件
- 裁判文书 12 份
- 立案信息 6 条

#### 🎯 三种自动化方案的对比

| 方案 | 原理 | 是否可行 | 优点 | 缺点 |
|------|------|:--------:|------|------|
| **A: OpenCLI browser** | 驱动Chrome操作页面 | ✅ **最佳** | 复用登录态、操作直观、extract/eval灵活 | 需Chrome+扩展、比API慢 |
| **B: 浏览器eval调API** | 在浏览器上下文fetch API | ✅ 可行 | 更快（JSON直接返回） | 需先知道API路径、认证随会话 |
| **C: Playwright (Python)** | 独立启动Chrome/CDP | ✅ 已预装 v1.61.0 | 更精细控制 | 需额外安装chromium浏览器 |

**推荐方案：A（OpenCLI browser extract/eval）** — 最直接，无需额外配置。

#### 已验证的API端点（用于方案B）

```javascript
// 在浏览器上下文中调用（继承登录态）
const resp = await fetch('/finchinaAPP/v1/finchina-search/v1/devzSearch?text=中复碳芯');
const data = await resp.json();

// 搜索结果API
const resp2 = await fetch('/finchinaAPP/v1/finchina-search/v1/multipleSearch?pagesize=15&text=中复碳芯');
```

> **注意：** 搜索建议弹窗（autocomplete dropDown）的点击依赖React内部状态，不稳定。**可靠方案是通过搜索按钮导航到搜索结果页，再取详情页URL导航。**

### 注意事项

1. **天眼查 React SPA**：页面加载较慢，`open` 后等 5-8 秒，每次交互后等 3-5 秒
2. **天眼查搜索框选择**：天眼查首页有两个搜索框——顶部搜索框（[20]）和中间搜索框（[43]）。**优先用中间搜索框**（[43]），输入后点击中间"天眼一下"按钮（[47]）。顶部搜索框输入后可能不触发导航跳转（React 状态管理问题）
3. **企查查 WAF**：不要直接打开搜索 URL，必须通过首页搜索框交互
4. **企业预警通**：需要登录，核心是风险监控而非工商查询
5. **数据差异**：同一家公司的股东信息，天眼查更详细（有具体金额），可作为数据来源首选
6. **交叉验证**：重要查询建议两家都查，互相验证数据准确性
7. **浏览器 session**：每个平台用不同 session 名称（qcc、tyc、yujing），避免冲突
8. **必须实测验证**：不要推测平台能力（如"企业预警通能不能搜企业"），必须通过浏览器实际打开测试。只汇报真实测试结果，不提供基于推测的分析
9. **三源融合顺序**：天眼查（主数据源）→ 企业预警通（风险专项）→ 企查查（交叉验证，需登录）。详见 `references/three-source-fusion-workflow.md`

---

## 综合尽职调查自动化流程（16维度全量采集）

**前置条件：** Chrome 运行 + OpenCLI 扩展已连接（见「Chrome 扩展设置」）

### 触发条件

当用户查询「查一下XX公司/企业」「尽调XX公司」「XX公司的风险」「XX公司怎么样」等时，自动执行此流程。

### 执行流程（2026-07-12 三源融合实测确认 + 自动深度展开）

```
Step 1: 加载 skill opencli-integration
Step 2: 检查 Chrome + OpenCLI 扩展连接（opencli doctor）
Step 3: 打开天眼查 → 搜索公司 → 采集工商/股东/知识产权/招投标/司法数据
Step 4: 打开企业预警通 → 搜索同一公司 → 采集行政处罚详情/近6月风险统计/舆情指标
Step 5: 如企查查已登录 → 打开企查查 → 交叉验证关键数据
Step 6: 自动风险信号检测 → 如满足条件自动触发深度展开（见下方触发规则）
Step 7: 按模板整合 → 输出综合尽调报告（含深度展开数据）
```

**注意访问顺序：** 天眼查最稳定（基础数据无需登录），企业预警通次之（登录态持久），企查查最脆弱（WAF+登录态易过期）。按此顺序执行，即使企查查登录过期也能覆盖90%以上维度。

**⚠️ 关键规则：Step 6 是自发的，不是可选的。** 只要检测到风险信号（见下方），必须自动执行深度展开，不得等待用户提示。

### 自动深度展开触发规则（Step 6 详细）

在执行 Step 3-5 的初始采集后，**自动检查**以下信号，任一满足即自动触发深度展开：

| 信号 | 阈值 | 触发动作 |
|:-----|:----|:---------|
| **开庭公告 ≥ 5条** | >= 5 | 天眼查点击「法律诉讼」tab → 提取完整开庭公告表格（案号/案由/当事人/法院/时间） |
| **存在公司解散/注销纠纷** | 1条即触发 | 标记 🔴🔴 最高风险，单独写入报告警告段 |
| **行政处罚 > 0** | > 0 | 企业预警通提取处罚详情（日期/原因/文号/机关/罚金） |
| **预警提醒 > 100条** | > 100 | 列出前10条预警类型分类 |
| **涉诉关系 ≥ 10** | >= 10 | 分析原告vs被告比例，判断主动追款 vs 被动被追 |
| **裁判文书涉案金额 > 100万** | > 100万 | 提取具体案件详情 |
| **同一案号多次开庭** | >= 2次 | 标记案件复杂/调解未成，持续关注 |
| **自身风险 + 周边风险 > 50** | > 50 | 提取风险明细清单 |

**自动深度展开执行伪代码：**

```python
# 伪代码：Hermes 在 Step 3-5 之后自动执行的逻辑
def auto_deep_dive(company_data):
    signals = detect_risk_signals(company_data)
    
    if signals['court_notices'] >= 5:
        # 自动点击天眼查法律诉讼tab
        tyc_click_lawsuit_tab()
        sleep(3)
        court_details = tyc_extract_court_table()
        signals['court_details'] = court_details
    
    if signals['admin_penalties'] > 0:
        # 自动提取企业预警通处罚详情
        penalty_details = yujing_extract_penalties()
        signals['penalty_details'] = penalty_details
    
    if signals['dissolution_lawsuit'] > 0:
        signals['highest_risk'] = 'company_dissolution'
    
    # 分析案件性质
    defendant_cases = count_defendant_cases(court_details)
    plaintiff_cases = count_plaintiff_cases(court_details)
    signals['lawsuit_direction'] = {
        'plaintiff': plaintiff_cases,  # 柯渡主动追款
        'defendant': defendant_cases   # 柯渡被追款
    }
    
    return signals  # 注入最终报告
```

### 16维度尽调清单总览

| # | 维度 | 天眼查 | 企查查 | 企业预警通 |
|---|------|:------:|:------:|:----------:|
| 1 | 基础工商信息 | ✅ | ✅ | ❌ |
| 2 | 股权结构（含认缴金额） | ✅⭐ | ✅ | ❌ |
| 3 | 股权穿透至实控人 | ✅ | ⚠️(SVIP) | ❌ |
| 4 | 管理团队/法人履历 | ✅ | ✅ | ❌ |
| 5 | 对外投资与分支机构 | ✅⭐ | ⚠️ | ❌ |
| 6 | 法律诉讼与司法风险 | ✅ | ✅ | ✅（26件/12裁判/6立案） |\n| 7 | 经营风险（行政处罚/异常等） | ✅ | ✅ | ✅ **最优（6条处罚+340万详情）** |
| 8 | 历史沿革（股东/风险/变更） | ✅⭐ | ⚠️ | ❌ |
| 9 | 知识产权（商标/专利/软著） | ✅ | ✅ | ❌ |
| 10 | 资质许可与认证（高新/专精特新） | ✅ | ✅ | ❌ |
| 11 | 财务与年报/社保 | ✅ | ✅ | ❌ |
| 12 | 融资历史（轮次/投资机构） | ✅ | ✅ | ❌ |
| 13 | 招投标与供应链 | ✅ | ✅ | ❌ |
| 14 | 新闻舆情 | ✅ | ⚠️ | ✅⭐ |
| 15 | 关联关系（关联企业/协同股东） | ✅ | ✅ | ❌ |
| 16 | 行业对比 | ✅ | ✅ | ❌ |

> ✅ = 完整可获取 | ✅⭐ = 数据最优 | ⚠️ = 部分获取 | ❌ = 不支持

### 天眼查操作流程（16维度采集）

```bash
# 第1步：打开首页
opencli browser tyc open "https://www.tianyancha.com/" --window background
sleep 5

# 第2步：搜索公司
opencli browser tyc type <search-index> "公司名"
opencli browser tyc click <search-button-index>
sleep 5

# 第3步：从搜索结果中进入公司详情页
opencli browser tyc eval "document.querySelectorAll('a[href*=\"/company/\"]')[0]?.href"
opencli browser tyc open "<company-url>" --window background
sleep 8

# 第4步：获取基础信息 + 股东信息 + 主要人员 + 对外投资
opencli browser tyc eval "document.body.innerText"
# → 从中提取：工商信息、股东列表、高管、对外投资、诉讼、风险等

# 第5步：获取法律诉讼汇总
# 从详情页底部「法律诉讼」分类获取各维度数据
# 用 eval 提取全部文本后按关键词过滤
```

### 企查查操作流程（交叉验证）

```bash
# 打开企查查首页，搜索同一公司
opencli browser qcc open "https://www.qichacha.com/" --window background
sleep 3
# ... 按企查查专项操作流程
```

### 风险等级标记规则

| 等级 | 标记 | 条件 | 建议 |
|------|:----:|------|------|
| 严重 | 🔴🔴 | 被执行人 / 失信被执行人 / 破产案件 / 严重违法 / 股权冻结 | 强烈建议暂停合作/投资 |
| 高 | 🔴 | 行政处罚 / 环保处罚 / 限制消费令 / 税收违法 / 欠税公告 / 终本案件 | 需深入调查后方可决策 |
| 中 | 🟡 | 开庭公告 / 裁判文书 / 经营异常 / 历史股权冻结 / 劳动仲裁 | 关注但可正常合作，需持续监控 |
| 低 | 🟢 | 无上述任何风险记录 | 正常推进 |

### 综合尽调报告输出模板

```markdown
# 【公司名称】尽职调查报告
**查询时间：** YYYY-MM-DD | **数据来源：** 天眼查+企查查+企业预警通

## 一、基本信息摘要
- 状态：[存续/注销] | 评分：[86分]
- 法人：[姓名] | 注册资本：[金额]（实缴：全额）
- 成立：[日期] | 社保：[人数]人 | 标签：[高新/专精特新]

## 二、股权结构与穿透
（股东明细表 + 终极控制方）

## 三、管理团队
（主要人员 + 法定代表人关联）

## 四、对外投资
（子公司列表 + 注销项警示）

## 五、🔴 法律诉讼与司法风险
（各分类数量 + 最新动态 + 严重等级标记）

## 六、🟡 经营风险
（行政处罚/环保处罚/经营异常等）

## 七、知识产权
（商标/专利/软著数量）

## 八、资质与融资
（高新认证/融资轮次/投资机构）

## 九、财务与供应链
（社保趋势/招投标/客户）

## 十、风险综合评价
### 🟢 低风险项
### 🟡 中风险项
### 🔴 高风险项
### 综合建议
```

### 参考文件

- `references/due-diligence-framework.md` — 16维度完整清单、数据采集要点、穿透规则、模板
- `references/enterprise-platforms-comparison.md` — 三家平台实测对比、股东数据对比
- `references/equity-research-pattern.md` — 股权穿透实操模式
- `references/chrome-extension-setup.md` — Chrome扩展设置

---

## 搜索兜底融合模式（SearXNG → OpenCLI）

当 SearXNG 搜索返回空结果或结果不满意时，自动用 OpenCLI 查询特定站点作为兜底。

### 触发条件

- `web_search` 返回 0 条结果
- 结果太少（< 3 条）且与查询不相关
- 用户明确要求查某个平台的内容（如"帮我查知乎上关于XX"）
- 查询涉及中文特定平台内容（知乎/微博/小红书/B站等）

### 兜底策略：按主题映射

| 查询主题 | 兜底站点 | OpenCLI 命令 |
|---------|---------|-------------|
| 热点/热搜/时事 | 知乎、微博、微信 | `opencli zhihu hot -f json`<br>`opencli weibo hot -f json`<br>`opencli weixin search "关键词" -f json` |
| 科技/AI/编程 | HackerNews、36氪、arXiv | `opencli hackernews top -f json`<br>`opencli 36kr hot -f json`<br>`opencli arxiv search "关键词" -f json` |
| 商品/评测/购物 | 淘宝、京东、什么值得买 | `opencli taobao search "关键词" -f json`<br>`opencli jd search "关键词" -f json`<br>`opencli smzdm search "关键词" -f json` |
| 论文/学术 | arXiv、Semantic Scholar、PubMed | `opencli arxiv search "关键词" -f json`<br>`opencli semanticscholar search "关键词" -f json`<br>`opencli pubmed search "关键词" -f json` |
| 股票/财经/行情 | 雪球、新浪财经 | `opencli xueqiu search "股票名" -f json`<br>`opencli xueqiu hot-stock -f json`<br>`opencli sinafinance news -f json` |
| 生活/旅游/交通 | 12306、Booking、携程 | `opencli 12306 trains ... -f json`<br>`opencli booking search ... -f json` |
| 开发者/开源 | GitHub、npm、PyPI、Stack Overflow | `opencli github trending -f json`<br>`opencli npm search "包名" -f json`<br>`opencli stackoverflow search "问题" -f json` |
| 天气/地理位置 | wttr | `opencli wttr current "城市" -f json` |
| 视频/内容 | B站、抖音、YouTube | `opencli bilibili search "关键词" -f json`<br>`opencli douyin search "关键词" -f json`<br>`opencli youtube search "关键词" -f json` |
| 通用中文搜索 | 微信搜狗搜索 | `opencli weixin search "关键词" -f json` |
| 公司/股权调研 | 企查查（browser模式） | 见「企查查操作专项」 |

### 执行流程

```bash
# 步骤1: 先试 web_search（Hermes 自动）
web_search(query="公司名 股权结构")

# 步骤2: 如果结果不够，选合适站点兜底
# 公司调研 → 企查查
export PATH="$HOME/.npm-global/bin:$PATH"
opencli browser qcc open "https://www.qichacha.com/" --window background
...（按企查查操作专项流程）

# 合并结果后回复
```

### 技术要点

1. **并行查询**：可以同时查多个站点（用多个 terminal 调用），比串行快
2. **结果去重**：不同站点可能有重复内容，合并时注意去重
3. **来源标注**：回复时注明"来自 SearXNG"或"来自 OpenCLI 知乎/36氪/…"
4. **cookie 命令注意**：需要 Chrome 打开 + 扩展已连接，第一次调用可能较慢（30-60s）
5. **public 命令优先**：优先用无需登录的 public 模式，`AUTH_REQUIRED` 再切 cookie 模式

所有 164 个站点和 10 个应用的完整命令列表：
```bash
export PATH="$HOME/.npm-global/bin:$PATH"
opencli list | less
opencli list | grep -c "^  [a-z]"    # 应用+站点数
opencli <site> --help                # 查看某站点的所有子命令
```

---

## ⚠️ Chrome 双实例与登录态隔离（关键根因）

### 现象

用户在 Chrome 上已登录企查查/天眼查，但 `opencli browser` 打开的页面显示未登录，强制跳转微信登录页。

### 根因

OpenCLI 的 `opencli browser` 命令**不是用你日常使用的 Chrome 浏览器**，而是启动了一个**完全独立的 Chrome 副本**：

```bash
# 用户的主 Chrome
/Applications/Google Chrome.app/Contents/MacOS/Google Chrome
# 用户数据目录：~/Library/Application Support/Google/Chrome/
# 一切登录态都在这里（企查查已登录、天眼查已登录等）

# OpenCLI 启动的 Chrome（独立副本）
/Applications/Google Chrome.app/Contents/MacOS/Google Chrome
  --remote-debugging-port=18800
  --user-data-dir=/Users/jinzhanxiang/.openclaw/browser/openclaw/user-data
# 用户数据目录：~/.openclaw/browser/openclaw/user-data/（空壳，无任何登录信息）
```

**两个 Chrome 使用不同的 user-data-dir，互相隔离，不共享 cookies、登录态、书签、扩展。** 你在主 Chrome 上登录了企查查，但 OpenCLI 操作的 Chrome 并不知道。

### 预检：Chrome 是否带远程调试端口

每次 cookie/browser 命令前，先检测 Chrome 实例情况：

```bash
# 检测 Chrome 是否运行
pgrep -i "Google Chrome" > /dev/null && echo "Chrome 运行中" || echo "Chrome 未运行"

# 检测 Chrome 是否带 --remote-debugging-port（即方案A是否已生效）
ps aux | grep "Google Chrome" | grep -v grep | grep -v helper | head -5

# 解读：
# - 如果输出含 --remote-debugging-port=18800 → 方案A已生效
# - 如果输出只有 /Applications/Google Chrome.app/... → 方案A未生效，存在双实例问题
# - 如果无输出 → Chrome 未运行

# 检测 OpenCLI 是否连接到主Chrome
opencli doctor
# Extension: connected → 已连接
# Daemon: running → daemon正常
```

**场景判断：**

| 检测结果 | 问题 | 应对 |
|:---------|:-----|:-----|
| Chrome 未运行 | 无Chrome | 自动启动后打开chrome://extensions唤醒扩展 |
| Chrome运行, 无 `--remote-debugging-port` | **双实例问题复发** ⚠️ | 方案A：重启Chrome带远程调试端口 |
| Chrome运行, 有 `--remote-debugging-port` | ✅ 方案A已生效 | 直接执行，登录态共享 |
| OpenCLI Chrome已启动（ps可见两个Chrome进程） | ✅ 双实例已确认 | 立即执行方案A |

### 验证方法

```bash
# 查看 Chrome 进程
ps aux | grep -i "Google Chrome" | grep -v grep | grep -v helper

# 查看 OpenCLI 启动的 Chrome 参数
ps aux | grep "remote-debugging-port" | grep -v grep

# 对比两个 Chrome 的 cookie 数据库
python3 -c "
import sqlite3
oc = sqlite3.connect(os.path.expanduser('~/.openclaw/browser/openclaw/user-data/Default/Cookies'))
main = sqlite3.connect(os.path.expanduser('~/Library/Application Support/Google/Chrome/Default/Cookies'))
# 对比企查查 cookie
for name, db in [('OpenCLI Chrome', oc), ('主Chrome', main)]:
    c = db.cursor()
    c.execute(\"SELECT host_key, name FROM cookies WHERE host_key LIKE '%qcc%'\")
    rows = c.fetchall()
    print(f'{name}: {len(rows)} 个企查查 cookie')
"
```

### 解决方案

#### 方案 A（推荐）：重启主 Chrome 带远程调试

让 OpenCLI 直接操作你的主 Chrome，共享所有登录态：

```bash
# 1. 正常退出 Chrome（⚠️ 必须用osascript，不能用pkill -9）
osascript -e 'quit app "Google Chrome"'
sleep 2

# 2. 用主 Chrome 的用户数据目录 + 远程调试端口启动
open -a "Google Chrome" --args \
  --remote-debugging-port=18800 \
  --user-data-dir="$HOME/Library/Application Support/Google/Chrome"

# 3. 等待 Chrome 启动
sleep 5

# 4. 重启 OpenCLI daemon 让它连接新端口
opencli daemon restart
sleep 3
opencli doctor
# → 应显示 Extension: connected, Daemon: running

# 5. 验证远程调试端口已生效
ps aux | grep "Google Chrome" | grep "remote-debugging-port" | grep -v grep
# → 应显示 --remote-debugging-port=18800

# 6. 现在 opencli browser 将使用你的主 Chrome（含所有登录态）
```

**⚠️ 关键：后台启动必须用 notify_on_complete=true**

当用 background=true 启动 Chrome 时，必须配对 `notify_on_complete=true`，否则 Hermes 无法感知 Chrome 何时完成启动：

```bash
# ✅ 正确：启动Chrome + 通知
open -a "Google Chrome" --args \
  --remote-debugging-port=18800 \
  --user-data-dir="$HOME/Library/Application Support/Google/Chrome"
# 后续的 opencli daemon restart 必须在 Chrome 实际启动后执行
# 建议：用 sleep 5 等待，或用 notify_on_complete 确保顺序
```

**⚠️ 方案A不持久的根因：** Chrome 正常重启后，`--remote-debugging-port` 参数丢失。因为：
- `open -a "Google Chrome"` 默认启动不带自定义参数
- 用户手动打开的 Chrome 也不带 `--remote-debugging-port`
- 方案A只在**当前 Chrome 进程**的生命周期内有效

**解决方案 — 创建启动脚本：**

```bash
# 创建快捷启动脚本
cat > ~/.hermes/scripts/chrome-with-debug.sh << 'EOF'
#!/bin/bash
osascript -e 'quit app "Google Chrome"'
sleep 2
open -a "Google Chrome" --args \
  --remote-debugging-port=18800 \
  --user-data-dir="$HOME/Library/Application Support/Google/Chrome"
sleep 5
opencli daemon restart 2>/dev/null
sleep 3
opencli doctor
EOF
chmod +x ~/.hermes/scripts/chrome-with-debug.sh

# 每次重启Chrome后执行
bash ~/.hermes/scripts/chrome-with-debug.sh
```

#### 方案 B（即时）：bind 绑定到当前标签页

不重启 Chrome，直接绑定到用户已登录的 Chrome 标签页：

```bash
# 1. 用户在 Chrome 中打开目标网站并登录（如 qcc.com）
# 2. 确保该标签页是当前活动标签页
# 3. 执行 bind
opencli browser <session-name> bind
# → 绑定成功，session 指向用户当前标签页

# 4. 现在可以操作该标签页
opencli browser <session-name> state
opencli browser <session-name> eval "window.location.href"
```

**限制：** `bind` 绑定到 OpenCLI 扩展连接的 Chrome 实例。如果扩展连接的是 OpenCLI 启动的独立 Chrome，则 `bind` 仍绑定到该独立 Chrome，而非用户的主 Chrome。**方案 A 才是根本解决。**

#### 方案 C（临时）：AppleScript 控制主 Chrome

当无法使用方案 A/B 时，直接用 AppleScript 操作主 Chrome：

```bash
osascript -e '
tell application "Google Chrome"
    activate
    open location "https://www.qcc.com/"
    delay 3
    -- 执行搜索等操作
    tell application "System Events" to keystroke "中复碳芯"
    delay 1
    tell application "System Events" to key code 36  -- Enter
end tell
'
```

**限制：** 无法结构化提取数据（无 eval），只能做简单导航和点击。

### 三源融合的登录态敏感性

| 平台 | 主 Chrome 登录态 | OpenCLI Chrome 登录态 | 影响 |
|:----|:---------------:|:--------------------:|:----|
| **天眼查** | ✅ 已登录 | ⚠️ 基础数据无需登录 | 基础工商/股东/风险数据可见 |
| **企业预警通** | ✅ 已登录 | ✅ Cookie 持久性好 | 登录态可跨 session 保持 |
| **企查查** | ✅ 已登录 | ❌ 无登录态 | 搜索/详情均被 WAF 拦截 |

**建议：** 优先使用天眼查+企业预警通（覆盖90%+），企查查作为交叉验证。如需企查查，用方案 A 或让用户手动打开企查查后 bind。

1. **PATH 问题**：`~/.npm-global/bin` 不在默认 PATH 中，每次使用前必须 export
2. **cookie 模式**：需要 Chrome 打开 + 扩展已连接 + 对应站点已登录。详见 `references/chrome-extension-setup.md`
3. **cookie 命令较慢**：需要开 Chrome 标签页操作，比 public 命令慢。给 terminal 工具设置 30-60s 超时，不要用 15s 默认值
4. **AUTH_REQUIRED (exit 77)**：扩展已连接但该站点未登录。让用户用 Chrome 打开该站点并登录
5. **BROWSER_CONNECT (exit 69)**：Chrome 未打开或扩展断连。使用 4 步恢复流程：
   - pgrep -i "Google Chrome" 检测是否运行
   - 未运行则 open -a "Google Chrome" + sleep 5 正常启动
   - 执行 4 步恢复：osascript 打开 chrome://extensions → System Events Cmd+R 刷新 → opencli daemon restart
   - opencli doctor 验证
   - 仍断连则通知用户手动在 chrome://extensions 刷新扩展
   详见 references/chrome-extension-setup.md「自动恢复步骤」
6. **扩展连接不稳定**：长时间不用可能断连，建议每次 cookie 命令前先跑 `opencli doctor` 确认状态。若 Chrome 重启过，手动加载的扩展需重新加载
7. **速率限制**：频繁调用 cookie 模式命令可能触发站点反爬，建议间隔 1-2 秒
8. **JSON 输出**：始终使用 `-f json` 让 Hermes 能结构化处理结果
9. **桌面应用 CDP**：需要应用正在运行；可能需要先 `opencli <app> status` 检查连接
10. **Node.js 版本要求**：>= 21（本机 Node 24 已验证通过）
11. **terminal 超时**：cookie 命令需要 30-60s 超时；public 命令 15s 足够；browser 命令等待渲染需要额外时间
12. **主动预检**：每次 cookie/browser 命令前，先主动检查 `opencli doctor`，Chrome 未开则自动打开
13. **⚠️ 永远不要 pkill -9 杀 Chrome**：强制杀掉 Chrome 会损坏 Preferences 文件，导致"已解压的扩展程序"丢失。必须用 `osascript -e 'quit app "Google Chrome"'` 正常退出
14. **扩展重启后恢复**：如果 Chrome 正常重启后扩展未连，用 4 步恢复流程：`osascript` 打开 `chrome://extensions` → `Cmd+R` 刷新 → `opencli daemon restart` → `opencli doctor` 验证。详见 references/chrome-extension-setup.md「自动恢复步骤」

15. **AppleScript 兜底**：OpenCLI browser 无法打开 `chrome://` 内部页面。当需要操作 Chrome 内部页面（如 extensions 管理、设置页）时，用 `osascript` 替代：
    ```bash
    osascript -e 'tell application "Google Chrome" to open location "chrome://extensions"'
    ```

16. **风险数据提取：eval \"document.body.innerText\" 优先**：天眼查等 React SPA 的页面结构复杂，用 eval 提取特定 DOM 元素可能因 class 名动态生成而失败。`eval \"document.body.innerText.substring(0, 8000)\"` 是最可靠的方式，全页文本包含所有可见的风险信息、股东信息、高管信息、对外投资等

17. **⚠️ 弹窗处理：关弹窗不关页面**：当页面上出现弹窗（VIP邀请/广告/登录提示等），**必须关闭弹窗而非关闭页面或导航离开**。先用 `dialog` 命令检查是否有JavaScript对话框。否则用 `eval` 找到关闭按钮点击：`eval \"document.querySelector('[class*=close],[class*=cancel],[class*=dialog] button, [aria-label*=关闭]')?.click()\"`。**永远不要**因为弹窗就关闭整个session或导航到 about:blank。

18. **⚠️ 元素索引 [N] 不稳定（关键）**：OpenCLI browser `state` 返回的元素 `[N]` 索引每次加载都可能变化。**不能硬编码索引**。正确做法：
    - 每次先用 `state` 确认当前索引
    - 或用 `eval` CSS 选择器兜底：`eval "document.querySelector('input[placeholder*=\"企业/证券\"]')"`
    - 先 `state` 找索引，不匹配时 fallback 到 `eval`

19. **⚠️ eval 变量名冲突：同一 session 多次 eval 变量会残留**：变量名从上次 eval 残留，导致 `SyntaxError: Identifier 'X' has already been declared`。**解决方案**：每次用不同变量名，或用IIFE包裹：
    ```bash
    opencli browser <s> eval "let data1 = ...; JSON.stringify(data1)"
    opencli browser <s> eval "let data2 = ...; JSON.stringify(data2)"  # 不同变量名
    # 或
    opencli browser <s> eval "(function(){ let items = ...; return JSON.stringify(items); })()"
    ```

20. **⚠️ 企业预警通搜索结果误判风险**：搜索后默认显示"证券"tab，企业结果可能隐藏在"全部"或"企业"tab中。**不要因为搜索结果页无企业链接就下"未收录"结论**。必须先检查：
    - 是否切换到"全部"tab查看所有结果
    - 或用 `eval` 直接搜索所有 `<a>` 链接中的企业名
    - 正确流程：搜索 → 切换到"全部"tab → 提取所有企业详情链接 → 如仍无结果再判断"未收录"
    ```bash
    # 正确做法：先搜索，再检查所有结果
    opencli browser yujing eval "
    var anchors = document.querySelectorAll('a');
    var out = [];
    for(var i=0; i<anchors.length; i++) {
      var txt = anchors[i].textContent.trim().substring(0, 40);
      if(txt.length > 2) out.push({text: txt, href: (anchors[i].href || '').substring(0,120)});
    }
    JSON.stringify(out.slice(0,8), null, 2);
    "
    ```

21. **⚠️ 企业预警通覆盖范围比假设的广（但搜索默认tab为「证券」）**：经实测柯渡医学（非债券/非上市公司）仍有数据（信用分545、股东信息、风险等）。**之前的「仅收录有债券/金融风险企业」的假设是错误的。** 覆盖范围更广，但搜索后默认显示「证券」tab，企业结果在「全部」tab中。正确流程：搜索 → eval 枚举所有链接筛选 `/detail/enterprise/overview` → 仍无结果再判断「未收录」。

22. **⚠️ 执行流程必须按天眼查→预警通→企查查顺序**：天眼查最稳定（免登录），预警通次之（登录持久但非全量），企查查最脆弱（WAF+登录态）。按此顺序，后续失败也能覆盖90%+维度。

23. **⚠️ 企业预警通有两个搜索栏**：顶栏搜索框（placeholder="公司/证券/集团户/功能"）和主体搜索框（placeholder="企业/证券/功能/集团户/区域/关键字"）。**必须用主体搜索框**。

24. **天眼查 extract 比 eval tables 更可靠**：React SPA 表格 class 名动态生成，`eval "document.querySelector('table')"` 可能找不到。优先用 `extract` 或 `eval "document.body.innerText"`。

25. **⚠️ 三源数据差异是常态，非异常**：同一公司的科创分三家平台可能分别为99、88、73.73；融资轮次可能为"股权融资"/"C轮"/"D轮"。这是因为数据口径、更新频率、来源不同。**报告应如实展示差异，不强行统一**。信用分（企业预警通独有）是其他平台没有的独特维度。

26. **⚠️ 登录检测不能依赖单一字符串**：企查查登录态检测中，`document.body.innerText.includes('退出')` 在已登录状态下可能返回 false，造成误判为"未登录"。**正确方式**：同时检查无登录按钮 + 有消息入口：
    ```javascript
    // ✅ 正确：检查两个指标
    let hasNoLoginLink = !document.body.innerHTML.includes('登录');
    let hasMessages = document.body.innerText.includes('消息');
    // hasNoLoginLink && hasMessages → 已登录
    ```

27. **⚠️ 不要轻信"无数据"结论，先检查搜索tab**：企业预警通搜索默认显示"证券"tab而非"企业"tab。**柯渡医学的教训** — 最初认为"预警通没收录"，实际是因为搜索结果默认在"证券"tab，切换tab后即可看到企业数据。**任何"无数据"结论前必须先验证tab切换和全量链接扫描。**

28. **⚠️ 三源融合执行需独立验证每一步，禁止推测**：每步操作后必须用 `eval` 或 `state` 验证实际结果。例如：
    - 天眼查搜索后 → 检查 window.location.href 是否跳转
    - 企业预警通搜索后 → 检查搜索结果中的企业链接
    - 企查查操作后 → 检查登录态是否仍然有效
    - **唯一可靠的验证方式：看页面实际内容，而不是假设操作成功**

---

## 自动深度展开能力（Step 6 自动触发）

> **这不是可选操作。** 在三源融合 Step 3-5 完成后，Hermes 必须自动检测风险信号并触发深度展开，详见上方「自动深度展开触发规则」表。

### 三源深度展开能力对比（2026-07-12 实测）

| 能力 | 天眼查 | 企查查 | 企业预警通 |
|:-----|:------:|:------:|:----------:|
| **开庭公告详情**（案号/案由/当事人/法院/时间） | ✅⭐ 23条完整表格 | ✅⭐ 33条（更多） | ⚠️ 仅近6月统计 |
| **单个案件详情钻取** | ✅ 点击「详情」展开（React模态） | ✅ 需VIP查看深度内容 | ❌ 无逐案详情 |
| **裁判文书详情**（涉案金额/判决结果） | ⚠️ 需登录查看 | ⚠️ 需VIP | ⚠️ 12份摘要 |
| **行政处罚详情**（处罚日期/原因/文号/机关） | ⚠️ 需登录 | ⚠️ 需VIP | ✅⭐ **最优**（6条处罚340万含全部字段） |
| **立案信息详情**（案号/案由/当事人/立案日期） | ✅⭐ 4条完整表 | ✅⭐ 10条完整表 | ⚠️ 6条摘要 |
| **公司解散纠纷专项** | ✅ 有（1条，山西子公司） | ✅ 有 | ❌ 无 |
| **新闻舆情深度**（热点新闻/动态时间线） | ✅ 首页动态时间线 | ✅ 动态时间线+新闻舆情35条 | ✅ 近6月舆情统计 |
| **竞品信息** | ⚠️ 19家（摘要） | ✅⭐ 13家（含详情） | ❌ |
| **客户/供应商信息** | ✅ 客户307/供应商1 | ⚠️ 客户332/供应商1（部分需VIP） | ❌ |

### 深度展开操作流程（自动触发，见Step 6触发规则表）

以下是 Step 6 中每条触发规则对应的具体操作命令：

#### 🔴 触发规则1：开庭公告 ≥ 5条 — 自动提取完整开庭公告表

```bash
# 【自动触发】天眼查点击法律诉讼tab → 提取开庭公告表格
# 1. 导航到公司详情页
opencli browser tyc open "https://www.tianyancha.com/company/{companyId}" --window background
sleep 6

# 2. 点击「法律诉讼」tab展开子模块
opencli browser tyc eval "(function(){
  let spans = document.querySelectorAll('span');
  for(let s of spans) { if(s.textContent.trim() === '法律诉讼') { s.click(); break; } }
  return 'clicked';
})()"
sleep 3

# 3. 提取全部开庭公告数据
opencli browser tyc eval "(function(){
  let txt = document.body.innerText;
  let idx = txt.indexOf('开庭公告');
  let end = txt.indexOf('裁判文书', idx);
  if(end < 0) end = txt.indexOf('立案信息', idx);
  if(end < 0) end = Math.min(idx + 5000, txt.length);
  return idx >= 0 ? txt.substring(idx, end) : '未找到';
})()"

**备选：企查查**（数据更多，但需登录）

```bash
# 1. 搜索并导航到企查查详情页
opencli browser qcc open "https://www.qcc.com/firm/{firmHash}.html" --window background
sleep 6

# 2. 直接提取全量文本，找法律诉讼区域
opencli browser qcc eval "(function(){
  let txt = document.body.innerText;
  let idx = txt.indexOf('法律诉讼');
  let section = idx >= 0 ? txt.substring(idx, Math.min(idx + 5000, txt.length)) : txt.substring(0, 5000);
  return section;
})()"
```

#### 🔴 触发规则2：行政处罚 > 0 — 自动提取处罚详情

**企业预警通**（处理机关、违规原因、罚没金额完整）

```bash
# 1. 导航到公司详情页
opencli browser yujing open "https://www.qyyjt.cn/detail/enterprise/overview?code={code}&type=company" --window background
sleep 5

# 2. 提取全量数据（含行政处罚详情区）
opencli browser yujing extract
```

#### 🔴 触发规则3：涉诉关系 ≥ 10或裁判文书金额 > 100万 — 自动钻取单个案件详情

**天眼查「详情」按钮**

```bash
# 在开业公告列表中找到并点击第一条的「详情」
opencli browser tyc open "https://www.tianyancha.com/company/{companyId}/sifa" --window background
sleep 5

# 点击「详情」（找到可见的第一个详情链接）
opencli browser tyc eval "(function(){
  let spans = document.querySelectorAll('span');
  for(let s of spans) {
    if(s.textContent.trim() === '详情' && s.offsetParent !== null) {
      s.click(); break;
    }
  }
  return 'clicked detail';
})()"
sleep 3

# 提取详情内容（React模态展开）
opencli browser tyc eval "(function(){
  let txt = document.body.innerText;
  // 找详情附近的内容，通常包含更详细的案件描述
  let idx = txt.indexOf('案由');
  let section = idx >= 0 ? txt.substring(Math.max(0, idx - 200), Math.min(txt.length, idx + 2000)) : '未找到';
  return section;
})()"
```

#### 🔴 触发规则4：预警提醒 > 100 — 自动提取重大舆情和公司动态

**天眼查**首页直接包含：
- 热点新闻版块（最新中标/处罚/投资动态）
- 动态时间线（按日期排列的事件流）
- 招投标动态（最新中标项目）

**企查查**首页包含更多商业舆情：
- 商业快讯（行业新闻，含相关公司链接）
- 动态时间线（中标/商标/投资变更）
- 新闻舆情模块（35条）

```bash
# 天眼查——导航到详情页后直接提取动态区域
opencli browser tyc eval "(function(){
  let txt = document.body.innerText;
  let idx = txt.indexOf('热点新闻');
  let section = idx >= 0 ? txt.substring(idx, Math.min(idx + 3000, txt.length)) : '未找到热点新闻';
  return section;
})()"
```

### 深度展开的严重等级判断

当钻取到具体案件数据后，用以下信号判断严重程度：

| 信号 | 严重程度 | 案例 | 说明 |
|:-----|:--------:|:-----|:-----|
| **公司解散纠纷** | 🔴🔴 最高 | 柯渡医学 vs 山西柯渡 | 子公司内部矛盾，可能影响关联公司运营 |
| **装饰装修合同纠纷**（供应商起诉） | 🔴 高 | 长浩工程 vs 柯渡医学 | 供应商收不到款起诉，反映现金流压力 |
| **服务合同纠纷**（医院方不付款） | 🟡 中 | 柯渡 vs 泉港医院/上饶中医院 | 医疗设备维保行业常见，医院回款慢 |
| **同一案号多次开庭** | 🟡 中 | (2025)闽0505民初5888号开庭4次 | 案件复杂/调解未成，持续关注 |
| **原告vs被告身份** | — | 柯渡作原告=追款；作被告=被追款 | 被告方案件反映偿债压力 |
| **多起异地诉讼** | 🟡 中 | 涉及闵行/泉港/上饶/厦门/太原/启东多地 | 跨区域经营纠纷普遍 |

### Step 6 自动化执行流程总结

```
检测到风险信号（如开庭23条/处罚6条/预警409条）
    ↓ 自动触发（无需用户要求）
Step 6a: 天眼查「法律诉讼」tab展开 → 提取开庭公告完整表格
Step 6b: 分析案由分布（合同纠纷多为追款、解散纠纷为严重）
Step 6c: 分析当事人身份（原告=公司主动追款、被告=公司被追款）
Step 6d: 如涉及行政处罚 → 企业预警通提取处罚详情
Step 6e: 企查查交叉验证（数据量可能更多）
Step 6f: 输出风险评价（分级+具体案件示例+趋势判断）
注：以上全部自动执行，不等待用户要求
```

## Reference Files
- `references/due-diligence-framework.md` — **16 维度尽调完整框架**
- `references/three-source-fusion-workflow.md` — 三源融合尽调工作流
- `references/chrome-dual-instance-root-cause.md` — Chrome 双实例根因分析
- `references/browser-act-bypass.md` — BrowserAct 反检测浏览器备选方案（OpenCLI 被拦截时启用）
- `scripts/chrome-with-debug.sh` — 一键重启Chrome带远程调试端口，解决双实例登录态隔离问题

## 关联技能

### 浏览器自动化关联

`opencli-integration` 使用的 **OpenCLI browser** 与 Hermes 内置浏览工具（`browser-automation` skill）是两套不同的浏览器自动化机制，已在 `browser-automation/references/browser-registry.md` 中注册为独立路径：

| 维度 | OpenCLI browser（本 skill） | Hermes 内置工具（browser-automation skill） |
|:----|:--------------------------|:----------------------------------------|
| 浏览器 | 主 Chrome（共享登录态） | CloakBrowser（反检测，隔离 profile） |
| 注册 ID | `opencli` | `cloak` |
| 适用场景 | 需要登录的站点（企查查/预警通/微博/知乎） | 免登录浏览、信息提取 |
| 操作方式 | CLI 命令（opencli browser ...） | 工具调用（browser_navigate/click/console） |
| 登录态 | ✅ 共享 Chrome 所有 cookie | ❌ 隔离，需额外处理 |

**使用建议：**
- 查询**免登录站点**（如天眼查基础工商信息）→ 用 Hermes 内置工具（无需加载 skill）
- 查询**需登录站点**（企查查/预警通/微博等）→ 加载本 skill，用 `opencli browser`
- 复杂场景可**混合使用**：Hermes 工具浏览 → OpenCLI 查需登录部分

参见 `autonomous-ai-agents/browser-automation` skill 的「浏览器自动化路径选择指南」。

### 数据后处理

当完成 16 维度数据采集后，如需进一步估值建模或财务分析，加载 `research/investment-finance-skills`：

- DCF 估值模型（LLM 假设 → Python 纯计算）
- 可比公司/可比交易分析
- 敏感性分析矩阵
- 完整投资分析报告生成