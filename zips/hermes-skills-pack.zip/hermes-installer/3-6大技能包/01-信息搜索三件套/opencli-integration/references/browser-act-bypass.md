# 反检测浏览器方案 — OpenCLI 被拦截时的备选方案

## 概要

当 OpenCLI 浏览器被网站反爬拦截时，有两个反检测方案可选：

| 方案 | 成本 | 反检测 | 推荐度 |
|:----|:----|:------|:------|
| **CloakBrowser**（推荐） | **免费** MIT 开源 | **30/30 全绿** | ⭐⭐⭐ 首选 |
| **BrowserAct**（备选） | **$13/月起** | 18/18 全绿 | ⭐⭐ 仅作备选 |

## 方案一：CloakBrowser（推荐，已集成到 Hermes）

**这是当前推荐方案。** CloakBrowser 是 Chromium 源码级反检测浏览器，30/30 反检测全绿，已通过 `AGENT_BROWSER_EXECUTABLE_PATH` 集成到 Hermes 内置浏览器工具。

```bash
# 安装
pip install cloakbrowser
# 在 ~/.hermes/.env 中设置（已配置）
# AGENT_BROWSER_EXECUTABLE_PATH=/Users/jinzhanxiang/.cloakbrowser/.../Chromium
```

**使用方法：** 直接用 Hermes 的 `browser_navigate` 等内置浏览器工具即可，自动使用 CloakBrowser 内核。

**实测结果：**
| 网站 | CloakBrowser 结果 |
|:----|:-----------------|
| 天眼查 | ✅ 完全通过 |
| 企业预警通 | 🚫 页面对，但搜索/详情需登录 |
| 企查查 | ⚠️ 过 Cloudflare，搜索需登录 |

详见 `browser-automation` skill 的 `references/cloakbrowser-setup.md`。

## 方案二：BrowserAct（付费备选，当 CloakBrowser 不够时）

当 CloakBrowser 的反检测仍然不够（如企查查 405 应用层拦截），且不方便登录时，可使用 BrowserAct 的 `stealth-extract` 服务。

### 前提条件

```bash
pipx install browser-act-cli
browser-act get-skills main
browser-act auth set <API_KEY>    # 需要付费 API Key
```

### 用法

```bash
# 轻量提取（推荐，无需创建浏览器）
browser-act stealth-extract <url> --content-type markdown

# 全浏览器自动化
browser-act --session s1 browser open <browser-id> <url>
```

### 定价（2026-07）

| 计划 | 价格/月 | 可查次数/月 |
|:---|:-------|:----------|
| Free Trial | $0（100 Credits/天） | ≈ 1次/天 |
| Basic | **$13**（年付） | ≈ 90次 |

### 使用策略

| 场景 | 首选方案 |
|:----|:--------|
| 天眼查查询 | CloakBrowser ✅ |
| 企业预警通查询 | CloakBrowser + 登录 session |
| 企查查查询 | CloakBrowser + `--restore` 登录 session ✅ |
| 上述都不行 | BrowserAct stealth-extract（付费备选） |