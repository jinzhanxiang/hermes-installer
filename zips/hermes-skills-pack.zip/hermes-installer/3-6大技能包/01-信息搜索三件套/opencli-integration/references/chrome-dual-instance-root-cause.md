# Chrome 双实例与登录态隔离

## 问题现象

用户在 Chrome 上已登录企查查、天眼查等网站，但 `opencli browser` 操作的页面显示未登录，搜索时强制跳转微信登录页。

## 根因分析

### 两个 Chrome 实例

```
主 Chrome（用户日常使用）
  PID: 76412
  用户数据目录: ~/Library/Application Support/Google/Chrome/
  远程调试: 未开启
  登录态: 企查查已登录、天眼查已登录、企业预警通已登录

OpenCLI 启动的 Chrome（独立副本）
  PID: 97491
  用户数据目录: ~/.openclaw/browser/openclaw/user-data/
  远程调试: --remote-debugging-port=18800
  登录态: 空壳，无任何登录信息
```

### 关键发现

- 两个 Chrome 使用**完全不同的 user-data-dir**，不共享 cookies、登录态、书签、扩展
- OpenCLI 浏览器扩展连接的是**OpenCLI 启动的 Chrome**（端口 18800），而非用户的主 Chrome
- 这是 OpenCLI 的设计选择——为了不干扰用户正常使用浏览器
- 但这也意味着所有需要登录的站点（企查查、天眼查等）在 OpenCLI 的 Chrome 中都没有登录态

### 验证命令

```bash
# 查看所有 Chrome 进程
ps aux | grep -i "Google Chrome" | grep -v grep | grep -v helper

# 查看 OpenCLI 启动的 Chrome 参数
ps aux | grep "remote-debugging-port" | grep -v grep

# 对比 cookie 数据库
python3 -c "
import os, sqlite3

oc_path = os.path.expanduser('~/.openclaw/browser/openclaw/user-data/Default/Cookies')
main_path = os.path.expanduser('~/Library/Application Support/Google/Chrome/Default/Cookies')

for label, path in [('OpenCLI Chrome', oc_path), ('主Chrome', main_path)]:
    if os.path.exists(path):
        conn = sqlite3.connect(path)
        c = conn.cursor()
        c.execute(\"SELECT host_key, name FROM cookies WHERE host_key LIKE '%qcc%' OR host_key LIKE '%tianyancha%'\")
        rows = c.fetchall()
        print(f'{label}: {len(rows)} 个相关cookie')
        conn.close()
    else:
        print(f'{label}: 数据库不存在')
"
```

## 解决方案

### 方案 A（推荐）：重启主 Chrome 带远程调试

```bash
# 1. 正常退出 Chrome
osascript -e 'quit app "Google Chrome"'
sleep 2

# 2. 用主 Chrome 的用户数据目录启动
open -a "Google Chrome" --args \
  --remote-debugging-port=18800 \
  --user-data-dir="$HOME/Library/Application Support/Google/Chrome"

sleep 5

# 3. 重启 OpenCLI daemon
opencli daemon restart
sleep 3
opencli doctor
# → 应显示 Extension: connected, Daemon: running
```

### 方案 B（即时）：bind 绑定

```bash
# 用户打开目标网站并登录 → 确保是活动标签页 → 执行
opencli browser <session> bind
```

### 方案 C（临时）：AppleScript 控制主 Chrome

```bash
osascript -e 'tell application "Google Chrome" to open location "https://www.qcc.com/"'
```

## 三源融合的登录态影响

| 平台 | 主 Chrome | OpenCLI Chrome | 建议 |
|:----|:---------:|:--------------:|:----|
| 天眼查 | 已登录 | 基础数据无需登录 | 优先使用 |
| 企业预警通 | 已登录 | Cookie 持久性好 | 优先使用 |
| 企查查 | 已登录 | 无登录态 | 需方案 A 或 bind |

## 2026-07-12 实测记录

- 首次发现：用户反馈企查查已登录但 OpenCLI 操作时跳转微信登录
- 排查过程：`ps aux | grep chrome` 发现两个 Chrome 主进程
- 确认根因：`--user-data-dir` 参数指向 `~/.openclaw/` 而非标准的 Chrome 配置目录
- 验证：对比两个 Cookie 数据库，确认 OpenCLI Chrome 无企查查 auth cookie