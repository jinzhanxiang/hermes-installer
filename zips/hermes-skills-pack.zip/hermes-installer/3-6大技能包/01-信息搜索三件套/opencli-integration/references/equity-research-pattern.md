# 企查查股权穿透研究模式

> **⚠️ 注意：自 2026-07-12 起，天眼查已替代企查查作为股权穿透首选项。**
> 天眼查数据更详细（含认缴出资额、历史股东），详见 `due-diligence-framework.md` 完整 16 维度框架。
> 以下企查查流程仅用于交叉验证。天眼查操作流程见 SKILL.md 中「综合尽职调查自动化流程」章节。

## 概述

通过 OpenCLI 浏览器驱动模式，对企查查上无内置适配器的公司进行股权穿透研究，逐层追溯到最终受益人（自然人或国资委）。

## 典型工作流

### 第1层：搜索目标公司

```bash
opencli browser <session> open "https://www.qichacha.com/" --window background
sleep 3
opencli browser <session> state
# 找到搜索框 [N] 索引
opencli browser <session> type <N> "目标公司名"
opencli browser <session> click <查询按钮>
sleep 3
# 确认 URL 变为 /web/search?key=...
```

### 第2层：获取公司基本信息 + 股东列表

```bash
# 获取基础信息表
opencli browser <session> eval "document.querySelector('table')?.innerText"

# 获取股东持股表
opencli browser <session> eval \
  "let tables=document.querySelectorAll('table'); \
   let r=[]; for(let t of tables){if(t.innerText.includes('持股比例'))r.push(t.innerText)}; r.join('\\n---\\n')"

# 获取高管信息表
opencli browser <session> eval \
  "let tables=document.querySelectorAll('table'); \
   let r=[]; for(let t of tables){if(t.innerText.includes('职务'))r.push(t.innerText)}; r.join('\\n---\\n')"
```

### 第3层：逐层穿透上游股东

对每个法人股东，重复第1-2步：

```bash
# 获取法人股东的详情页链接
opencli browser <session> eval "document.querySelector('a[href*=\"/firm/\"]')?.href"

# 打开股东公司页面
opencli browser <session> open "<股东详情页URL>" --window background
sleep 3

# 提取该股东的基础信息（注意企业类型字段）
# 有限责任公司（法人独资）→ 100% 被单一法人持有
# 有限责任公司（国有独资）→ 100% 国资委
opencli browser <session> eval "document.querySelector('table')?.innerText"

# 提取该股东的股东信息
opencli browser <session> eval \
  "let tables=document.querySelectorAll('table'); \
   let r=[]; for(let t of tables){if(t.innerText.includes('持股比例'))r.push(t.innerText)}; r.join('\\n---\\n')"
```

### 第4层：判断终极受益人

| 企业类型 | 含义 | 终极受益人 |
|---------|------|-----------|
| 有限责任公司（国有独资） | 100% 国资委持有 | 国务院国资委 |
| 有限责任公司（法人独资） | 100% 被单一法人持有 | 继续向上穿透 |
| 股份有限公司（上市） | 上市公司 | 查前十大股东 |
| 有限合伙企业 | 私募/员工持股平台 | 查 GP/LP 结构 |
| 自然人股东 | 个人持股 | 该自然人 |

## 数据解读模板

### 股权结构总结

```
┌─ 终极受益人
│  100% ↓
├─ 一级控股公司
│  100% ↓
├─ 二级投资平台
├──────┬──────┘
│  X%  ↓
├─ 目标公司
│  ┌──────────────┐
│  │ 股东1 (类型)  XX% │
│  │ 股东2 (类型)  XX% │
│  │ 股东3 (类型)  XX% │
│  └──────────────┘
│  ▸ 子公司
```

### 国资比例算法

```
国资合计 = 央企股东持股 + 国企股东持股
```

如果国资合计 > 50%，该公司为国有控股企业；如果国资合计 < 50% 但为最大股东，为国有相对控股。

### 投资轮次推断

- 股东名称含"基金"、"投资"、"资本" → 财务投资人
- 多个机构同一年进入 → 同一轮融资
- 早期股东（成立时进入）→ 创始股东
- 员工持股平台（名称含"合伙"、"新芯"等）→ 管理层/员工激励

## 已知限制

- **实际控制人页面**：需要 SVIP 会员（年费 ¥1800+），免费用户无法查看
- **股权穿透图**：SVG 渲染，无法通过 `extract` 或 `eval` 提取文本，只能手动逐层穿透
- **受益所有人**：同样需要 SVIP
- **WAF 防护**：企查查有 WAF，直接搜索 URL 会被 405 拦截，必须通过首页搜索框交互
- **数据时效性**：工商信息有滞后，最新股东变更可能未及时更新

## 参考：本会话完整案例

- 目标：中复碳芯电缆科技有限公司
- 穿透路径：中复碳芯 → 中建材联合投资(31.2%) → 中国建材集团(100%) → 国务院国资委(100%)
- 国企合计：48.32%（中建材联合投资31.20% + 哈尔滨玻璃钢研究院17.12%）
- 结论：国有控股（央企体系，最大股东群体为国有资本）

## 关联文档

- `due-diligence-framework.md` — **当前首选**：完整 16 维度尽调框架，含天眼查操作流程、数据采集要点、风险等级标记
- `enterprise-platforms-comparison.md` — 天眼查/企查查/企业预警通三家平台实测对比
- SKILL.md「综合尽职调查自动化流程」章节 — Hermes 自动化执行流程