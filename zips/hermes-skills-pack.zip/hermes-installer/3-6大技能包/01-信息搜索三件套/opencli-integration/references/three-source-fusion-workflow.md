# 三源融合尽调工作流

> 创建日期：2026-07-12 | 最后更新：2026-07-12

## 概述

天眼查（主数据源）+ 企业预警通（风险专项）+ 企查查（交叉验证）的三源自动化融合尽调流程。

## 前置条件

- Chrome 运行 + OpenCLI 扩展已连接（`opencli doctor` 通过）
- 若需企查查：用户主 Chrome 已登录企查查 + Chrome 已带 `--remote-debugging-port=18800` 启动或使用 `bind`

## 执行顺序（必须按此顺序执行 — graceful degradation 设计）

```
Step 0: 检查环境
  opencli doctor
  如扩展断连 → 自愈流程（见 chrome-extension-setup.md）

Step 1: 天眼查（主数据源 — 免登录，最稳定）
  open  → type[中间搜索框] → click[天眼一下] → extract 搜索结果 → open company/{id} → extract 全量数据
  覆盖：工商信息、股东+认缴金额、主要人员、对外投资、司法案件、经营风险、知识产权、招投标
  成功概率：~100%（无需登录）

Step 2: 企业预警通（风险专项 — 登录态持久，但非全量覆盖）
  open  → type[主体搜索框] → click[搜索按钮] → 取详情URL → open detail/enterprise/overview → extract
  覆盖：行政处罚详情（6条+340万）、近6月风险统计、信用分、科创分、舆情指数
  注意：非所有公司都有收录（如柯渡医学无数据）→ 无数据则跳过，报告标注
  成功概率：~70%（取决于该公司是否有债券/金融风险关联）

Step 3: 企查查（交叉验证 — 需登录，最脆弱）
  bind → eval搜索 → open firm/{hash} → extract
  覆盖：企查分、司法案件数、行政处罚数、经营风险、知产数量（与天眼查/预警通交叉验证）
  成功概率：~50%（依赖登录态是否有效）
```

**关键原则：** 天眼查必查（100%成功），企业预警通尝试（失败不阻塞），企查查最后（登录过期也能覆盖90%+维度）。

## 各平台操作详情

### 天眼查 (tyc.com) — 推荐搜索索引 [43]/[46]

```bash
# 打开
opencli browser tyc open "https://www.tianyancha.com/" --window background
sleep 6

# 中间搜索框输入 + 点击
opencli browser tyc type 43 "公司名"
sleep 1
opencli browser tyc click 46
sleep 5

# 取搜索结果中的公司详情URL
opencli browser tyc eval \
  "let links = document.querySelectorAll('a[href*=\"/company/\"]'); \
   for(let l of links) { if(l.textContent.trim().includes('公司简称')) return l.href; }"

# 导航到详情页
opencli browser tyc open "<company-url>" --window background
sleep 8

# extract 全量数据
opencli browser tyc extract
```

**数据提取要点**（从 `eval "document.body.innerText"` 中 regex 提取）：
- 股东信息：搜索"股东信息"和"持股比例"之间的表格
- 风险数据：搜索"自身风险""法律诉讼""经营风险"等分类标题
- 知识产权：搜索"商标信息""专利信息""软件著作权"等
- 对外投资：搜索"被投资企业名称"

### 企业预警通 (qyyjt.cn) — 推荐搜索索引 [117]/[120]

```bash
# 打开
opencli browser yj open "https://www.qyyjt.cn/" --window background
sleep 3

# 主体搜索框输入 + 点击搜索按钮
opencli browser yj type 117 "公司名"
sleep 1
opencli browser yj click 120
sleep 3

# 从搜索结果找公司详情URL
opencli browser yj eval \
  "let links = document.querySelectorAll('a[href*=\"/detail/enterprise/overview\"]'); \
   for(let l of links) { if(l.textContent.trim().includes('公司名')) return l.href; }"

# 如果返回空数组，说明企业预警通未收录该公司
# 跳过该步骤，在报告中标注

# 导航到详情页
opencli browser yj open "<detail-url>" --window background
sleep 4

# extract 全量数据
opencli browser yj extract
```

### 企查查 (qcc.com) — 需登录，优先用 bind

```bash
# 方案A：用户已打开企查查且登录 → bind
opencli browser qcc-bind bind
opencli browser qcc-bind eval "window.location.href"

# 方案B：主Chrome带远程调试
opencli browser qcc open "https://www.qcc.com/" --window background
sleep 3

# 搜索（用 eval 方式最可靠）
opencli browser qcc eval "
  let input = document.querySelector('input');
  if(input) {
    let nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeSetter.call(input, '公司名');
    input.dispatchEvent(new Event('input', { bubbles: true }));
    let btns = document.querySelectorAll('button');
    for(let b of btns) { if(b.textContent.includes('查一下')) { b.click(); break; } }
  }
"
sleep 5

# 取公司详情URL
opencli browser qcc eval \
  "let links = document.querySelectorAll('a[href*=\"/firm/\"]'); \
   for(let l of links) { if(l.textContent.trim().includes('公司名')) return l.href; }"

# 导航
opencli browser qcc eval "window.location.href = '<firm-url>'"
sleep 5
opencli browser qcc extract
```

## 实测数据映射

### 中复碳芯电缆科技有限公司（完整三源融合）

| 维度 | 天眼查 | 企业预警通 | 企查查 | 最佳来源 |
|:----|:------:|:----------:|:------:|:--------|
| 工商信息 | ✅ 完整 | ✅ 完整 | ✅ 完整 | 天眼查 |
| 股东8+金额 | ✅ 2915/1622/1600万 | ✅ 持股比例 | ✅ | 天眼查 |
| 实控人 | ⚠️ SVIP | ✅ 国务院国资委 | ⚠️ SVIP | 企业预警通 |
| 行政处罚 | 0（口径不同） | ✅ **6条340万** | 0 | **企业预警通** |
| 司法案件 | 35件 | 26件 | 26件 | 交叉参考 |
| 专利 | 155 | — | 154 | 天眼查 |
| 招投标 | 282次 | 54次(近6月) | 135次 | 天眼查 |
| 营收 | — | 14.51亿 | — | 企业预警通 |
| 科创分 | 97 | 86.34 | 90 | 各有不同 |

### 柯渡医学科技股份有限公司（仅天眼查 + 企业预警通无数据）

| 维度 | 天眼查 | 企业预警通 | 说明 |
|:----|:------:|:----------:|:-----|
| 工商信息 | ✅ 完整 | ❌ 未收录 | 天眼查覆盖 |
| 股东15+金额 | ✅ 33.35%/11.71%/... | ❌ | 天眼查覆盖 |
| 创始人持股 | ✅ 倪军6.09%+12.26% | ❌ | 天眼查覆盖 |
| 对外投资70家 | ✅ 完整列表 | ❌ | 天眼查覆盖 |
| 司法案件16件 | ✅ 23开庭/1裁判/4立案 | ❌ | 天眼查覆盖 |
| 自身风险30 | ✅ | ❌ | 天眼查覆盖 |
| 预警提醒409 | ✅ | ❌ | 天眼查覆盖 |
| 专利/商标/软著 | ✅ 39/39/60 | ❌ | 天眼查覆盖 |
| 招投标999+ | ✅ | ❌ | 天眼查覆盖 |

**结论：** 即使企业预警通无数据，天眼查单一来源仍能覆盖95%+尽调维度。三源融合是"有则更好，无则不卡"的设计。

## 常见问题

### 索引 [N] 不匹配

页面索引每次加载可能变化。用以下 fallback：

```bash
# 天眼查 — eval CSS 选择器
opencli browser tyc eval "document.querySelector('input[placeholder*=\"请输入公司名称\"]').dataset?.index || 'fallback'"

# 企业预警通 — eval 找搜索框
opencli browser tyc eval "document.querySelectorAll('input')[2]?.placeholder"  # 第二个input通常是主体搜索框
```

### 企查查 bind 后 URL 变成 about:blank

说明 session 被关闭了。重新 bind：

```bash
opencli browser <old-session> unbind
opencli browser <new-session> bind
```

### 数据不一致问题的处理

三个平台的数据可能不一致（如天眼查35件司法案件 vs 预警通26件），原因：
- **统计口径不同**：有的算全部案件，有的只算"本公司和分公司"
- **更新频率不同**：有的每天更新，有的每周
- **分类方式不同**：有的把劳务纠纷也算入，有的不算

**处理原则**：
1. 优先采用**详细的来源**（如企业预警通的行政处罚含文号/处罚机关/法律依据）
2. 数量级接近时取**最大值**作为"可能存在"的风险
3. 明确标注数据来源差异

### 弹窗处理

搜索过程中可能遇到 VIP 弹窗/开通邀请：
- 通常不影响数据提取（extract 仍能获得页面主要内容）
- 如需关闭：找 `.close-button` 或 `.modal-close` 类点击
- 不要关闭标签页（会导致 session 丢失）

### eval 变量名冲突

同一 session 多次 `eval` 调用时，变量名会残留。每次用不同变量名或用 IIFE 包裹：

```bash
# 错误（第二次调用报错）
opencli browser s eval "let data = ...; JSON.stringify(data)"
opencli browser s eval "let data = ...; JSON.stringify(data)"  # SyntaxError!

# 正确
opencli browser s eval "let data1 = ...; JSON.stringify(data1)"
opencli browser s eval "let data2 = ...; JSON.stringify(data2)"
# 或
opencli browser s eval "(function(){ let d = ...; return JSON.stringify(d); })()"
```