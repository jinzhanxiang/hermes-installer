# OpenCLI Chrome 扩展设置指南

## 前置条件

- Node.js >= 20（本机 v24.15.0）
- Chrome 或 Chromium 浏览器
- OpenCLI 已安装：`npm install -g @jackwener/opencli`

## 当前状态（2026-07-12）

| 组件 | 状态 |
|------|------|
| OpenCLI CLI | ✅ v1.8.6 已安装 |
| Daemon | ✅ 自动运行（端口 19825） |
| Chrome 扩展 | ✅ 已从本地加载 |

Daemon 在 OpenCLI 命令首次调用时自动启动。

## 安装 Chrome 扩展

### ⚠️ Chrome Web Store 被墙（中国大陆）

https://chromewebstore.google.com/detail/opencli/ildkmabpimmkaediidaifkhjpohdnifk

从中国大陆无法访问，只能手动加载。

### 手动加载（唯一可行方式）

扩展文件已解压到 `~/Downloads/opencli-extension-v1/`。

```bash
# 第一次安装（或 force-kill 后重装）
# 打开扩展页面
osascript -e 'tell application "Google Chrome" to set URL of active tab of window 1 to "chrome://extensions"'

# 然后手动操作：
# 1. 开启右上角「开发者模式」
# 2. 点击左上角「加载已解压的扩展程序」
# 3. 选择 ~/Downloads/opencli-extension-v1
```

### 自动加载尝试（均失败）

| 方法 | 结果 | 原因 |
|------|------|------|
| `--load-extension` 命令行参数 | ❌ 扩展不连 daemon | Chrome 后台启动时参数传递不可靠 |
| 修改 Chrome Preferences 注册扩展 | ❌ Chrome 启动后覆盖 | Chrome 内部管理 Preferences，外部修改无效 |
| 复制到 Chrome Extensions 目录 | ❌ 同上 | Chrome 启动时校验扩展目录，不一致则删除 |

**结论：必须通过 Chrome UI 手动加载一次。** 加载后只要不 force-kill，扩展会持续可用。

## 验证连接

```bash
export PATH="$HOME/.npm-global/bin:$PATH"
opencli doctor

# 期望输出：
# [OK] Daemon: running on port 19825 (v1.8.6)
# [OK] Extension: connected (v1.0.22)
# [OK] Connectivity: connected in 0.1s
```

## ⚠️ 扩展持久化机制（关键发现）

### 正常重启 ✅ — 扩展保留

```bash
# ✅ 正确：正常退出 Chrome
osascript -e 'quit app "Google Chrome"'

# 然后重新打开
open -a "Google Chrome"
```

"已解压的扩展程序"信息保存在 Chrome 的 Preferences 文件中。正常退出时 Chrome 会保存 Preferences，扩展注册保留。

### 强制杀 ❌ — 扩展丢失

```bash
# ❌ 错误：force-kill 会损坏 Preferences
pkill -9 -f "Google Chrome"
```

`SIGKILL` 导致 Chrome 无法保存 Preferences 文件，扩展注册信息丢失。下次启动时 Preferences 恢复到旧版本，扩展消失。

**永远不要 `pkill -9` Chrome。** 必须用 `osascript` 正常退出。

### 恢复步骤

如果扩展丢失（`opencli doctor` 显示 `Extension: not connected`）：

```bash
# 1. 打开扩展页面
osascript -e 'tell application "Google Chrome" to set URL of active tab of window 1 to "chrome://extensions"'

# 2. 如果扩展卡片还在 → 点击右下角刷新按钮 🔄
# 3. 如果扩展卡片不在 → 重新「加载已解压的扩展程序」
#    选择 ~/Downloads/opencli-extension-v1

# 4. 重启 daemon 并验证
opencli daemon restart
sleep 3
opencli doctor
```

### 自动恢复步骤（Hermes 自愈流程 — 已验证 2026-07-12）

**核心发现：** 用 AppleScript 打开 `chrome://extensions` 页面会**自动唤醒所有已加载扩展的 service worker**，扩展随后自动扫描本地 daemon 并重连。**不需要手动点击刷新按钮。**

当 `opencli doctor` 显示 `Extension: not connected` 时，按以下顺序自动尝试：

```bash
# 步骤1：检查 Chrome 是否运行
pgrep -i "Google Chrome" > /dev/null

# 步骤2：未运行 → 正常启动
if [ $? -ne 0 ]; then
  open -a "Google Chrome"
  sleep 5
fi

# 步骤3：重启 daemon（清除 stale 连接状态）
opencli daemon restart
sleep 2

# 步骤4：打开 chrome://extensions 唤醒扩展 service worker（已验证关键步骤）
# 这会触发扩展 service worker 苏醒 → 自动扫描 daemon → 建立连接
osascript -e '
tell application "Google Chrome"
    activate
    open location "chrome://extensions"
    delay 3
end tell
'
sleep 2

# 步骤5：再次检查
opencli doctor

# 步骤6：仍不行 → 彻底重启 Chrome + daemon（全链路刷新）
if [ $? -ne 0 ]; then
  osascript -e '\''quit app "Google Chrome"'\''
  sleep 2
  open -a "Google Chrome"
  sleep 5
  opencli daemon restart
  sleep 3
  opencli doctor
fi
```

### 恢复检查表

| 症状 | 操作 | 预期结果 |
|------|------|---------|
| Chrome 打开但扩展断连 | `opencli daemon restart` → `opencli doctor` | 扩展重连 |
| daemon 已重启仍断连 | osascript 打开 chrome://extensions 唤醒 service worker（已验证） | **自动唤醒重连**（无需手动点击） |
| Chrome 被 pkill -9 杀过 | 用户需重新在 chrome://extensions → 加载 `~/Downloads/opencli-extension-v1/` | 扩展注册已丢失，必须重加载 |
| Chrome 正常重启后扩展未连 | 用 AppleScript 打开 chrome://extensions（无需手动操作） | 自动唤醒 |
| 扩展重连后 cookie 命令仍 AUTH_REQUIRED | 让用户登录对应站点 | 登录态过期 |

## 多 Chrome Profile

```bash
opencli profile list          # 查看已连接的 profile
opencli profile rename <id> <alias>  # 给 profile 命名
opencli profile use <alias>   # 设为默认
```

只有一个 profile 时自动使用。

## 常见问题

| 问题 | 解决 |
|------|------|
| Daemon running 但 Extension disconnected | 重启 daemon：`opencli daemon restart` → 再查 doctor。还不行就检查 Chrome 是否打开 |
| 扩展被 force-kill 后丢失 | 打开 `chrome://extensions` → 重新「加载已解压的扩展程序」|
| 扩展在 Chrome 重启后未自动连 | 打开 `chrome://extensions` → 找到 OpenCLI 卡片 → 点击右下角刷新按钮 |
| cookie 命令提示 AUTH_REQUIRED (exit 77) | 扩展正常，但目标站点未登录。用 Chrome 打开该站点并登录 |
| cookie 命令提示 BROWSER_CONNECT (exit 69) | Chrome 未打开或扩展未连。先开 Chrome，等几秒重试 |
| cookie 命令超时（20s+） | cookie 模式需要开 Chrome 标签页。terminal 设 30-60s 超时 |