# 天眼查风险信息提取工作流

## 适用场景

查询非上市公司的司法风险、经营风险、历史风险时，使用天眼查（tyc.com）获取最详细的风险数据。

## 完整工作流

### 第1步：预检 Chrome 扩展

```bash
export PATH="$HOME/.npm-global/bin:$PATH"
opencli doctor
# 若扩展断连 → 重启 daemon 或 AppleScript 打开 chrome://extensions
```

### 第2步：打开天眼查并搜索

```bash
# 打开首页
opencli browser tyc open "https://www.tianyancha.com/" --window background
sleep 5

# 获取页面状态，找到中间搜索框
opencli browser tyc state
# 注意：使用中间搜索框 [43]，不是顶部搜索框 [20]
# 顶部搜索框可能不触发 React 导航跳转

# 输入公司名
opencli browser tyc type 43 "公司完整名称"
opencli browser tyc click 47   # 中间"天眼一下"按钮
sleep 5

# 确认已跳转
opencli browser tyc eval "document.title + ' | ' + window.location.href"
```

### 第3步：进入公司详情页

```bash
# 获取搜索结果中的公司链接
opencli browser tyc eval \
  "let links = document.querySelectorAll('a[href*=\"/company/\"]'); \
   let r = []; for(let l of links) { if(l.innerText.includes('公司简称')) r.push(l.href); } \
   r.join('\n')"

# 打开公司详情页
opencli browser tyc open "<公司URL>" --window background
sleep 8
```

### 第4步：提取风险数据

```bash
# 全量文本提取（最可靠的方式）
opencli browser tyc eval "document.body.innerText.substring(0, 8000)"
```

### 第5步：解析风险数据

从提取的文本中解析以下字段：

**概览：**
- 自身风险: N
- 周边风险: N
- 历史风险: N
- 预警提醒: N
- 天眼评分: XX分

**法律诉讼（活性）：**
- 司法案件 N
- 开庭公告 N
- 裁判文书 N
- 法院公告 N
- 限制消费令 N（0=安全）
- 失信被执行人 N（0=安全）
- 被执行人 N（0=安全）
- 股权冻结 N（0=安全）
- 立案信息 N
- 破产案件 N（0=安全）

**经营风险（活性）：**
- 行政处罚 N（0=安全）
- 环保处罚 N（非0=合规问题）
- 经营异常 N（0=安全）
- 欠税公告 N（0=安全）
- 严重违法 N（0=安全）

**历史风险：**
- 历史股权冻结 N
- 历史经营异常 N
- 历史行政处罚 N
- 历史被执行人 N
- 历史限制消费令 N
- 历史失信被执行人 N

**最近动态：**
- 搜索 `2026-` 日期前缀获取最近事件
- 搜索 `新增开庭`、`新增招投标` 等关键词

### 第6步：风险等级判断

| 信号 | 严重程度 | 操作 |
|------|---------|------|
| 被执行人 > 0 | 🔴 高 | 重点关注，建议进一步查看裁判文书 |
| 失信被执行人 > 0 | 🔴 高 | 严重违约，需警惕 |
| 限制消费令 > 0 | 🟡 中 | 法人被限高，影响经营 |
| 开庭公告 > 10 | 🟡 中 | 诉讼频繁，经营不稳定 |
| 案由含"损害公司债权人利益" | 🔴 高 | 债权人追索，偿债能力存疑 |
| 历史股权冻结 > 0 | 🟡 中 | 历史上股权不稳定 |
| 历史行政处罚 > 0 | 🟢 低 | 已消除，但反映合规历史 |
| 环保处罚 > 0 | 🟡 中 | 环保合规风险 |

## 输出格式

最终向用户输出风险报告时，使用以下格式：

```
### ⚠️ 公司名 风险警示报告

**概览：** 自身风险 N / 周边风险 N / 历史风险 N / 预警提醒 N

**🔴 重点关注风险：**
1. 最严重的风险项（含具体数据）
2. 次严重的风险项

**🟡 中等级风险：**
- 风险项列表

**🟢 未发现的风险（正面信号）：**
- 被执行人 0 ✅
- 失信被执行人 0 ✅
...

**📋 总体判断：**
总体经营状态 + 需关注的风险信号 + 建议
```