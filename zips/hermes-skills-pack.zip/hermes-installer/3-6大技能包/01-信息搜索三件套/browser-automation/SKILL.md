---
name: browser-automation
description: |
  Automate web browsers for data extraction, form filling, and multi-step
  workflows using Hermes built-in browser tools (browser_navigate etc.),
  OpenCLI browser (Chrome), or browser-use library. Features multi-path
  orchestrator (Planner+N路Navigator with auto-fallback), browser-registry
  for extensibility, CloakBrowser anti-detection integration, LLM provider
  configuration (MiniMax Anthropic, DeepSeek), and anti-crawling workarounds.
version: 2.0.0
metadata:
  hermes:
    tags: [browser, automation, scraping, web, china]
    related_skills: [llm-json-output-parsing, computer-use, hermes-tooling-integration]
---

# Browser Automation

## Overview

Hermes 提供两层浏览器自动化能力，按需选择：

| 层 | 工具 | 适用场景 | 反检测 |
|:--|:----|:--------|:------|
| **内置浏览器工具** | `browser_navigate` / `browser_click` / `browser_snapshot` 等 | 单页浏览、截图、信息提取、表单操作 | ✅ 已集成 CloakBrowser（见下文） |
| **browser-use 库** | 通过 `execute_code` 调用 | 多步骤复杂工作流（搜索→点击→滚动→提取） | ❌ 需自行配置 |

### CloakBrowser 反检测集成

[CloakBrowser](https://github.com/CloakHQ/CloakBrowser) 是 Chromium 源码级反检测浏览器（MIT 开源，**30/30 反检测全绿**），已通过环境变量无缝集成到 Hermes 内置浏览器工具：

```bash
pip install cloakbrowser               # 安装 Python 包
# 国内下载需 ghproxy 镜像加速（~200MB）
```

在 `~/.hermes/.env` 中设置：

```
AGENT_BROWSER_EXECUTABLE_PATH=/Users/jinzhanxiang/.cloakbrowser/chromium-145.0.7632.109.2/Chromium.app/Contents/MacOS/Chromium
```

**设置后 Hermes 全部浏览器工具自动使用 CloakBrowser 内核，零代码改动。** 通过 `browser_navigate` 打开的页面会获得源码级反检测能力（`navigator.webdriver=false`、`chrome` 对象正常、plugins 和 mimeTypes 真实）。

| 反检测检查 | CloakBrowser 结果 |
|:----------|:-----------------|
| `navigator.webdriver` | `false` ✅ |
| `navigator.plugins.length` | `5` ✅ |
| `typeof chrome` | `"object"` ✅ |
| UserAgent | `Chrome/145` ✅ |

### 何时用哪个

- **日常浏览/信息提取** → Hermes 内置浏览器工具（+ CloakBrowser 反检测）
- **多步骤复杂工作流** → `browser-use`（Python 库，84k+ GitHub stars），通过 `execute_code` 或独立 Python 脚本调用

## When to Use

- **Data extraction** from websites that require JavaScript rendering
- **Multi-step workflows** (search → click → scroll → extract)
- **Form filling** and login automation
- **Site monitoring** — periodic checks via cron

## Planner-Navigator 多 Agent 架构（NanoBrowser 模式）

> 来源：NanoBrowser（13k+ ⭐ GitHub）— 开源 Chrome 扩展，AI Agent 通过 Planner + Navigator 双 Agent 协执行复杂网页任务。

对于复杂多步骤浏览器任务（跨页面调研、多来源聚合、有条件分支的导航），推荐使用 **Planner + Navigator 双 Agent 分工**，而非单 Agent 硬跑到底。核心思想：**Planner 思考做什么，Navigator 动手执行**。

### 架构

| Agent | 职责 | 使用场景 |
|:-----|:-----|:---------|
| **Planner** | 分析页面状态，规划下一步策略，判断是否调整方向 | 初始任务解析、遇到意外页面时重规划、最终结果审核 |
| **Navigator** | 执行具体浏览器操作（点击、输入、跳转、提取），向 Planner 汇报结果 | 所有实际的 DOM 交互 |

### 工作流

```
用户指令 → Planner 拆解为步骤序列
    ↓ (第 1 步)
Navigator 执行操作 → 报告页面状态和提取结果
    ↓ (第 2 步)
Planner 判断结果是否符合预期 → 继续/调整策略/终止
    ↓ 循环 ...
Navigator 执行下一步 → ...
    ↓
Planner 验收 → 返回最终结果
```

### 适用场景与不适用场景

| 适合（用 Planner-Navigator） | 不适合（单 Agent 更好） |
|:----|:------|
| 跨页面调研（搜索多个关键词、合并结果） | 单页面简单提取（如取标题、取一段文字） |
| 页面结构不确定（搜索结果变化、弹窗遮挡、需要判断） | 已知稳定的重复任务（传统脚本更可靠） |
| 需要中途判断（信息不够 → 换搜索词 → 再试） | 毫秒级响应操作 |
| 多来源信息聚合（从多个网站提取并对比） | 一次性导航（打开固定 URL 即可） |

### 实现方式

#### 方式 A：Hermes delegate_task（推荐）— 多路径编排器（含基础设施自动初始化）

这是升级后的 Planner-Navigator 模式，Planner 不再只规划步骤，而是**同时做路径选择**。读取 `references/browser-registry.md`（浏览器路径注册中心），自动了解所有可用路径。

**核心增强：路径切换前自动初始化所需基础设施。**

#### 初始化清单

| 路径 | 需要初始化 | 自动执行 |
|:----|:----------|:--------|
| **cloak** | 无需初始化，始终可用 | — |
| **opencli** | 扩展可能断连 | navigate to `chrome://extensions` → Cmd+R → `opencli daemon restart` |
| **browseruse** | 需确认库可用 | `pip show browser-use` 检查 |
| **cdp** | Chrome 可能无调试端口 | 启动 Chrome 带 `--remote-debugging-port=9222` |
| **playwright-mcp** | 首次需下载 Chromium 二进制 | `npx playwright install chromium` |

**前置步骤：读取浏览器注册表 + 检测可用路径**

```bash
# 动态获取当前哪些浏览器路径可用
bash scripts/check_browser_paths.sh
# → cloak: available
# → opencli: available (extension not connected)    ← 知道扩展状态
# → browseruse: partially available
# → cdp: unavailable (Chrome without debug port)     ← 知道为什么不可用
```

**完整编排循环（含初始化）：**

```python
# ═══ Step 0: 读取可用路径 ═══
available_paths = terminal(command="bash scripts/check_browser_paths.sh")

# ═══ Step 1: Planner 选择路径 + 规划 ═══
plan = delegate_task(
    goal="""你是 **Planner**。用户需要：{用户目标}。
    
当前可用浏览器路径：
{available_paths}

请选择 BEST 路径，考虑是否需要登录、反爬强度、任务复杂度。

返回 JSON（纯 JSON）：
{"selected_path": "cloak|opencli|browseruse|cdp|playwright-mcp",
 "reason": "选择理由",
 "steps": ["步骤1", "步骤2", "..."],
 "fallback_if_fails": "下一候选路径",
 "needs_init": true|false,        # 是否需要初始化基础设施
 "init_type": "opencli|cdp|playwright|none"  # 初始化类型
}""",
    context=f"当前页面状态：{{browser_snapshot 摘要}}",
    toolsets=["browser", "terminal"]
)

# ═══ Step 1.5: 基础设施初始化（在 Navigator 执行前） ═══
if plan.get('needs_init'):
    if plan['selected_path'] == 'opencli':
        # OpenCLI 扩展唤醒流程（已验证可行 2026-07-15）
        terminal("""
            echo "🔧 初始化 OpenCLI 扩展..."
            export PATH="$HOME/.npm-global/bin:$PATH"
            # 1. 导航到 chrome://extensions 唤醒 service worker
            osascript -e 'tell application "Google Chrome" to open location "chrome://extensions"'
            sleep 4
            # 2. Cmd+R 刷新扩展
            osascript -e 'tell application "System Events" to tell process "Google Chrome" to keystroke "r" using command down'
            sleep 2
            # 3. 重启 daemon 触发重连
            opencli daemon restart
            sleep 3
            # 4. 验证
            opencli doctor
        """)
        # 验证
        doctor_check = terminal("export PATH=$HOME/.npm-global/bin:$PATH && opencli doctor")
        if "Extension: connected" not in doctor_check:
            # 如果还不通，通知用户手动刷新
            delegate_task(goal="OpenCLI 扩展自动唤醒失败，请用户在 Chrome 中打开 chrome://extensions 页面刷新扩展")

    elif plan['selected_path'] == 'cdp':
        # Chrome CDP 端口初始化
        terminal("""
            echo "🔧 启动 Chrome 带远程调试端口..."
            if ! curl -sf http://localhost:9222/json/version > /dev/null 2>&1; then
                osascript -e 'quit app "Google Chrome"'
                sleep 3
                open -a "Google Chrome" --args \\
                    --remote-debugging-port=9222 \\
                    --no-first-run --no-default-browser-check
                sleep 5
            fi
        """)

    elif plan['selected_path'] == 'playwright-mcp':
        # Playwright 浏览器初始化
        terminal("""
            echo "🔧 确保 Playwright 浏览器已安装..."
            npx playwright install chromium 2>/dev/null
        """)

    # 其他路径无需初始化

# ═══ Step 2: Navigator 按选定路径执行 ═══
if plan['selected_path'] == 'cloak':
    result = delegate_task(
        goal=f"用 Hermes 浏览器工具（browser_navigate/click/console）执行：{plan['steps']}",
        toolsets=["browser"]
    )
elif plan['selected_path'] == 'opencli':
    # 初始化已完成，直接执行
    result = delegate_task(
        goal=f"""用 OpenCLI browser 执行：{plan['steps']}
操作：opencli browser <session> open/type/click/eval""",
        toolsets=["terminal"]
    )
elif plan['selected_path'] == 'browseruse':
    result = delegate_task(
        goal=f"""用 browser-use 执行：{plan['steps']}
使用 ChatAnthropic 类 + MiniMax Anthropic 接口""",
        toolsets=["terminal", "execute_code"]
    )
elif plan['selected_path'] == 'cdp':
    # 初始化已完成
    result = delegate_task(
        goal=f"用 browser_cdp 工具执行：{plan['steps']}",
        toolsets=["browser"]
    )
elif plan['selected_path'] == 'playwright-mcp':
    # MCP 工具已注册，可直接调用
    result = delegate_task(
        goal=f"""用 Playwright MCP 工具执行：{plan['steps']}
可用工具：mcp_playwright-mcp_browser_navigate / mcp_playwright-mcp_browser_click / mcp_playwright-mcp_browser_snapshot / mcp_playwright-mcp_browser_find
browser_find 可在无障碍快照中按文本搜索，比全量 snapshot 省 Token""",
        toolsets=["browser"]
    )

# ═══ Step 3: Planner 验收（失败则初始化+切换路径） ═══
MAX_RETRIES = 5
STUCK_THRESHOLD = 3
cycle = 0
consecutive_stuck = 0
last_summary = ""
used_paths = []
verdict = None

while cycle < MAX_RETRIES:
    cycle += 1
    used_paths.append(plan['selected_path'])

    # Step 3: Planner 验收
    verdict = delegate_task(
        goal=f"""你是 **Planner**。路径：{plan['selected_path']}
之前计划：{plan}
执行结果：{result}
用户目标：{用户目标}

已尝试过的路径：{used_paths}
可用但未试的路径：{plan.get('fallback_if_fails', 'none')}

目标达成了吗？返回 JSON：
{{"done": bool,
  "next_action": "..." if not done else null,
  "summary": "...",
  "need_fallback": bool,
  "suggested_path": "opencli|cloak|..." if need_fallback,
  "needs_init": true|false,
  "init_type": "opencli|cdp|none"}}""",
        toolsets=["browser", "terminal"]
    )

    if isinstance(verdict, dict) and verdict.get('done'):
        break

    # 需要切换路径？
    if isinstance(verdict, dict) and verdict.get('need_fallback'):
        new_path = verdict.get('suggested_path', plan.get('fallback_if_fails'))
        if new_path and new_path not in used_paths:
            plan['selected_path'] = new_path
            
            # 初始化新路径的基础设施
            if verdict.get('needs_init'):
                if new_path == 'opencli':
                    terminal("export PATH=$HOME/.npm-global/bin:$PATH && osascript -e 'tell application \"Google Chrome\" to open location \"chrome://extensions\"' && sleep 4 && osascript -e 'tell application \"System Events\" to tell process \"Google Chrome\" to keystroke \"r\" using command down' && sleep 2 && opencli daemon restart && sleep 3")
                elif new_path == 'cdp':
                    terminal("osascript -e 'quit app \"Google Chrome\"' && sleep 2 && open -a 'Google Chrome' --args --remote-debugging-port=9222 && sleep 4")
                elif new_path == 'playwright-mcp':
                    terminal("npx playwright install chromium 2>/dev/null")
            
            # 用新路径重新执行
            if new_path == 'cloak':
                result = delegate_task(goal=f"用 Hermes 浏览器工具重试：{plan['steps']}", toolsets=["browser"])
            elif new_path == 'opencli':
                result = delegate_task(goal=f"用 OpenCLI browser 重试：{plan['steps']}", toolsets=["terminal"])
            elif new_path == 'browseruse':
                result = delegate_task(goal=f"用 browser-use 重试：{plan['steps']}", toolsets=["terminal", "execute_code"])
            elif new_path == 'playwright-mcp':
                result = delegate_task(goal=f"用 Playwright MCP 工具重试：{plan['steps']}", toolsets=["browser"])
            continue

    # 卡住检测
    current_summary = verdict.get('summary', '') if isinstance(verdict, dict) else ''
    if current_summary and current_summary == last_summary:
        consecutive_stuck += 1
    else:
        consecutive_stuck = 0
    last_summary = current_summary

    if consecutive_stuck >= STUCK_THRESHOLD:
        delegate_task(goal=f"告知用户：浏览器自动化在路径 {plan['selected_path']} 卡住")
        break

# 全部尝试失败
if cycle >= MAX_RETRIES or not (isinstance(verdict, dict) and verdict.get('done')):
    delegate_task(goal=f"告知用户：{len(used_paths)} 条浏览器路径均已尝试但仍未完成：{used_paths}")
```

#### 关键行为总结

| 阶段 | 操作 |
|:----|:----|
| **路径选择** | Planner 读 registry → 根据站点需登录否、反爬强度、任务复杂度选最佳路径 |
| **执行** | Navigator 用选定路径的工具执行操作 |
| **验收** | 成功 → 结束。失败 → Planner 选下一条路径重试 |
| **全部失败** | 告知用户所有路径都尝试过了，附详细失败原因 |

#### 路径选择参考表

| 场景 | 推荐路径 | 理由 |
|:----|:--------|:----|
| 天眼查查询（免登录） | **cloak** | 30/30 反检测，免登录，已验证可用 |
| 企查查查询（需登录） | **opencli** | 共享 Chrome 登录态，绕过 405 |
| 企业预警通查询 | **opencli** | 需要 APP 扫码登录态 |
| 简单导航取标题 | **cloak** 或 **browseruse** | 简单任务都可胜任 |
| 需要在快照中搜索元素 | **playwright-mcp** | browser_find 按需检索，节省 Token |
| 移动端页面测试 | **playwright-mcp** | 支持 --mobile --device 模拟 |
| 需要 CDP 协议操作 | **cdp** | 直接控制 Chrome DevTools |
| 其他所有浏览器任务 | **cloak**（默认） | 始终可用，无需配置 |

#### ⚡ 关键 pitfall：Snapshot 截断时用 JS 兜底

**2026-07-15 实测发现：** 天眼查搜索结果页的 snapshot 在 `element_count=708` 时被截断，无法通过 `browser_snapshot` 找到结果链接。

**解决方案（已验证可行）：** Planner 发现 snapshot 不可用时，改用 `browser_console(expression=...)` 直接查询 DOM：

```python
# Planner 发现 snapshot 截断后，走 JS 兜底
links = browser_console(expression="""
Array.from(document.querySelectorAll('a'))
  .filter(a => a.textContent.includes('公司名'))
  .slice(0,3)
  .map(a => ({text: a.textContent.trim().slice(0,100), href: a.href}))
""")

# Navigator 用结果链接继续
browser_navigate(links[0]['href'])
```

**什么时候用 JS 兜底：**
- `browser_snapshot` 返回的元素数接近或达到 `element_count` 上限
- 目标内容（如表格、列表、搜索结果）在 snapshot 中不可见
- 页面是 SPA 但 DOM 已渲染完整

**不要什么时候用：** 简单页面、snapshot 已清晰显示目标元素时——优先用 snapshot + ref 点击。

#### 方式 B：browser-use 双 Agent（Python 方案）— Anthropic 接口模式（推荐）

当前 DeepSeek API Key 已失效，推荐用 MiniMax Anthropic 接口模式：

```python
from browser_use.llm.anthropic.chat import ChatAnthropic

# 使用 MiniMax 的 Anthropic 兼容接口
# 优势：thinking 是结构化 block，browser-use 自动剥离，无需 monkey-patch
llm = ChatAnthropic(
    model='MiniMax-M2.7',
    api_key='<MINIMAX_API_KEY>',
    base_url='https://api.minimaxi.com/anthropic',
    max_tokens=4096,
    temperature=0.1
)

# 简单任务验证（导航+读取标题已验证通过）
agent = Agent(
    task="请打开 https://example.com 并告诉我页面标题",
    llm=llm,
    use_vision=False,
    max_steps=5
)
```

**备选：DeepSeek**（原生支持 tool calling，格式更稳定，但 Key 已失效需续费）

```python
# 仅当 DeepSeek Key 有效时使用
planner_llm = openai_chat.ChatOpenAI(
    model='deepseek-chat',
    base_url='https://api.deepseek.com/v1',
    api_key='<DEEPSEEK_API_KEY>'
)
navigator_llm = openai_chat.ChatOpenAI(
    model='MiniMax-M2.7',
    base_url='https://api.minimaxi.com/v1',
    api_key='<KEY>',
    dont_force_structured_output=True
)
```

#### ⚡ 2026-07-15 实测：browser-use + MiniMax Anthropic 接口模式

**之前结论有误，更正如下：**

| 接口模式 | 状态 | 实测结果 |
|:--------|:----|:---------|
| **MiniMax OpenAI 兼容接口** (`/v1/chat/completions`) | ⚠️ | 可以跑，但 thinking 标签嵌入 content 字符串，需 monkey-patch 剥离 |
| **MiniMax Anthropic 兼容接口** (`/v1/messages`) | ✅ **推荐** | 原生支持！browser-use 的 `ChatAnthropic` 类直接可用 |

**配置方式：**

```python
from browser_use.llm.anthropic.chat import ChatAnthropic

llm = ChatAnthropic(
    model='MiniMax-M2.7',
    api_key='<MINIMAX_API_KEY>',
    base_url='https://api.minimaxi.com/anthropic',
    max_tokens=4096,
    temperature=0.1
)
```

**关键优势：** Anthropic 接口的 thinking 是结构化 block（`type: "thinking"`），browser-use 的 `_extract_content_blocks()` 自动剥离，无需 monkey-patch。文本输出天然干净。

**⚠️ 限制：** MiniMax-M2.7 模型的 tool calling 精度有限，简单任务（导航+读取标题）可完成，复杂多步骤任务（搜索→点击→提取）可能因输出格式不匹配 Pydantic schema 而失败。**复杂任务推荐用 Hermes delegate_task（方式 A）。**

**替代方案：** 如果确实需要 browser-use 执行复杂任务，建议：
- 使用 DeepSeek（原生支持 tool calling，格式稳定）
- 或使用 OpenAI/Anthropic 等原生支持的模型

### 多模型组合策略

| 任务类型 | 推荐模型 | 原因 |
|:---------|:---------|:-----|
| 复杂规划（跨页面、多条件判断） | **DeepSeek / Claude** | 推理能力强，JSON 输出稳定 |
| 普通导航（点击、输入、提取） | **MiniMax-M2.7** | 便宜，单步操作足够 |
| 隐私敏感任务 | **Ollama 本地模型** | 数据不出本机 |
| 企业内部环境 | **自定义 OpenAI-compatible 网关** | 统一管理 |

### 实战案例：天眼查企业查询（对比）

| 步骤 | 单 Agent | Planner-Navigator |
|:----|:--------|:------------------|
| 任务 | "查宁德时代基本信息" | 同上 |
| 执行 | 一次性调用，如果中间出错了整个重来 | Planner 拆成 4 步，每步可独立重试 |
| 页面弹窗 | 可能卡住（MiniMax thinking 不输出 action） | Navigator 汇报"弹窗挡住了" → Planner 说"关闭弹窗" |
| 结果不理想 | 无调整机会 | Planner 判断"搜索结果不精确" → "换关键词重搜" |
| 总计 | 1 次调用 | 3-5 次调用，但成功率更高 |

## LLM Provider Configuration

### MiniMax-M2.7 (Hermes primary model)

**✅ Works for simple tasks** (single page, get title, click one element).
**❌ Struggles with complex multi-step tasks** (long thinking chains, no action output).

```python
from browser_use import Agent
from browser_use.llm.openai import chat as openai_chat
from browser_use.browser.profile import BrowserProfile

llm = openai_chat.ChatOpenAI(
    model='MiniMax-M2.7',
    api_key='<MINIMAX_API_KEY>',
    base_url='https://api.minimaxi.com/v1',  # MUST include /v1
    dont_force_structured_output=True         # Avoid JSON schema issues
)
```

### Thinking Tag Stripping (Mandatory)

MiniMax embeds `` / `>` tags in JSON content, breaking Pydantic parsing.
Monkey-patch `ChatOpenAI.ainvoke` before every use:

```python
import re
from browser_use.llm.openai import chat as openai_chat
from browser_use.llm.views import ChatInvokeCompletion
from browser_use.llm.openai.serializer import OpenAIMessageSerializer
from browser_use.llm.openai.chat import ResponseFormatJSONSchema, SchemaOptimizer
from browser_use.llm.exceptions import ModelProviderError

_orig_ainvoke = openai_chat.ChatOpenAI.ainvoke

async def patched_ainvoke(self, messages, output_format=None, **kwargs):
    openai_messages = OpenAIMessageSerializer.serialize_messages(messages)
    model_params = {}
    if self.temperature is not None:
        model_params['temperature'] = self.temperature
    if self.frequency_penalty is not None:
        model_params['frequency_penalty'] = self.frequency_penalty
    if self.max_completion_tokens is not None:
        model_params['max_completion_tokens'] = self.max_completion_tokens
    if self.top_p is not None:
        model_params['top_p'] = self.top_p
    if self.seed is not None:
        model_params['seed'] = self.seed
    if self.service_tier is not None:
        model_params['service_tier'] = self.service_tier

    if output_format is not None and not self.dont_force_structured_output:
        schema = SchemaOptimizer.create_optimized_json_schema(output_format, ...)
        response_format = ResponseFormatJSONSchema(
            json_schema={'name': 'agent_output', 'strict': True, 'schema': schema},
            type='json_schema'
        )
        r = await self.get_client().chat.completions.create(
            model=self.model, messages=openai_messages,
            response_format=response_format, **model_params
        )
    else:
        r = await self.get_client().chat.completions.create(
            model=self.model, messages=openai_messages, **model_params
        )

    choice = r.choices[0] if r.choices else None
    if choice is None:
        raise ModelProviderError(message='Invalid response', status_code=502, model=self.name)

    content = choice.message.content or ''
    # Strip MiniMax thinking tags
    # Use find-last-tag pattern (handles missing closing tag)
    _tags_to_check = [
        ' response', ' response', '', ''
    ]
    _positions = [(content.rfind(t), len(t)) for t in _tags_to_check]
    _positions = [(p, l) for p, l in _positions if p >= 0]
    if _positions:
        p, l = max(_positions, key=lambda x: x[0])
        content = content[p+l:]
    cleaned = re.sub(r'<[^>]+>', '', content)
    cleaned = cleaned.strip()

    if output_format is None:
        return ChatInvokeCompletion(completion=cleaned, usage=None, stop_reason=choice.finish_reason)
    parsed = output_format.model_validate_json(cleaned)
    return ChatInvokeCompletion(completion=parsed, usage=None, stop_reason=choice.finish_reason)

openai_chat.ChatOpenAI.ainvoke = patched_ainvoke
```

### Alternative: DeepSeek

If MiniMax thinking tags cause persistent issues, switch to DeepSeek
(cleaner JSON output, no thinking tags):

```python
llm = openai_chat.ChatOpenAI(
    model='deepseek-chat',
    api_key='<DEEPSEEK_API_KEY>',
    base_url='https://api.deepseek.com/v1'
)
```

## 用户偏好：结果展示风格

用户偏好 **直接、数据驱动的结果展示**，而非冗长的叙述性报告。展示测试结果时：

1. **优先用表格对比**：Before/After 对比，关键指标一目了然
2. **先给结论，再给细节**：第一行就给出通过/不通过，后面再展开
3. **避免过度解释**：不需要解释为什么要做每个步骤，直接展示做了什么、结果是什么
4. **适当使用 emoji 标记**：✅ 通过 / ❌ 失败 / ⚠️ 部分通过，帮助快速扫描

用户询问"结果呢"时，意味着已经等待了足够久，需要立即看到测试结果——不要重新解释上下文，直接给出结果。

## Chinese-Language Convention

**⚠️ CRITICAL: ALL communication must be in Chinese.**

This is not optional — the user explicitly corrected English output.
Every single message to the user must be in Chinese:

- Task descriptions (`task="请用中文完成以下操作..."`)
- All output and extraction results
- Error messages and status reports
- **Debug summaries, technical analysis, test results** — everything
- **Conversational responses** — not just automation output

**Reason:** The user communicates in Chinese and expects Chinese responses.
Chinese websites (天眼查, 企查查, 东方财富等) render Chinese content naturally.
LLM operates better with Chinese instructions for Chinese sites.

**Enforcement:** Before sending any response, check: is every sentence
in Chinese? If you catch yourself writing English technical terms or
debug output, translate it. A single English paragraph ("here are the
results...") will trigger user frustration.

## Browser Profile Configuration

```python
from browser_use.browser.profile import BrowserProfile

profile = BrowserProfile(
    headless=True,          # Run without visible window
    disable_security=True,  # Bypass CORS restrictions
    chrome_channel='chrome', # Use system Chrome (not Chromium)
    enable_default_extensions=False  # Skip extension download (faster)
)
```

## Anti-Crawling Workarounds

Chinese business information sites (天眼查, 企查查, 企业预警通) detect automated browsers. 按优先级尝试以下方案：

### 方案一：CloakBrowser（推荐，已集成）

Hermes 已集成 CloakBrowser 反检测浏览器，**天眼查、企业预警通可直接通过**，企查查可通过 Cloudflare 层（但仍有 405 应用层拦截）。

```bash
# 确认 CloakBrowser 已生效（在 .env 中设置了 AGENT_BROWSER_EXECUTABLE_PATH）
# 直接使用 Hermes 内置浏览器工具即可，无需额外操作
browser_navigate("https://www.tianyancha.com")
```

### 方案二：非 headless 模式 + 真实浏览器 Profile

| Symptom | Likely Cause | Workaround |
|---------|-------------|------------|
| "系统检测到您的操作存在异常" | Playwright fingerprint detected | 改用 CloakBrowser（方案一）或 headless=False + 真实 Chrome profile |
| CAPTCHA / slider puzzle | Rate limiting | 在步骤之间添加延迟 |
| Login wall | Unauthenticated access | 使用官方 API 或手动登录 |
| Cloudflare 拦截 | 无代理/住宅 IP | CloakBrowser 可绕过，如仍不行需配合住宅代理 |

### 用户偏好：登录类任务走最直白路径

**用户明确反馈**：需要登录某个网站时，不要先尝试复杂的 CDP 连接、cookie 解密、跨浏览器 cookie 迁移等方案。直接用最简单的路径——

**首选：用 Hermes 内置浏览器工具直接打开登录页，让用户在页面上扫码/输入账号登录。** 登录后 session 就绑在当前浏览器上，再 `--restore` 持久化即可。

```bash
# 1. 直接用 Hermes 浏览器打开登录页（CloakBrowser 已自动集成）
browser_navigate("https://www.qyyjt.cn/user/login")

# 2. 显示登录页（扫码/账号密码），用户登录
#    - 企查查: 扫码登录页在 qcc.com/weblogin
#    - 企业预警通: 扫码登录页在 qyyjt.cn/user/login
#    - 天眼查: 扫码登录页

# 3. 登录后用 agent-browser --restore 持久化 session
npx agent-browser --restore <name> --restore-save always \
  open --url "https://目标网站"
```

**只有当直接登录方案不可行时**（例如用户已经有 Chrome 登录态、不想重新登录），才考虑 cookie 迁移 / CDP 连接等复杂方案。

### 方案三：一次性登录 + `--restore` 持久化（企查查 405 的首选方案）

企查查的 405 拦截是应用层反爬，仅靠浏览器指纹不够，还需要合法登录 session。用 `agent-browser` 的 `--restore` 功能，登录一次后自动保存 session，后续复用。

**⚠️ 关键 pitfall：`browser_navigate` 会丢失 QR 扫码登录态。**
Hermes 内置浏览器工具 (`browser_navigate`) 每次调用可能创建新的页面上下文，导致 QR 码扫码设置的 cookies 丢失。正确流程：

#### 方式 A：有界面窗口（推荐）

```bash
CLOAK_PATH="/Users/jinzhanxiang/.cloakbrowser/chromium-145.0.7632.109.2/Chromium.app/Contents/MacOS/Chromium"
# 1. 打开有界面的浏览器窗口，显示企查查登录页
npx agent-browser --executable-path "$CLOAK_PATH" --headed \
  open --url "https://www.qcc.com/weblogin"
# 2. 用户用手机微信扫屏幕上二维码登录
# 3. 关闭窗口后用 --restore 持久化
npx agent-browser --executable-path "$CLOAK_PATH" --headed \
  --restore qcc --restore-save always \
  open --url "https://www.qcc.com"
```

**⚠️ `--visible`/`--headed` 模式生命周期：** agent-browser 的 `open --visible` 命令完成后，浏览器窗口会**立即关闭**。用户无法看到 QR 码完成扫码。正确的做法是：
- 用 `wait` 命令保持窗口活跃：`agent-browser wait 300000`（5分钟）
- 或者用 `open --visible` 先打开，**然后立即**在另一个 terminal 调用中执行 `wait` 命令保持 session 存活
- `--restore-save-interval` 不是有效选项（正确：`--restore-save always`）

**不同网站的登录方式：**
| 网站 | 登录方式 | 说明 |
|:----|:---------|:-----|
| **企查查 (qcc.com)** | 手机微信扫码 | 登录页在 `qcc.com/weblogin`，二维码在 Canvas 上 |
| **企业预警通 (qyyjt.cn)** | 企业预警通 APP 扫码 | 需打开 APP → [我的-扫一扫]，登录页在 `qyyjt.cn/user/login` |

以后自动恢复：
```bash
npx agent-browser --executable-path "$CLOAK_PATH" \
  --restore qcc open --url "https://www.qcc.com"
```

#### 方式 B：Canvas 二维码截图（当无法用 `--headed` 时）

当用户无法看到有界面窗口时，可以用 Hermes 浏览器工具提取 Canvas 二维码并分享截图：

**⚠️ 工作流 pitfall：先问用户能不能直接扫码，不要先尝试复杂的技术方案。** 用户明确表达了这一偏好——只需要打开 QR 码页面让用户用手机扫码，不要先尝试 cookie 解密、CDP 连接、keychain 提取等复杂方案。这些是 QR 码方案失败后的备选，不是第一步。

```python
# 1. 用 browser_navigate 打开登录页
browser_navigate("https://www.qcc.com/weblogin")

# 2. 用 browser_console(expression=...) 提取 Canvas 二维码
# 执行: (()=>{const c=document.querySelector('canvas');if(!c)return'no canvas';return c.toDataURL('image/png')})()
# 返回 base64 data URL → 保存为.png文件

# 3. 分享截图给用户
# MEDIA:/path/to/qrcode.png

# 4. 用户扫码后，注意 QR 码过期时间短（2-3分钟）
# 如过期，刷新页面重新提取
browser_navigate("https://www.qcc.com/weblogin")
```

**⚠️ QR 码有过期时间（2-3分钟）**，过期后需重新导航页面刷新。提取二维码时先导航到登录页再立即截图，减少中间延迟。

session 自动保存到 `~/.agent-browser/restore/qcc.json`。

详见 `references/chrome-login-transfer.md` 和 `references/canvas-qrcode-extraction.md`。

#### 方式 C：Chrome CDP + cookie 注入（全自动，用户已有登录态时用）

当用户已经在 Chrome 中登录了目标站点，无需重复扫码。全自动提取 cookie 注入 CloakBrowser：

```bash
# 1. 关掉所有 Chrome（✅ 用 osascript 正常退出，❌ 别用 pkill -9）
osascript -e 'quit app "Google Chrome"'; sleep 3

# 2. 启动 Chrome 带调试端口
# ⚠️ --user-data-dir 必须指向父目录，不含 /Default
#    ❌ --user-data-dir=.../Chrome/Default → "incorrect profile type"，端口不绑定
#    ✅ --user-data-dir=.../Chrome
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --remote-debugging-port=9222 \
  --user-data-dir="/Users/jinzhanxiang/Library/Application Support/Google/Chrome" \
  --no-first-run --no-default-browser-check &

# 2b. 如果用户的主 Chrome 已在运行（GUI 实例），用独立临时 profile
# mkdir -p /tmp/chrome-debug-profile-<name>
# "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
#   --remote-debugging-port=9222 \
#   --user-data-dir="/tmp/chrome-debug-profile-<name>" \
#   --no-first-run --no-default-browser-check &
# 注意：这是空 profile，用户需要在此窗口中重新登录
# 2. 等待 Chrome 启动 → 用户扫码登录 → 提取 cookies
# 3. 通过 CDP WebSocket → Network.getCookies
# 4. npx agent-browser cookies set 逐条注入
# 5. npx agent-browser --restore qcc 持久化
```

完整脚本见 `references/chrome-login-transfer.md` →「方案二（全自动）：Chrome CDP + cookie 注入」。

### 方案四：BrowserAct stealth-extract（付费备选）

### ⚠️ Chrome Dual Instance Problem (所有CDP自动化相关)

使用 `opencli browser`、`browser-use` 或 Playwright 通过 CDP 连接 Chrome 时，**可能操作的是独立Chrome实例**，与用户主Chrome不共享登录态。

**症状：** 用户确认已登录，但自动化浏览器显示未登录/登录墙。

**根因：** 许多工具启动Chrome时使用专用 `--user-data-dir`（如 `~/.openclaw/browser/openclaw/user-data`），与主Chrome完全隔离。

**检测：**
```bash
ps aux | grep "Google Chrome" | grep -v grep | grep -v helper | head -5
# 看是否包含 --remote-debugging-port — 无此参数说明双实例问题
```

**解决：** 重启Chrome带远程调试端口：
```bash
osascript -e 'quit app "Google Chrome"'
open -a "Google Chrome" --args --remote-debugging-port=18800
```

详见 `opencli-integration` skill 的「Chrome 双实例与登录态隔离」章节。

## Pitfalls

### 1. base_url MUST include /v1
❌ `https://api.minimaxi.com` → browser-use appends `/chat/completions` → 404
✅ `https://api.minimaxi.com/v1` → browser-use appends `/chat/completions` → 200

### 2. MiniMax thinking tags break JSON parsing
MiniMax always outputs `>` / `>` tags in `content`.
The monkey-patch must strip these BEFORE Pydantic validation.

### 3. MiniMax not suitable for complex multi-step tasks
MiniMax-M2.7 outputs long thinking chains for complex tasks (search → click → extract).
It may never produce actual JSON actions. Use DeepSeek for complex tasks.

### 4. use_vision=False
MiniMax does not support vision input. Always set `use_vision=False`.

### 5. max_steps for complex tasks
Set `max_steps=15` minimum for multi-step Chinese website tasks.
MiniMax is slower than DeepSeek due to thinking chain generation.

### 6. dont_force_structured_output=True is critical
Without this flag, browser-use sends JSON schema (`response_format`) to
MiniMax, which MiniMax handles poorly — it returns empty content or wraps
JSON in thinking tags, causing Pydantic validation failure.

```python
llm = openai_chat.ChatOpenAI(
    model='MiniMax-M2.7',
    base_url='https://api.minimaxi.com/v1',
    dont_force_structured_output=True,  # ← REQUIRED
)
```

### 7. Robust cleaner for MiniMax output
The simple `re.sub(r'[\s\S]*?', '', content)` regex fails when
MiniMax outputs `>` without a closing `>` tag (common during
long thinking chains). Use the `find-last-tag` pattern:

```python
def clean_minimax(content):
    if not content:
        return ''
    # Find last  or  response tag
    positions = [(content.rfind(t), len(t)) for t in
                 [' response', ' response', '', '']]
    positions = [(p, l) for p, l in positions if p >= 0]
    if positions:
        p, l = max(positions, key=lambda x: x[0])
        content = content[p+l:]
    content = re.sub(r'<[^>]+>', '', content)
    return content.strip()
```

### 8. Chinese output for ALL interactions — including agent-to-user chat

Task descriptions, extraction results, AND your conversational responses to the user
must all be in Chinese. The user explicitly corrected English output previously.
Never assume technical English is acceptable — translate everything.

```python
task='请用中文完成以下操作：\\n1. 打开网站\\n2. 搜索信息\\n3. 用中文返回结果'
```

### 9. `kill -SIGUSR1` 在 macOS 上不能开启 Chrome 调试端口

在 Linux 上 `kill -SIGUSR1 <chrome-pid>` 可让 Chrome 开始监听调试端口，但在 macOS 上**无效**。必须杀掉 Chrome 进程后重启带 `--remote-debugging-port` 参数。

### 10. `--user-data-dir` 必须指向父目录，不能含 `/Default`

Chrome 的 `--user-data-dir` 参数期望的是**包含多个 profile 的根目录**（如 `~/Library/Application Support/Google/Chrome/`），其下有 `Default/`、`Profile 1/` 等子目录。

```bash
# ✅ 正确
--user-data-dir="/Users/jinzhanxiang/Library/Application Support/Google/Chrome"

# ❌ 错误 — 导致 "incorrect profile type"，端口 9222 不绑定
--user-data-dir="/Users/jinzhanxiang/Library/Application Support/Google/Chrome/Default"
```

### 11. Chrome 已运行时，用独立临时 profile 启动调试实例

当主 Chrome（GUI 实例）已在运行，不能用同一 `--user-data-dir` 启动第二个 Chrome。必须用独立的临时 profile：

```bash
mkdir -p /tmp/chrome-debug-profile-<name>
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --remote-debugging-port=9222 \
  --user-data-dir="/tmp/chrome-debug-profile-<name>" \
  --no-first-run --no-default-browser-check &
```

然后用 CDP 将窗口移到可见区域：
```python
import requests, json, asyncio, websockets
async def move_window():
    targets = requests.get("http://localhost:9222/json").json()
    page = [t for t in targets if t['type']=='page'][0]
    async with websockets.connect(page['webSocketDebuggerUrl']) as ws:
        # 获取窗口 ID
        await ws.send(json.dumps({"id":1, "method":"Browser.getWindowForTarget"}))
        resp = json.loads(await ws.recv())
        win_id = resp['result']['windowId']
        # 移到主屏可见区域
        await ws.send(json.dumps({"id":2, "method":"Browser.setWindowBounds", "params":{
            "windowId": win_id,
            "bounds": {"left": 100, "top": 100, "width": 1200, "height": 900}
        }}))
asyncio.run(move_window())
```

### 12. agent-browser `--visible` / `--headed` 模式无法保持窗口

`open --visible` 命令完成后浏览器窗口立即关闭，用户来不及扫码。正确做法：
- 用 `wait` 命令保持 session 活跃：`agent-browser wait 300000`
- 或启动后立即在另一个 terminal 调用中执行 `wait`
- `--restore-save-interval` 不是有效选项（正确：`--restore-save always`）

### 13. Hermes 浏览器是本地 CloakBrowser，每次会话隔离登录态

**关键事实（2026-07-14 实操验证）：** Hermes 浏览器工具 (`browser_navigate`) 默认使用 **本地 CloakBrowser**（非远程 Browserbase），CDP 端口由 Hermes 自动分配（如 `ws://127.0.0.1:54098`）。`cdp_url: ''` 是默认行为，**不代表用远程浏览器**——Hermes 自己启动 CloakBrowser。

**⚠️ 核心问题：Hermes 每次会话的 CloakBrowser 是独立隔离实例。** Hermes 用临时 `user-data-dir`（如 `/var/folders/4y/rhhg2cqj2kbgj2ys1938xm_80000gn/T/agent-browser-chrome-<uuid>`），不同 session 不共享 cookie。

**症状：** 用户扫码登录了某个 CloakBrowser 实例，但 Hermes `browser_navigate` 打开的是**另一个独立实例**（不同 CDP 端口/不同 user-data-dir），显示登录页。

**检测：**
```bash
# 获取 Hermes CDP URL
npx agent-browser get cdp-url 2>&1
# 结果: ws://127.0.0.1:<port>/devtools/browser/<uuid>

# 检查 Hermes cookies
npx agent-browser cookies get --domain qyyjt.cn 2>&1
# 只有 HWWAF cookie = 未登录；有业务 cookie = 已登录
```

**解决（需要用户扫码登录）：**
1. 用 `browser_navigate` 打开登录页
2. 用 `browser_vision` 截图 → `MEDIA:` 发送二维码给用户
3. 用户扫码后，**同一个 browser session** 内 cookie 有效
4. 用 `--restore` 持久化：`npx agent-browser --restore <name> --restore-save always`

**Pitfall**：用户说"已登录"但 Hermes 浏览器仍显示登录页 = **实例不一致**（扫了其他浏览器的码）。立即检查 Hermes CDP URL 和 cookies，不要盲目重试扫码。

### 14. 企业预警通 (qyyjt.cn) 需 APP 扫码，不是微信扫码

与企查查不同，企业预警通的登录方式是**企业预警通 APP 内扫码**，不是微信扫码：
- 提示："打开 企业预警通 APP，在【我的-扫一扫】扫描二维码登录"
- 登录页 URL: `qyyjt.cn/user/login`
- 二维码在 Canvas 上渲染
- 企业预警通全站需要登录态，任何页面都不可免登录访问

### 15. 截图必须直接发在对话中，不是给文件路径

**用户明确反馈**：当用户需要看浏览器页面（特别是登录二维码、表单等）时，**不能只给本地文件路径**（如 `~/cache/screenshot.png`）。用户要求截图以 native media 形式直接嵌入对话。

**正确做法**：

1. **通过 `browser_vision` 截图** → 返回的 `screenshot_path` 用 `MEDIA:` 前缀发送：
   ```
   MEDIA:/Users/jinzhanxiang/.hermes/cache/screenshots/browser_screenshot_*.png
   ```

2. **WeChat 渠道限制**：`MEDIA:` 图片路径在微信渠道不可见，此时用 `open -a Preview` 打开本地文件让用户在屏幕上看到。

3. **如果 `browser_vision` 失败（401 / 黑屏 / empty page）**：
   - 可能是 Hermes 内置浏览器的截图不可见
   - 改用 `agent-browser screenshot /path/to/qr.png` 在本地 CloakBrowser 上截图
   - 然后用 `MEDIA:` 发送

4. **永远不要**只回复文件路径而不附带 `MEDIA:` 或 `open` 命令。用户看不到文件路径对应的图片。

**用户反馈原文**："你需要截图直接对话的形式发给我，而不是给我本地存放地址"

### 16. `browser_vision` 401 不影响截图文件生成

`browser_vision` 调用时可能返回 `Error code: 401 - invalid api key`（Hermes 的 vision 辅助模型未配置）。但**截图本身仍然成功生成**（`screenshot_path` 有效）。直接通过 `MEDIA:` 发送该路径即可，vision analysis 步骤的失败不影响图片可用性。

### 17. 「不兼容」结论必须先实测验证，再下结论

**2026-07-15 教训：** 首次测试 browser-use + MiniMax 时报错 `'SystemMessage' object is not subscriptable`，当场下了"不兼容"的结论，但用户指出 MiniMax 有 Anthropic 接口模式，实测后完全可用。

**正确流程：**
1. 发现某个接口模式报错 → 检查该模型是否还有**其他接口模式**
2. 查看模型配置文档（config.yaml 中 model 的 `api_mode` 字段）
3. 测试所有可用接口模式后，再下结论
4. 结论要精确：说清楚"XX接口模式在XX场景下不可用"，而非"XX模型不兼容"

**常见陷阱：** MiniMax 同时支持 OpenAI 兼容接口和 Anthropic 兼容接口。如果 OpenAI 接口有问题，Anthropic 接口可能完全可用。

## 用户偏好：截图/图片展示

用户偏好 **图片以 native media 形式直接显示在对话中**，而不是作为文件路径文字。具体要求：

- **截图/二维码**：用 `MEDIA:/path/to/file.png` 直接发送，不要只给路径字符串
- **二维码扫码场景**：截图必须在对话中可见，用户才能用手机扫码。不能让用户自己去打开文件路径
- **WeChat 渠道**：`MEDIA:` 图片路径在微信不可见，此时用 `open -a Preview` 打开本地文件让用户在屏幕上看到，或说明渠道限制

## Chinese-Language Convention

After setting up, test with a simple task:

```python
result = await agent.run(
    task='访问 https://example.com 并告诉我页面标题',
    llm=llm,
    llm_screenshot_size=(640, 480),
    use_vision=False,
    browser_profile=profile
)
```

Expected: returns page title "Example Domain" in Chinese.

## 实测 Archive（Planner-Navigator 模式验证）

### 2026-07-15：天眼查查询宁德时代

**测试目标：** 验证 Planner-Navigator 双 Agent 模式在真实企业查询场景的可行性。

**完整流程：**

| # | Agent | 操作 | 结果 | 耗时 |
|:-|:-----|:----|:----|:---|
| 1 | Planner | 拆解任务：打开天眼查 → 搜索 → 选结果 → 提取 | 4 步序列 ✅ | — |
| 2 | Navigator | `browser_navigate("tianyancha.com")` | 首页加载成功 ✅ | 3s |
| 3 | Navigator | 输入"宁德时代" + 点击搜索 | 搜索页 ✅ | 2s |
| 4 | **Planner** | 搜索结果页 snapshot 截断（708 元素）→ **换 JS 兜底** | 用 `browser_console` 找到链接 ✅ | 1s |
| 5 | Navigator | `browser_navigate` 到公司详情页 | 详情页加载成功 ✅ | 3s |
| 6 | Navigator | `browser_console` 提取关键字段 | 全部字段 ✅ | 1s |
| 7 | **Planner** | 验收：目标达成（所有字段有值） | ✅ | — |

**提取数据：**

```json
{
  "公司": "宁德时代新能源科技股份有限公司",
  "状态": "存续",
  "法定代表人": "曾毓群",
  "注册资本": "456,360.8365万人民币",
  "成立日期": "2011-12-16",
  "员工人数": 185839,
  "行业": "锂离子电池制造",
  "邮箱": "catl-ir@catl.com",
  "网址": "www.catl.com"
}
```

**关键发现（已吸收进 skill）：**
1. Snapshot 截断时用 JS DOM 查询兜底（`browser_console` + `querySelectorAll`）
2. Planner 遇到意外情况（截断）能自主切换策略
3. 每一步独立执行，某步失败不影响前面步骤

## Related Skills

- `opencli-integration` — **企业信息查询（天眼查/企查查/企业预警通）三源融合尽调流程**。使用 Chrome + OpenCLI 扩展，共享用户主 Chrome 登录态。与 `browser-automation` 互补：Hermes 工具适合免登录浏览，OpenCLI 适合需登录的站点。
- `llm-json-output-parsing` — MiniMax thinking tag stripping (general, non-browser-use)
- `computer-use` — Desktop GUI automation (different tool, same domain)
- `hermes-tooling-integration` — External tool integration with Hermes

## 浏览器自动化路径选择指南

当前系统有 3 条浏览器自动化路径，按以下逻辑选择：

```
需要浏览器自动化？
├── 目标站点不需要登录（如天眼查基础工商信息）
│   └── ✅ 直接用 Hermes 内置工具（browser_navigate 等）— CloakBrowser 反检测
│
├── 目标站点需要登录（如企查查/企业预警通/微博/知乎）
│   └── ✅ 加载 opencli-integration skill → 用 opencli browser — 共享主 Chrome 登录态
│
├── 需要在快照中搜索特定元素（省 Token）
│   └── ✅ 用 Playwright MCP 的 browser_find 工具 — 按需检索，不获取全量快照
│
├── 需要移动端页面模拟
│   └── ✅ 用 Playwright MCP — 支持 --mobile --device 参数
│
└── 需要 Python 层精细控制（自定义脚本、复杂逻辑）
    └── ⚠️ browser-use 库 — 需 MiniMax Anthropic 接口（简单任务可用）
        ├── 简单任务（导航+读取标题）→ MiniMax-M2.7 Anthropic 接口模式可用
        ├── 复杂多步骤任务 → 需 DeepSeek/OpenAI/Claude（MiniMax tool calling 有限）
        └── 配置：ChatAnthropic(base_url='https://api.minimaxi.com/anthropic')
```

**⚠️ 重要：Hermes 内置浏览器工具（CloakBrowser）和 OpenCLI browser（Chrome）的操作路径完全不同，不能混用。** 登录态不共享（CloakBrowser 用临时 profile，Chrome 用主 profile）。

### 🔴 关键：三条路径之间没有自动 fallback

**Hermes 的 `engine: auto` 是静态的一次性选择**（按 Browserbase → Browser Use → Firecrawl → Camofox → CDP → agent-browser 顺序找到第一个可用的），选定后不会动态切换。

### ⚡ 路径切换前的初始化流程

切换路径时，不仅要选择新路径，还要确保该路径的基础设施就绪：

```python
# 切换路径时的初始化检查
if new_path == 'opencli':
    # 1. 检测 opencli 是否在 PATH 中
    #    opencli 安装路径: ~/.npm-global/bin/opencli
    #    如果不在 PATH 中，先 export PATH="$HOME/.npm-global/bin:$PATH"
    # 2. 检查 daemon 是否运行
    opencli doctor  # 若 daemon 未运行: opencli daemon start
    # 3. 检查扩展是否连接
    #    若未连接: opencli daemon restart → osascript 打开 chrome://extensions
    # 4. 检查目标站点是否已登录
    #    若未登录: 引导用户扫码

elif new_path == 'cdp':
    # 1. 检测 Chrome 是否带 --remote-debugging-port
    #    若没有: 运行 ~/.hermes/scripts/chrome-with-debug.sh
    # 2. 注意: 9222 端口可能被 CloakBrowser 占用
    #    用户 Chrome 应该用 18800 端口
    # 3. 检测 CDP 连通性
    curl -sf http://localhost:{port}/json/version

elif new_path == 'browseruse':
    # 1. 确认 browser-use 已安装
    pip show browser-use
    # 2. 确认 MiniMax API Key 可用
    #    config.yaml 中 minimax.api_key 或环境变量 MINIMAX_API_KEY
    # 3. 使用 ChatAnthropic 类（非 ChatOpenAI）
    #    避免 thinking 标签问题
```

**2026-07-15 实测发现：** opencli binary 安装在 `~/.npm-global/bin/`，不在默认 PATH 中。`check_browser_paths.sh` 已修复为合并 PATH。

这意味着一条不通时，Agent 必须**手动感知失败并主动切换**：

```python
# 错误：browser_navigate 失败 = 任务失败
browser_navigate("https://www.qcc.com")  # 可能 405

# 正确：手动 fallback 模式
# 路1: Hermes CloakBrowser
if result := browser_navigate(target):
    return result
# 路2: OpenCLI Chrome
log("CloakBrowser 失败 → 尝试 OpenCLI browser")
if result := terminal(f"opencli browser sess open {target}"):
    return result
# 路3: browser-use
log("OpenCLI 也失败 → 尝试 browser-use")
if result := run_browseruse(task):
    return result
```

这不是 Hermes 框架的缺陷——三条路径底层机制完全不同（CloakBrowser、Chrome 扩展、Playwright），无法自动切换。Agent 必须接手这个判断。

## Human-in-the-Loop（HITL）验证码/异常处理

> 来源：BrowserAct Skills 文章（2026-06-06）— 内置人机协作模式
> 当前系统状态：❌ 未实现。遇到验证码/弹窗/登录墙时直接失败并切换路径

### 何时需要 HITL

当浏览器自动化遇到以下情况时，**不要直接失败**，而是暂停并通知用户：

| 场景 | 如何检测 | 处理方式 |
|:----|:--------|:--------|
| **验证码/CAPTCHA** | 页面出现"验证码"、"captcha"、"安全验证"等文字，或 slider/drag 元素 | 截图 → 用户手动处理 → 恢复 |
| **登录墙** | 页面出现"登录"、"注册"、"扫码"等登录墙 | 截图 → 用户扫码/登录 → 恢复 |
| **JS 弹窗** | `browser_snapshot` 返回 `pending_dialogs` 字段 | 用 `browser_dialog` 处理或截图通知用户 |
| **Cloudflare 挑战** | 页面标题含"Just a moment"或"Cloudflare" | 截图 → 用户手动通过 → 恢复 |
| **未知异常页面** | 页面内容与预期不符（如空白页、错误页、重定向） | 截图 → 询问用户如何处理 |

### HITL 流程图

```python
# 在 Navigator 执行步骤后，Planner 检测异常
step_result = navigator.execute(step)

# Planner 检测是否需要 HITL
if detect_anomaly(step_result):
    # 1. 截图
    screenshot = browser_vision(question="当前页面截图，用户需要查看")
    # 截图已通过 MEDIA: 自动嵌入对话
    
    # 2. 通知用户
    delegate_task(goal=f"""
    浏览器自动化遇到需要人工介入的情况：
    - 当前路径: {current_path}
    - 目标步骤: {current_step}
    - 检测到: {anomaly_type}
    
    截图已显示在对话中。请用户：
    - 如果是验证码：手动完成验证
    - 如果是登录墙：扫码/登录
    - 如果是弹窗：点击确认/关闭
    
    处理完成后，请确认"已处理"，我会继续执行。
    """)
    
    # 3. 等待用户确认（通过 clarify 工具）
    user_response = clarify(
        question="浏览器遇到异常，截图已显示。请手动处理后告诉我是否继续",
        choices=["已处理，继续", "跳过这一步", "终止任务"]
    )
    
    # 4. 根据用户响应继续
    if user_response == "已处理，继续":
        # 刷新页面，继续执行
        browser_console(expression="window.location.reload()")
        # 继续执行
    elif user_response == "跳过这一步":
        # 记录跳过，继续下一步
        planner.skip_step(current_step)
    elif user_response == "终止任务":
        planner.stop()
```

### HITL 检测规则

在每次 Navigator 执行步骤后，Planner 检查以下异常信号：

```python
def detect_anomaly(snapshot, page_title, current_url):
    """检测是否需要 HITL 介入"""
    
    # 异常关键词
    captcha_keywords = ['验证码', 'captcha', '安全验证', '滑块验证', 
                        '请完成安全验证', '拖动滑块', '点选验证']
    login_keywords = ['登录', '注册', 'sign in', 'login', '扫码登录']
    error_keywords = ['404', '500', 'error', '出错', '页面不存在', 
                      '访问被拒绝', 'access denied']
    
    page_text = snapshot.get('text', '')
    title = (page_title or '').lower()
    
    # 1. 检测验证码
    if any(kw in page_text for kw in captcha_keywords):
        return 'captcha'
    
    # 2. 检测登录墙
    if any(kw in page_text for kw in login_keywords) and \
       '登录' in page_text or '扫码' in page_text:
        return 'login_wall'
    
    # 3. 检测 JS 弹窗
    if snapshot.get('pending_dialogs'):
        return 'dialog'
    
    # 4. 检测错误页
    if any(kw in title for kw in error_keywords) or \
       any(kw in page_text[:200] for kw in error_keywords):
        return 'error_page'
    
    return None
```

### 集成到 Planner-Navigator 循环

在原有的验收循环中，检测到异常时走 HITL 分支，而非直接 fallback：

```python
# 在 Planner 验收时
verdict = planner.verify(step_result)

# 先检测异常
anomaly = detect_anomaly(step_result)

if anomaly:
    # HITL 分支 — 暂停并通知用户
    screenshot = browser_vision(question="页面截图")
    user_choice = clarify(
        question=f"⚠️ 检测到 {anomaly}，请查看截图并手动处理后继续",
        choices=["已处理，继续", "跳过这一步", "终止任务", "切换其他浏览器路径"]
    )
    
    if user_choice == "已处理，继续":
        continue  # 刷新页面继续
    elif user_choice == "切换其他浏览器路径":
        # 走原来的 fallback 逻辑
        fallback_to_next_path()
    elif user_choice == "终止任务":
        break
else:
    # 正常走 fallback 逻辑
    if not verdict.get('done'):
        fallback_to_next_path()
```

### 关键规则

1. **HITL 优先于自动 fallback** — 在切换路径之前，先尝试让用户介入处理异常
2. **截图必须直接可见** — 用 `MEDIA:` 发送截图，不要只给文件路径
3. **超时处理** — 如果用户 5 分钟内未响应，自动 fallback 到下一条路径
4. **记录 HITL 事件** — 保存到 session 日志，方便后续优化

## 参考

- `references/canvas-qrcode-extraction.md` — Canvas 二维码提取与 QR 码过期处理
- `references/qyyjt-fingerprint-binding.md` — 企业预警通指纹绑定问题
- `references/qyyjt-session-isolation-20260714.md` — Hermes CloakBrowser 会话隔离与登录态获取踩坑
- `references/browser-act.md` — BrowserAct 定价与 CloakBrowser 替代方案
- `references/cloakbrowser-setup.md` — CloakBrowser 安装、集成、验证与已知问题
- `references/chrome-login-transfer.md` — Chrome 登录态转移到 CloakBrowser（`--restore` 方案）
- `references/browser-registry.md` — **浏览器路径注册中心**。所有浏览器自动化路径在此注册，Planner 自动读取做路径选择。新增浏览器技能时在此追加条目。
- 研究发现: `~/wiki/research/tools/BrowserAct-Agent-Browser.md` — BrowserAct 技术分析 + CloakBrowser 替代方案
- 研究发现: `~/wiki/research/tools/NanoBrowser-AI-Browser-Automation.md` — NanoBrowser Planner-Navigator 模式来源
- 研究发现: `~/wiki/research/tools/思维工具/Playwright-MCP-v0.0.78.md` — Playwright MCP 微软官方浏览器 MCP 服务器，提供 browser_find 等工具，已注册为第 5 条浏览器路径

## 实用工具

### `scripts/extract_info.py` — 结构化信息提取器

从当前浏览器页面批量提取结构化数据。一次 `browser_console` 调用提取所有字段。

**用法：**

```python
from scripts.extract_info import extract_info_from_page, TIANYANCHA_COMPANY_FIELDS

# 1. 生成 JS 查询表达式
js = extract_info_from_page(TIANYANCHA_COMPANY_FIELDS)

# 2. 传入 browser_console 执行
info = browser_console(expression=js)

# 3. 结果：{"法定代表人": "曾毓群", "注册资本": "456,360.8365万人民币", ...}
```

支持两种模式：正则匹配（默认）和 CSS 选择器。附带了天眼查、企查查等平台的预设字段配置。

### `scripts/test_browseruse_duel_agent.py` — browser-use 双 Agent 测试

测试 browser-use 库的 Planner (DeepSeek) + Navigator (MiniMax) 双 Agent 模式。运行方式：

```bash
cd ~/.hermes/skills/autonomous-ai-agents/browser-automation
python3 scripts/test_browseruse_duel_agent.py
```