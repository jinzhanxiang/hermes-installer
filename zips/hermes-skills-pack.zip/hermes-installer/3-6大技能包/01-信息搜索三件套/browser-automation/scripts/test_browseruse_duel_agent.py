"""
browser-use 双 Agent 实测 — MiniMax Anthropic 接口模式
======================================================
测试 browser-use 0.13.4 的 ChatAnthropic 类配合 MiniMax 的 Anthropic 兼容接口
MiniMax 配置: api_mode=anthropic_messages, base_url=https://api.minimaxi.com/anthropic
"""

import asyncio
import os
from browser_use import Agent
from browser_use.browser.profile import BrowserProfile
from browser_use.llm.anthropic.chat import ChatAnthropic

MINIMAX_KEY = "sk-cp-ZQQBAt3aDd6bocU37eAU-oNpXtTiwpQJNTs-yw-dHZmHRXvmhId8txJnGtYWaaWRebXSORMvu1lfKIOwnbdIz5LWdurhr5ecWZ8ViNsPBKQ6CnaYZ2tGdWA"

async def main():
    print("=" * 60)
    print("browser-use + MiniMax Anthropic 接口实测")
    print(f"  Model: MiniMax-M2.7")
    print(f"  Endpoint: https://api.minimaxi.com/anthropic")
    print("=" * 60)
    
    # ── 用 ChatAnthropic 配置 MiniMax ──
    llm = ChatAnthropic(
        model='MiniMax-M2.7',
        api_key=MINIMAX_KEY,
        base_url='https://api.minimaxi.com/anthropic',
        max_tokens=4096,
        temperature=0.1
    )
    
    profile = BrowserProfile(
        headless=True,
        disable_security=True,
        chrome_channel='chrome',
        enable_default_extensions=False
    )
    
    # ── 测试 1: 简单导航 + 获取标题 ──
    print("\n📋 Test 1: 打开 example.com 获取标题")
    print("-" * 40)
    
    agent = Agent(
        task="请打开 https://example.com 并告诉我页面标题",
        llm=llm,
        use_vision=False,
        browser_profile=profile,
        max_steps=5
    )
    
    try:
        result = await agent.run(max_steps=5)
        print(f"  ✅ 结果: {str(result)[:300]}")
        test1_pass = True
    except Exception as e:
        import traceback
        print(f"  ❌ 失败: {type(e).__name__}: {str(e)[:300]}")
        traceback.print_exc()
        test1_pass = False
    
    # ── 测试 2: 天眼查搜索（如果测试1通过） ──
    if test1_pass:
        print("\n📋 Test 2: 天眼查搜索（复杂任务）")
        print("-" * 40)
        
        agent2 = Agent(
            task="请打开 https://www.tianyancha.com 并在搜索框输入'宁德时代'，然后点击天眼一下按钮，告诉我搜索结果页的标题",
            llm=llm,
            use_vision=False,
            browser_profile=profile,
            max_steps=10
        )
        
        try:
            result2 = await agent2.run(max_steps=10)
            print(f"  ✅ 结果: {str(result2)[:300]}")
        except Exception as e:
            import traceback
            print(f"  ❌ 失败: {type(e).__name__}: {str(e)[:300]}")
            traceback.print_exc()
    
    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)

if __name__ == '__main__':
    asyncio.run(main())