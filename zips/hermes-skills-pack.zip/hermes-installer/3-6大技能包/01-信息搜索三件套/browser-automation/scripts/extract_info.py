"""
extract_info_from_page() — 从浏览器页面批量提取结构化信息

用法：
    from browser_console import extract_info_from_page  # Hermes skill 内直接调用
    
    info = await extract_info_from_page({
        "公司名": r"h1\s*存续",
        "法定代表人": r"法定代表人：\s*(\S+)",
        "注册资本": r"注册资本：\s*([\d,]+万[元]?人民币)",
        "成立日期": "成立日期：\\s*(\\S+)",
    })

原理：
    向浏览器注入 JavaScript，通过 document.body.innerText + 正则匹配提取字段。
    一次 console call 提取所有字段，比逐个提取快 5-10 倍。
"""

import json
import re

def extract_info_from_page(field_config: dict, use_regex: bool = True):
    """
    生成 browser_console 调用的 JavaScript 表达式，用于从页面提取结构化数据。
    
    参数:
        field_config: {字段名: 正则模式或CSS选择器}
            正则模式: 从 document.body.innerText 中匹配
            CSS选择器（以 CSS: 开头）: 如 "CSS:h1" 获取 h1 元素的文本
        use_regex: True=正则匹配, False=CSS选择器（默认True）
    
    返回:
        可直接传给 browser_console(expression=...) 的 JS 字符串
    
    示例:
        js = extract_info_from_page({
            "法定代表人": r"法定代表人：\s*(\S+)",
            "注册资本": r"注册资本：\s*([\d,]+万[元]?人民币)",
            "成立日期": r"成立日期：\s*(\S+)",
            "员工数": r"员工人数：\s*(\d+)",
        })
        result = browser_console(expression=js)
    """
    if use_regex:
        patterns = {}
        for name, pattern in field_config.items():
            # Escape the JS string properly
            escaped = pattern.replace('\\', '\\\\').replace("'", "\\'")
            patterns[name] = escaped
        
        js = f"""
(() => {{
    const text = document.body.innerText;
    const patterns = {json.dumps(field_config, ensure_ascii=False)};
    const result = {{}};
    for (const [key, pattern] of Object.entries(patterns)) {{
        try {{
            // Use the outerText for richer content, innerText as fallback
            const source = document.body.innerText;
            const regex = new RegExp(pattern);
            const match = source.match(regex);
            result[key] = match ? match[1].trim() : null;
        }} catch(e) {{
            result[key] = `[ERROR: ${{e.message}}]`;
        }}
    }}
    return result;
}})()
"""
    else:
        # CSS selector mode
        selectors = json.dumps(field_config, ensure_ascii=False)
        js = f"""
(() => {{
    const selectors = {selectors};
    const result = {{}};
    for (const [key, selector] of Object.entries(selectors)) {{
        try {{
            const el = document.querySelector(selector);
            result[key] = el ? el.textContent.trim() : null;
        }} catch(e) {{
            result[key] = null;
        }}
    }}
    return result;
}})()
"""
    return js.strip()


# ── 专用于企业查询场景的预设配置 ──

TIANYANCHA_COMPANY_FIELDS = {
    "法定代表人": r"法定代表人：\s*(\S+)",
    "注册资本": r"注册资本：\s*([\d,]+万[元]?人民币)",
    "成立日期": r"成立日期：\s*(\S+)",
    "统一社会信用代码": r"统一社会信用代码：\s*(\S+)",
    "员工人数": r"员工人数：\s*(\d+)",
    "行业": r"国标行业：\s*(\S+)",
    "邮箱": r"邮箱：\s*(\S+@\S+)",
    "网址": r"网址：\s*(\S+)",
    "状态": r"(存续|在业|注销|吊销)",
    "电话": r"电话：\s*(\S+)",
    "企业规模": r"企业规模：\s*(\S+)",
}

# QCC 企查查字段配置
QICHACHA_COMPANY_FIELDS = {
    "法定代表人": r"法定代表人[\s\S]{0,50}?(\S+?)(?:\s|$)",
    "注册资本": r"注册资本[\s\S]{0,30}?([\d,]+[万元]?[人民币]?)",
    "成立日期": r"成立日期[\s\S]{0,20}?(\d{4}[-/]\d{1,2}[-/]\d{1,2})",
    "统一社会信用代码": r"统一社会信用代码[\s\S]{0,30}?(\S{18})",
}


if __name__ == "__main__":
    # 测试: 生成 JS 表达式
    js = extract_info_from_page(TIANYANCHA_COMPANY_FIELDS)
    print("=== Generated JS (first 500 chars) ===")
    print(js[:500])
    print(f"\n... (total {len(js)} chars)")
    print("\n=== CSS selector mode test ===")
    js2 = extract_info_from_page({"title": "CSS:h1"}, use_regex=False)
    print(js2)