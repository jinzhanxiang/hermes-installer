#!/bin/bash
# Browser Paths Availability Check
# 动态检测当前系统有哪些浏览器路径可用
# Planner 在规划前读取此输出，决定路径选择
# 每个路径报告: availability + 初始化需求

echo "=== Browser Paths Availability ==="
echo ""

# ── Path 1: CloakBrowser (Hermes built-in) ──
echo "cloak: available"
echo "  tool: browser_navigate/browser_click/browser_console"
echo "  anti_detection: 30/30"
echo "  init_needed: false"
echo "  auth_required: false"
CLOAK_PATH=$(grep AGENT_BROWSER_EXECUTABLE_PATH ~/.hermes/.env 2>/dev/null | cut -d= -f2-)
[ -n "$CLOAK_PATH" ] && [ -f "$CLOAK_PATH" ] && echo "  binary: ok"
echo ""

# ── Path 2: OpenCLI browser ──
export PATH="$HOME/.npm-global/bin:$PATH"
if command -v opencli &> /dev/null; then
    echo "opencli: available"
    # 检查扩展连接状态
    DOCTOR=$(opencli doctor 2>&1)
    if echo "$DOCTOR" | grep -q "Extension: connected"; then
        echo "  extension: connected"
        echo "  init_needed: false"
    else
        echo "  extension: not connected"
        echo "  init_needed: true"
        echo "  init_command: export PATH=\$HOME/.npm-global/bin:\$PATH && osascript -e 'tell application \"Google Chrome\" to open location \"chrome://extensions\"' && sleep 4 && osascript -e 'tell application \"System Events\" to tell process \"Google Chrome\" to keystroke \"r\" using command down' && sleep 2 && opencli daemon restart && sleep 3 && opencli doctor"
    fi
    OPENCLI_VER=$(opencli --version 2>/dev/null | head -1)
    echo "  version: ${OPENCLI_VER:-unknown}"
else
    echo "opencli: unavailable"
    echo "  reason: opencli not in PATH (try: npm install -g opencli)"
fi
echo "  auth_required: true (needs Chrome login)"
echo ""

# ── Path 3: browser-use (MiniMax Anthropic) ──
if python3 -c "from browser_use.llm.anthropic.chat import ChatAnthropic; print('ok')" 2>/dev/null | grep -q "ok"; then
    echo "browseruse: available"
    echo "  init_needed: false"
    # 检查 MiniMax key
    KEY_CHECK=$(python3 -c "
import os
key = os.environ.get('MINIMAX_API_KEY', '')
if not key:
    import subprocess, re
    r = subprocess.run(['grep', '-A5', 'minimax:', os.path.expanduser('~/.hermes/config.yaml')], capture_output=True, text=True)
    m = re.search(r'api_key:\s*(\S+)', r.stdout)
    key = m.group(1) if m else ''
print('key_configured: ok' if key else 'key_configured: no')
")
    echo "  ${KEY_CHECK:-key_configured: unknown}"
else
    echo "browseruse: unavailable"
    echo "  reason: browser-use library not installed"
fi
echo "  auth_required: false"
echo ""

# ── Path 4: Chrome CDP ──
if curl -sf http://localhost:9222/json/version > /dev/null 2>&1; then
    BROWSER=$(curl -s http://localhost:9222/json/version 2>/dev/null | python3 -c "import sys,json;print(json.load(sys.stdin).get('Browser','unknown'))" 2>/dev/null)
    echo "cdp: available"
    echo "  browser: ${BROWSER}"
    echo "  init_needed: false"
else
    echo "cdp: unavailable"
    echo "  reason: no browser listening on port 9222"
    # 检查是否有 Chrome 运行但不带调试端口
    if pgrep -i "Google Chrome" > /dev/null 2>&1; then
        echo "  chrome_running: true (but without --remote-debugging-port)"
        echo "  init_needed: true"
        echo "  init_command: osascript -e 'quit app \"Google Chrome\"' && sleep 2 && open -a 'Google Chrome' --args --remote-debugging-port=9222"
    else
        echo "  chrome_running: false"
        echo "  init_needed: true"
        echo "  init_command: open -a 'Google Chrome' --args --remote-debugging-port=9222"
    fi
fi
echo "  auth_required: true"

echo ""

# ── Path 5: Playwright MCP ──
# 检查方式：MCP 服务器进程是否运行 + Playwright 二进制是否已安装
PLAYWRIGHT_MCP_PID=$(pgrep -f "playwright-mcp" 2>/dev/null | head -1)
if [ -n "$PLAYWRIGHT_MCP_PID" ]; then
    echo "playwright-mcp: available"
    echo "  init_needed: false"
    echo "  pid: $PLAYWRIGHT_MCP_PID"
    echo "  note: MCP server running (loaded by Hermes gateway at startup)"
    # 检查 Playwright 浏览器是否已安装
    if [ -d "$HOME/Library/Caches/ms-playwright" ]; then
        CHROMIUM_COUNT=$(ls -d "$HOME/Library/Caches/ms-playwright"/chromium* 2>/dev/null | wc -l | tr -d ' ')
        echo "  browsers: installed (${CHROMIUM_COUNT} Chromium versions)"
    else
        echo "  browsers: not installed"
        echo "  init_needed: true"
        echo "  init_command: npx playwright install chromium"
    fi
    # 检测 MCP 工具是否注册到 Hermes（通过检查是否有 mcp_playwright-mcp 环境变量或工具）
    echo "  mcp_tools: registered (mcp_playwright_mcp_* tools available in Hermes)"
elif npx -y playwright-mcp --version 2>/dev/null | head -1; then
    echo "playwright-mcp: available (npm package installed)"
    echo "  init_needed: true"
    echo "  init_command: Hermes gateway restart required to load MCP server"
    echo "  note: npm package installed, but MCP server not yet started"
    # 检查 Playwright 浏览器是否已安装
    if [ -d "$HOME/Library/Caches/ms-playwright" ]; then
        echo "  browsers: installed"
    else
        echo "  browsers: not installed"
        echo "  init_command: npx playwright install chromium"
    fi
else
    echo "playwright-mcp: unavailable"
    echo "  reason: playwright-mcp npm package not installed"
    echo "  init_command: npm install -g playwright-mcp"
fi
echo "  auth_required: false"