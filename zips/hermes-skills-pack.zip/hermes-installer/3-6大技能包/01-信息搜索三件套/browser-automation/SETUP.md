# browser-automation 安装说明

## 技能目录

解压后放置在：`~/.hermes/skills/autonomous-ai-agents/browser-automation/`

## 依赖安装

### 1. CloakBrowser（反检测引擎，可选但推荐）

```bash
# 安装 CloakBrowser Python 包
pip install cloakbrowser

# 国内加速（ghproxy 镜像）
pip install cloakbrowser -i https://pypi.douban.com/simple/
```

安装后找到二进制路径：

```bash
ls ~/.cloakbrowser/chrome/*/chrome 2>/dev/null
```

### 2. 配置环境变量

在 `~/.hermes/.env` 中添加：

```bash
# 指向 CloakBrowser 二进制（路径以实际安装为准）
AGENT_BROWSER_EXECUTABLE_PATH=~/.cloakbrowser/chrome/mac_arm-146/chrome
```

设置后 Hermes 浏览器工具自动使用 CloakBrowser，零代码改动。

### 3. 验证安装

```bash
# 在 Hermes 中加载技能
hermes -s browser-automation

# 运行检测脚本确认所有路径状态
bash ~/.hermes/skills/autonomous-ai-agents/browser-automation/scripts/check_browser_paths.sh
```

预期输出 5 条路径中至少有 cloak（内置浏览器）可用。

### 4. Playwright MCP（可选，第 5 条浏览器路径）

```bash
# 安装 Playwright MCP
npx -y playwright-mcp

# 在 config.yaml 中注册（如果未自动注册）
# mcp_servers:
#   playwright-mcp:
#     command: npx
#     args: ["-y", "playwright-mcp"]
#     enabled: true
#     timeout: 120
```

### 5. OpenCLI（可选，第 2 条浏览器路径）

```bash
npm install -g opencli
opencli doctor  # 确认安装成功
```

## 核心功能速查

### 5 条浏览器路径

| # | 路径 | 反检测 | 登录态 | 初始化 |
|:-:|:----|:------:|:------:|:------:|
| 1 | cloak（Hermes 内置） | ⭐⭐⭐⭐⭐ | 不需要 | 不需要 |
| 2 | opencli（Chrome 扩展） | ⭐⭐⭐ | 需要 | 可能需要 |
| 3 | browseruse（MiniMax） | ⭐⭐ | 不需要 | 不需要 |
| 4 | cdp（Chrome 直连） | ⭐⭐⭐ | 需要 | 可能需要 |
| 5 | playwright-mcp（MCP） | ⭐⭐ | 不需要 | 不需要 |

### Human-in-the-Loop（HITL）

当遇到验证码/登录墙/弹窗时，系统会自动：
1. 截图 → 发送给用户
2. 等待用户手动处理后恢复
3. 或用户选择跳过/切换路径/终止

### 自动路径切换

```
cloak(1) → opencli(2) → browseruse(3) → cdp(4) → playwright-mcp(5)
失败时自动降级到下一路径，全部失败才告知用户
```

## 使用示例

```bash
# 在 Hermes 中
"帮我查天眼查上宁德时代的基本信息"
# → 自动走 cloak 路径 → 查询成功

"帮我查企查查上宁德时代的股东信息"
# → cloak 路径失败（需登录）→ 自动走 opencli 路径 → 查询成功
```

## 注意事项

- macOS 专用（CloakBrowser 仅支持 macOS/Linux）
- 天眼查免登录可用，企查查/企业预警通需登录态
- 首次使用 CloakBrowser 需下载 ~200MB Chromium 二进制