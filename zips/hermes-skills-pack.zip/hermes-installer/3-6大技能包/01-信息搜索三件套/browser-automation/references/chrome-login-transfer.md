# Chrome 登录态转移到 CloakBrowser

## 场景

企查查等网站有应用层反爬（405），仅靠 CloakBrowser 的反检测不够，还需合法登录 session。

## 方案：一次性登录 + `--restore` 持久化（推荐）

### 首次：在 CloakBrowser 中登录并保存 session

```bash
CLOAK_PATH="/Users/jinzhanxiang/.cloakbrowser/chromium-145.0.7632.109.2/Chromium.app/Contents/MacOS/Chromium"

# 打开企查查（在非 headless 模式下方便扫码/输手机号）
npx agent-browser --executable-path "$CLOAK_PATH" --headed \
  --restore qcc --restore-save always \
  open --url "https://www.qcc.com"
```

手动登录后，session 自动保存到 `~/.agent-browser/restore/qcc.json`（含 cookies + localStorage）。

### 以后：自动恢复

```bash
npx agent-browser --executable-path "$CLOAK_PATH" \
  --restore qcc \
  open --url "https://www.qcc.com"
```

`--restore` 会自动注入保存的 cookies 和 localStorage，企查查认作已登录用户。

# 方案二（全自动）：Chrome CDP + cookie 注入（验证通过 — 2026-07-14）

当用户已经在 Chrome 中登录了目标站点，用此方案全自动提取 cookie 并注入 CloakBrowser，无需重复扫码。

### ⚠️ `--user-data-dir` 关键技术细节

`--user-data-dir` **必须指向用户数据目录的父目录**，不能包含 `/Default` 子目录：

```bash
# ✅ 正确
--user-data-dir="/Users/jinzhanxiang/Library/Application Support/Google/Chrome"

# ❌ 错误 — 会导致 "incorrect profile type" 错误，Chrome 不绑定调试端口
--user-data-dir="/Users/jinzhanxiang/Library/Application Support/Google/Chrome/Default"
```

**原因：** `--user-data-dir` 期望的是包含多个 profile 的根目录（如 `Chrome/`），其下有 `Default/`、`Profile 1/` 等子目录。指向子目录导致 Chrome 无法正确加载 profile。

### 当 Chrome 已运行时：用独立临时 profile

如果用户的主 Chrome（GUI 实例）已经在运行，**不能**用同一个 `--user-data-dir` 启动第二个 Chrome 实例（会冲突）。此时应该用**独立的临时 profile**：

```bash
# 创建临时 profile 目录
mkdir -p /tmp/chrome-debug-profile-<name>

"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --remote-debugging-port=9222 \
  --user-data-dir="/tmp/chrome-debug-profile-<name>" \
  --no-first-run --no-default-browser-check
```

**注意：** 这是空 profile，无任何登录态。用户需要在此 Chrome 窗口中重新登录目标站点。

### 全自动执行流程

```bash
# ===== 第1步：关掉所有 Chrome =====
# ✅ 正确：使用 osascript 正常退出，避免损坏 Preferences 文件
osascript -e 'quit app "Google Chrome"'
sleep 3
# ❌ 错误：pkill -9 会损坏 Preferences 文件，导致扩展注册丢失
# pkill -9 -f "Google Chrome"

# ===== 第2步：启动 Chrome 带调试端口 =====

"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --remote-debugging-port=9222 \
  --user-data-dir="/Users/jinzhanxiang/Library/Application Support/Google/Chrome" \
  --no-first-run --no-default-browser-check &

# 等待 Chrome 启动（需 15-20 秒）
sleep 15

# 验证端口是否打开
curl -s http://localhost:9222/json/version | head -3
# ===== 第3步：让用户登录或复用已保存的登录态 =====
# Chrome 窗口会显示，用户扫码或在已登录网站上直接导航

# 通过 CDP 导航到目标站点
curl -s -X PUT "http://localhost:9222/json/new?https://www.qcc.com"

# 用户扫码登录后...

# ===== 第4步：通过 CDP 提取 cookies =====
python3 << 'PYEOF'
import requests, json, asyncio, websockets

async def extract():
    targets = requests.get("http://localhost:9222/json", timeout=5).json()
    ws_url = next((t['webSocketDebuggerUrl'] for t in targets if 'qcc.com' in t.get('url','')), None)
    if not ws_url:
        ws_url = next((t['webSocketDebuggerUrl'] for t in targets if t.get('url','').startswith('http')), None)
    async with websockets.connect(ws_url) as ws:
        await ws.send(json.dumps({"id": 1, "method": "Network.getCookies", "params": {}}}))
        resp = json.loads(await ws.recv())
        cookies = resp['result']['cookies']
        with open('/tmp/all_cookies.json', 'w') as f:
            json.dump(cookies, f)
        print(f"Saved {len(cookies)} cookies")
asyncio.run(extract())
PYEOF

# ===== 第5步：注入到 CloakBrowser =====
CLOAK_PATH="/Users/jinzhanxiang/.cloakbrowser/chromium-145.0.7632.109.2/Chromium.app/Contents/MacOS/Chromium"
SESSION="qcc-logged-in"

# 先打开空白页
npx agent-browser --executable-path "$CLOAK_PATH" open --url "about:blank" --session "$SESSION"

# 逐条注入 cookies
python3 << 'PYEOF'
import json, subprocess
with open('/tmp/all_cookies.json') as f:
    cookies = json.load(f)
for c in cookies:
    name, value, domain = c['name'], c['value'], c['domain']
    path = c.get('path', '/')
    cmd = ['npx', 'agent-browser', 'cookies', 'set', name, value,
           '--domain', domain, '--path', path, '--session', 'qcc-logged-in']
    if c.get('secure'): cmd.append('--secure')
    if c.get('httpOnly'): cmd.append('--httpOnly')
    subprocess.run(cmd, capture_output=True, timeout=10)
PYEOF

# ===== 第6步：导航验证 =====
npx agent-browser --executable-path "$CLOAK_PATH" \
  open --url "https://www.qcc.com" --session "$SESSION"

# 检查登录态（注销字样 = 已登录）
npx agent-browser eval \
  "(()=>{const t=document.body.innerText;return t.includes('注销')?'LOGGED_IN':'NOT_LOGGED_IN'})()" \
  --session "$SESSION"

# ===== 第7步：持久化（后续直接复用） =====
npx agent-browser --executable-path "$CLOAK_PATH" \
  --restore qcc --restore-save always \
  eval "1" --session "$SESSION"

# 后续查询：
npx agent-browser --executable-path "$CLOAK_PATH" \
  --restore qcc open --url "https://www.qcc.com"
```

### 检测 CDP Chrome 的登录态

```python
# 验证 QCCSESSID + 页面元素
import requests, json, asyncio, websockets

async def check():
    targets = requests.get("http://localhost:9222/json", timeout=5).json()
    ws_url = next((t['webSocketDebuggerUrl'] for t in targets if 'qcc.com' in t.get('url','')), None)
    async with websockets.connect(ws_url) as ws:
        # 检查 cookies
        await ws.send(json.dumps({"id":1, "method":"Network.getCookies", "params":{}}))
        resp = json.loads(await ws.recv())
        qcc_sess = [c for c in resp['result']['cookies'] if c['name'] == 'QCCSESSID']
        print(f"QCCSESSID: {qcc_sess[0]['value'][:40] if qcc_sess else 'NOT_FOUND'}...")
        # 检查页面元素 — 有"注销" = 已登录
        await ws.send(json.dumps({"id":2, "method":"Runtime.evaluate", "params":{
            "expression": "document.body.innerText.includes('注销') ? 'LOGGED_IN' : 'NOT_LOGGED_IN'"
        }}))
        resp2 = json.loads(await ws.recv())
        print(f"Status: {resp2['result']['result'].get('value','N/A')}")
asyncio.run(check())
```

## 失效方案（记录备查）

以下方案在本环境中 **不可行**，供排查参考：

| 方案 | 原因 |
|:---|:----|
| `--profile Default` | CloakBrowser 的 Chromium 二进制与用户主 Chrome 不同，无法解密 macOS Keychain 中的加密 cookies |
| `--cdp 18800` 连 OpenCLI Chrome | 那是 OpenCLI 的隔离实例（`~/.openclaw/browser/openclaw/user-data`），和用户主 Chrome 不同 profile。即使有 QCCSESSID 也可能是过期 session（实测页面显示"登录\|注册"） |
| `--auto-connect` | 仅找默认 CDP 端口（9222），用户主 Chrome 未开 `--remote-debugging-port` |
| 解密 Chrome cookies（Python） | macOS 上 Chrome cookies 用 AES-256-GCM 加密，密钥存在系统 Keychain 中。`security find-generic-password` 会触发系统弹窗，CLI 环境无法自动确认，超时后失败 |
| `browser-cookie3` Python 库 | 同样触发 macOS Keychain 弹窗，非交互式终端中超时 |
| `kill -SIGUSR1` 给 Chrome | macOS 上 SIGUSR1 不能开启 Chrome 远程调试端口。只能重启带 `--remote-debugging-port` |
| `keyring` Python 库 | 底层仍调用 macOS Keychain，同样触发弹窗超时 |

## 原理

- `agent-browser` 的 `--restore` 自动保存/恢复 **cookies + localStorage** 到 `~/.agent-browser/restore/<key>.json`
- `--restore-save always` 确保每次页面变化都自动保存
- `--restore-check-url` / `--restore-check-text` / `--restore-check-fn` 可验证恢复的 state 是否仍然有效
- 数据默认存储 30 天，可通过 `AGENT_BROWSER_STATE_EXPIRE_DAYS` 调整
- 可用 `AGENT_BROWSER_ENCRYPTION_KEY` 设置 AES-256-GCM 加密密钥

## 检测 CDP 连接的 Chrome 是否真有有效登录态

```python
# 通过 CDP 获取 cookies 并检查关键 session cookie + 页面元素
import requests, json, asyncio, websockets

async def check():
    targets = requests.get("http://localhost:18800/json", timeout=5).json()
    ws_url = [t['webSocketDebuggerUrl'] for t in targets if 'qcc.com' in t.get('url','')][0]
    async with websockets.connect(ws_url) as ws:
        await ws.send(json.dumps({"id":1, "method":"Network.getCookies", "params":{}}))
        resp = json.loads(await ws.recv())
        qcc_sess = [c for c in resp['result']['cookies'] if c['name'] == 'QCCSESSID']
        print(f"QCCSESSID: {qcc_sess[0]['value'][:40] if qcc_sess else 'NOT_FOUND'}...")
        # 检查页面用户元素 — 显示"登录 | 注册"说明 session 过期
        await ws.send(json.dumps({"id":2, "method":"Runtime.evaluate", "params":{
            "expression": "document.querySelector('.navbar-user, .user-name, [class*=user]')?.textContent?.trim()?.substring(0, 40) || 'NOT_FOUND'"
        }}))
        resp2 = json.loads(await ws.recv())
        print(f"User element: {resp2.get('result',{}).get('result',{}).get('value','N/A')}")
asyncio.run(check())
```

## agent-browser 相关命令速查

```bash
# 连接跑着的 Chrome（需 --remote-debugging-port）
agent-browser --cdp 18800 open --url "https://example.com"

# 查看可用 Chrome 用户数据目录
agent-browser profiles

# 手动设置 cookies（逐条）
agent-browser cookies set <name> <value> --domain ".qcc.com" --path "/"

# 查看会话信息
agent-browser session info --json

# 列出所有 session
agent-browser session list
```