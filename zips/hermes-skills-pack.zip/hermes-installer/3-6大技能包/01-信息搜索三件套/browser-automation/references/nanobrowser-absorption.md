# NanoBrowser 引入与吸收记录

> 来源：NanoBrowser（13k+ ⭐ GitHub）— 开源 Chrome 扩展，AI Agent 通过 Planner + Navigator 双 Agent 协作执行复杂网页任务。
> 原文笔记：`~/wiki/research/tools/思维工具/NanoBrowser-AI-Browser-Automation.md`

## 吸收时间

2026-07-15

## 吸收了什么

### 1. Planner-Navigator 多 Agent 架构

从 NanoBrowser 的设计中提取了 Planner + Navigator 双 Agent 分工模式，替代原先的单 Agent 硬跑方案。

| 角色 | 职责 | 在浏览器自动化场景中 |
|:----|:-----|:-------------------|
| **Planner** | 分析状态、规划步骤、判断方向 | 拆解用户指令为浏览器步骤序列，遇到意外时重规划 |
| **Navigator** | 执行具体操作、返回结果 | 点击、输入、跳转、提取数据 |

### 2. 多模型组合策略

| 任务类型 | 推荐模型 |
|:---------|:---------|
| 复杂规划（跨页面、多条件判断） | DeepSeek / Claude |
| 普通导航（点击、输入、提取） | MiniMax-M2.7 |
| 隐私敏感任务 | Ollama 本地模型 |

### 3. Snapshot 截断 JS 兜底

**实测发现：** 天眼查搜索结果页在 `element_count=708` 时 snapshot 被截断，无法通过 `browser_snapshot` 找到结果链接。

**解决方案：** 用 `browser_console(expression=...)` 直接通过 DOM 查询拿到目标链接。

详见 `SKILL.md`「方式 A」之下的 ⚡ 关键 pitfall 章节。

## 验证结果

2026-07-15 以天眼查搜索"宁德时代"为测试用例：

1. Planner 拆任务为 4 步 ✅
2. Navigator 打开首页、搜索 ✅
3. Planner 发现 snapshot 截断 → 切换到 JS 兜底 ✅
4. Navigator 用 JS 找到的链接打开详情页 ✅
5. Navigator 提取全部字段 ✅
6. Planner 验收通过 ✅

完整测试记录见 SKILL.md「实测 Archive」章节。