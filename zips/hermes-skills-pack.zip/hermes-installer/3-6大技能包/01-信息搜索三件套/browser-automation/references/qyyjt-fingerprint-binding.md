# 企业预警通 (qyyjt.cn) — 指纹绑定与 --restore 失效

## 问题

从 Chrome CDP 提取的 qyyjt.cn cookies 注入 CloakBrowser 后，`--restore` 加载但服务器不认——返回登录页。

## 根因

**企业预警通的 session 绑定了浏览器指纹（Chrome vs CloakBrowser），不是纯 cookie 绑定。**
Chrome 登录的 cookies 在 CloakBrowser（Chromium 145）中不生效，因为服务端做了额外的浏览器指纹校验。

## 症状

- Chrome CDP 提取到 3 个 cookies: `HWWAFSESID`, `HWWAFSESTIME`, `JSESSIONID`
- 注入 CloakBrowser 后页面仍然是 `qyyjt.cn/user/login`（登录页）
- Chrome 中的 session 仍然有效（可正常查询）
- `JSESSIONID` 会随每次登录变化

## 正确方案

**不要做 cookie 迁移。** 直接在 CloakBrowser / Hermes 浏览器上登录：

1. 用 Hermes `browser_navigate` 打开登录页（`qyyjt.cn/user/login`）
2. 用户扫码（企业预警通 APP）或输入账号密码
3. 登录后用 `agent-browser --restore qyyjt --restore-save always open --url "https://www.qyyjt.cn"` 持久化
4. 下次 `--restore qyyjt` 自动恢复

## 企业预警通 cookies 结构

```
HWWAFSESID=<session-id>     domain=www.qyyjt.cn  secure=false  httpOnly=false  path=/
HWWAFSESTIME=<timestamp>     domain=www.qyyjt.cn  secure=false  httpOnly=false  path=/
JSESSIONID=<j-session-id>    domain=www.qyyjt.cn  secure=true   httpOnly=true   path=/
```

JSESSIONID 是核心 session cookie，每次登录会生成新值。

## 对比：企查查 vs 企业预警通

| 特性 | 企查查 (qcc.com) | 企业预警通 (qyyjt.cn) | 天眼查 |
|:----|:----------------|:-------------------|:------|
| 登录方式 | 微信扫码 | 企业预警通 APP 扫码 / 手机账号密码 | 无需登录 |
| cookie 跨浏览器可移植 | ⚠️ 部分（需配合 --restore） | ❌ 不可移植（指纹绑定） | — |
| 推荐方案 | `--restore` 在 CloakBrowser 上登录 | `--restore` 在 CloakBrowser 上登录 | 直接访问 |

**统一结论**：三个数据源都应在 CloakBrowser 上直接登录一次（天眼查除外），用 `--restore` 持久化，不要尝试跨浏览器 cookie 迁移。

## 截图展示流程（2026-07-14 实测）

当用户需要看到登录页二维码时：
1. `browser_navigate("https://www.qyyjt.cn")` → 自动跳转到 `/user/login`
2. `browser_vision(question=...)` → 截图保存到 `~/.hermes/cache/screenshots/browser_screenshot_*.png`
3. 用 `MEDIA:/path/to/screenshot.png` 直接发送给用户
4. **注意**：`browser_vision` 的 vision analysis 可能返回 401（API key 问题），但 `screenshot_path` 仍然有效，可以直接用 `MEDIA:` 发送
5. 如果截图是黑屏，重新 `browser_navigate` 导航到登录页后再截图

## Hermes 内置浏览器 vs agent-browser 对比

| 特性 | browser_navigate | agent-browser --restore |
|:----|:-----------------|:-----------------------|
| QR 扫码登录态保持 | ❌ 可能丢失（新页面上下文） | ✅ 保持 |
| 登录页展示 | ✅ 可用 | ✅ 可用 |
| 后续查询 | ⚠️ 需重新登录 | ✅ 自动恢复 |

**结论**：登录用 `agent-browser --restore <name> --restore-save always open`，日常查询用 `--restore <name> open`。
