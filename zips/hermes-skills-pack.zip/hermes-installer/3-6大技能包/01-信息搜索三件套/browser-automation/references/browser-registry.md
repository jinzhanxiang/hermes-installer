# Browser Registry — 浏览器自动化路径注册中心

> **核心约定：** Hermes 系统中所有浏览器自动化路径必须在此注册。
> 新增浏览器技能/工具时，在此文件追加条目 — Planner 自动读取并纳入路径选择。

---

## 注册格式

每个路径包含以下字段：

| 字段 | 说明 | 必填 |
|:----|:----|:----|
| `id` | 唯一标识（小写，如 `cloak`、`opencli`） | ✅ |
| `name` | 人类可读名称 | ✅ |
| `tool_type` | 调用方式：`hermes_tool` / `terminal` / `python` / `mcp` | ✅ |
| `invoke` | 具体调用方法 | ✅ |
| `browser` | 使用的浏览器引擎 | ✅ |
| `strength` | 优势说明 | ✅ |
| `weakness` | 劣势说明 | ✅ |
| `availability_check` | 可用性检测命令/代码 | ✅ |
| `init_needed` | 是否需要初始化（true/false） | ✅ |
| `init_command` | 初始化命令（当 init_needed=true 时） | ✅ |
| `auth_required` | 是否需要登录态 | ✅ |
| `anti_detection` | 反检测能力评分 | ✅ |
| `work_without_login` | 免登录能否工作 | ✅ |

---

## 注册条目

### Path 1: CloakBrowser（Hermes 内置工具）

```yaml
id: cloak
name: Hermes 内置 CloakBrowser
tool_type: hermes_tool
invoke: browser_navigate / browser_click / browser_snapshot / browser_console
browser: CloakBrowser v146（Chromium 源码级反检测）
strength:
  - 30/30 反检测全绿（navigator.webdriver=false, plugins=5, chrome=object）
  - 无需加载任何 skill，built-in 工具始终可用
  - 天眼查 ✅ 完全通过
weakness:
  - 隔离 profile，不共享 Chrome 登录态
  - 企查查 405 应用层拦截 ❌
  - 每次 session 新实例，cookie 不持久
availability_check: "✅ 始终可用（Hermes 内置工具集）"
init_needed: false
init_command: ""
auth_required: false
anti_detection: "⭐⭐⭐⭐⭐ (30/30)"
work_without_login: true
fallback_order: 1
```

### Path 2: OpenCLI browser（Chrome + OpenCLI 扩展）

```yaml
id: opencli
name: OpenCLI browser（Chrome CDP）
tool_type: terminal
invoke: "opencli browser <session> open/type/click/eval/extract"
browser: 用户主 Chrome（共享全部登录态）
strength:
  - 共享 Chrome 所有 cookie，天然有登录态
  - eval JS 可直接操作 DOM，灵活
  - bind 命令可接管用户当前标签页
  - 164 个站点有内置适配器
weakness:
  - 需要 Chrome 运行 + OpenCLI 扩展连接
  - 首次启动较慢（daemon + 扩展唤醒）
  - 元素索引 [N] 每次加载可能变化
  - Chrome 双实例问题（需 --remote-debugging-port）
availability_check: "opencli doctor → Extension: connected"
init_needed: true
init_command: "export PATH=$HOME/.npm-global/bin:$PATH && osascript -e 'tell application \"Google Chrome\" to open location \"chrome://extensions\"' && sleep 4 && osascript -e 'tell application \"System Events\" to tell process \"Google Chrome\" to keystroke \"r\" using command down' && sleep 2 && opencli daemon restart && sleep 3 && opencli doctor"
auth_required: true
anti_detection: "⭐⭐⭐ (真实用户浏览器)"
work_without_login: false
fallback_order: 2
```

### Path 3: browser-use（Python + MiniMax Anthropic）

```yaml
id: browseruse
name: browser-use 库（MiniMax Anthropic）
tool_type: python
invoke: "Agent(task, llm=ChatAnthropic(...)).run()"
browser: Playwright 管理的 headless Chromium
strength:
  - 独立的浏览器实例，不同 fingerprint
  - 可用 Anthropic 接口（ChatAnthropic 类）避免 thinking 污染
  - 简单任务（导航+读取标题）已验证可行
weakness:
  - MiniMax-M2.7 tool calling 精度有限
  - 复杂多步骤任务可能因 schema 验证失败
  - 需要 Python 环境和 browser-use 库
  - DeepSeek API Key 已失效，无法用强模型
availability_check: "pip show browser-use 2>/dev/null && python3 -c 'from browser_use.llm.anthropic.chat import ChatAnthropic; print(\"ok\")'"
init_needed: false
init_command: ""
auth_required: false
anti_detection: "⭐⭐ (headless Chromium)"
work_without_login: true
fallback_order: 3
```

### Path 5: Playwright MCP（MCP 服务器 / 微软官方）

```yaml
id: playwright-mcp
name: Playwright MCP（微软官方 MCP 服务器）
tool_type: mcp
invoke: "mcp_playwright-mcp_browser_navigate / mcp_playwright-mcp_browser_click / mcp_playwright-mcp_browser_snapshot / mcp_playwright-mcp_browser_find"
browser: Playwright 管理的 Chromium v149（微软官方维护）
strength:
  - 微软官方维护，更新及时
  - browser_find 按需搜索快照，Token 友好
  - 支持移动端设备模拟（--mobile --device='iPhone 13'）
  - 通过 MCP 协议集成，Hermes 原生支持
  - 已安装 4 个 Chromium 版本，无需额外下载
weakness:
  - 独立浏览器实例，不共享 Chrome 登录态
  - 需 Hermes 重启后生效（MCP 服务器在启动时加载）
  - 屏幕截图仅保存到本地，不自动分享
availability_check: "pgrep -f playwright-mcp → 进程存在即为可用"
init_needed: false
init_command: "npx playwright install chromium 2>/dev/null"
auth_required: false
anti_detection: "⭐⭐ (headless Chromium)"
work_without_login: true
fallback_order: 5
```

### Path 4: Chrome CDP 直连（browser_cdp 工具）

```yaml
id: cdp
name: Chrome CDP 直连
tool_type: hermes_tool
invoke: browser_cdp(method=...) / browser_cdp_url
browser: 用户 Chrome（需 --remote-debugging-port）
strength:
  - 直接操作 Chrome DevTools Protocol
  - 可提取 cookie、执行 JS、管理 tab
  - 与 Hermes browser_dialog 兼容
weakness:
  - 需预先启动 Chrome 带调试端口
  - 无元素 ref ID 系统（不如 browser_snapshot 方便）
  - CDP 会话不持久
availability_check: "curl -s http://localhost:9222/json/version 2>/dev/null → WebSocket URL"
init_needed: true
init_command: "osascript -e 'quit app \"Google Chrome\"' && sleep 2 && open -a 'Google Chrome' --args --remote-debugging-port=9222 && sleep 5"
auth_required: true
anti_detection: "⭐⭐⭐ (用户 Chrome)"
work_without_login: false
fallback_order: 4
```



---

## 自动发现机制

### 当前可用路径检测

Planner 在规划前运行以下脚本，动态获取当前哪些路径可用：

```bash
# ~/.hermes/skills/autonomous-ai-agents/browser-automation/scripts/check_browser_paths.sh
echo "=== Browser Paths Availability ==="

# Path 1: CloakBrowser
echo "cloak: available"  # 始终可用

# Path 2: OpenCLI
which opencli 2>/dev/null && echo "opencli: $(opencli doctor 2>&1 | grep -c 'Extension: connected')=available" || echo "opencli: unavailable"

# Path 3: browser-use
python3 -c "from browser_use.llm.anthropic.chat import ChatAnthropic; print('browseruse: available')" 2>/dev/null || echo "browseruse: unavailable"

# Path 4: CDP
curl -sf http://localhost:9222/json/version > /dev/null 2>&1 && echo "cdp: available" || echo "cdp: unavailable"
```

### 新路径注册流程

当新的浏览器路径或 browser 技能加入系统时：

```
1. 在 browser-registry.md 追加注册条目（YAML 格式）
2. 在 scripts/check_browser_paths.sh 追加可用性检测
3. Planner 下次加载时自动读 registry → 纳入路径选择
```

### 新路径注册模板

```yaml
id: <your-path-id>
name: <人类可读名称>
tool_type: hermes_tool|terminal|python|mcp
invoke: <具体调用方法>
browser: <浏览器引擎>
strength:
  - <优势1>
  - <优势2>
weakness:
  - <劣势1>
  - <劣势2>
availability_check: <检测命令>
auth_required: true|false
anti_detection: "⭐⭐⭐"
work_without_login: true|false
fallback_order: <N>
```

---

## 历史记录

| 日期 | 变更 | 操作 |
|:----|:----|:----|
| 2026-07-15 | 创建注册中心 | 初始 4 条路径：cloak, opencli, browseruse, cdp |
|| 2026-07-16 | 新增 Playwright MCP | 第 5 条路径（微软官方 MCP 服务器，需首次下载 Chromium） |
|| 2026-07-16 | 重复 Path 5 条目清理 | 删除第二个完整副本，保留首个 |
|| 2026-07-16 | Playwright MCP 状态更新 | init_needed: true→false, 检测方式改为进程 PID, 更新注册表信息 |
|| 2026-07-16 | 新增 Human-in-the-Loop | 来自 BrowserAct 文章吸收：验证码/异常→截图→通知用户→恢复执行 |