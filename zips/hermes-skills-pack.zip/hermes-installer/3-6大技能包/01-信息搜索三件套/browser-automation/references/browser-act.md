# BrowserAct — 浏览器自动化备选方案（已被 CloakBrowser 替代）

## 概要

[BrowserAct](https://www.browseract.com) 是 CLI 式浏览器自动化工具，核心差异在 **Stealth 反检测** 和 **Remote-assist 验证码接力**。但 **Stealth 功能需付费 API Key**（$13/月起），且其核心反检测技术已被开源替代方案追平。

## 替代方案：CloakBrowser（免费·MIT·开源）

[CloakBrowser](https://github.com/CloakHQ/CloakBrowser) 是 Chromium 源码级反检测浏览器，**30/30 反检测测试全绿**，已集成到 Hermes 默认浏览器工具中。

### 安装

```bash
pip install cloakbrowser
# 首次运行自动下载 Chromium 二进制（~200MB，国内需代理/镜像）
# 已通过 ghproxy.net 镜像完成安装
```

### Hermes 集成

已在 `~/.hermes/.env` 中设置：

```
AGENT_BROWSER_EXECUTABLE_PATH=/Users/jinzhanxiang/.cloakbrowser/chromium-145.0.7632.109.2/Chromium.app/Contents/MacOS/Chromium
```

设置后所有 Hermes 浏览器工具（`browser_navigate`、`browser_click` 等）自动使用 CloakBrowser 内核，**无需改代码**。

### 实测结果（2026-07-14）

| 网站 | 之前（Hermes 内置浏览器） | 现在（CloakBrowser） |
|:----|:----------------------:|:------------------:|
| **天眼查** | ❌ 被拦截 | ✅ **完全通过** |
| **企业预警通** | ❌ 被拦截 | ✅ **完全通过** |
| **企查查** | ❌ Cloudflare 拦截 | ⚠️ 通过 Cloudflare，但 405 应用层拦截 |

### 反检测验证

```
navigator.webdriver:  false       ✅
navigator.plugins:    5 items     ✅
typeof chrome:        "object"    ✅
UserAgent:            Chrome/145  ✅
```

## 与 Playwright/browser-use 的定位差异

| 维度 | Playwright / browser-use | BrowserAct | CloakBrowser（推荐） |
|:----|:------------------------|:----------|:-------------------|
| 集成方式 | Python 库，import 调用 | CLI 外部工具 | Playwright 原生 API |
| 编程控制 | ✅ 灵活 | ❌ CLI 命令链 | ✅ 灵活 |
| 反检测 | ❌ 需手动配置 | ✅ 18/18 全绿 | ✅ **30/30 全绿** |
| 验证码 | ❌ 卡死 | ✅ Remote-assist 接力 | ❌ 无（可配合 Hermes 手动） |
| 多浏览器并行 | ⚠️ 可配置 | ✅ 原生支持 | ⚠️ 可配置 |
| 成本 | 免费 | **付费**（$13/月起） | **免费** MIT 开源 |

## 安装（保留备选）

```bash
pipx install browser-act-cli
browser-act --version       # 验证
browser-act get-skills main # 加载技能运行时
```

## 定价（2026-07，仅作参考）

| 项目 | 内容 |
|:----|:----|
| Free Trial | $0/月，每日 100 Credits（≈ 1次 Stealth 查询） |
| Basic | **$13/月**（年付），10,000 Credits/月 |
| Essential | **$56/月**（年付），50,000 Credits/月 |
| Stealth 浏览器 | 100 Credits/次（≈ ¥0.46） |
| 操作步骤 | 5 Credits/步（≈ ¥0.023） |

## 使用时机

1. **默认** → CloakBrowser（已集成，免费，30/30 反检测）
2. **被反爬拦截时** → BrowserAct stealth-extract（付费，需 API Key，仅作备选）
3. **遇到验证码时** → BrowserAct remote-assist（扫码接力，仅作备选）

## 更多参考

- 企业信息查询场景下的使用 → `skill:opencli-integration/references/browser-act-bypass.md`