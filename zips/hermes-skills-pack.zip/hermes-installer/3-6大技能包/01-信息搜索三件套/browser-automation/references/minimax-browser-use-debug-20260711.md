# MiniMax + browser-use Integration Debugging Notes (2026-07-11)

## Root Cause Chain

### Problem: browser-use fails with MiniMax API

```
browser-use → ChatBrowserUse → POST /v1/chat/completions → 400 Bad Request
              ↓
         Sends extra fields: {fast, request_type, anonymized_telemetry}
              ↓
         MiniMax rejects unrecognized fields → 400
```

### Fix: Switch from ChatBrowserUse to ChatOpenAI

```
browser-use → ChatOpenAI → POST /v1/chat/completions → 200 OK
              ↓
         Uses OpenAI-compatible format (no extra fields)
```

## Three Issues Found

### Issue 1: base_url missing /v1 prefix
- **Symptom:** 404 Not Found
- **Root cause:** browser-use appends `/chat/completions` to base_url.
  `https://api.minimaxi.com` + `/chat/completions` = `https://api.minimaxi.com/chat/completions` (404)
- **Fix:** `base_url = "https://api.minimaxi.com/v1"`
- **Test evidence:**
  ```
  curl https://api.minimaxi.com/v1/chat/completions → 200 OK
  curl https://api.minimaxi.com/chat/completions → 404
  ```

### Issue 2: MiniMax thinking tags embedded in content
- **Symptom:** `Invalid JSON: expected value at line 1 column 1`
- **Root cause:** MiniMax always prepends `>` before JSON content.
  Even with `thinking={'type': 'disabled'}`, tags still appear in content.
- **Fix:** Monkey-patch `ChatOpenAI.ainvoke` to strip tags before JSON validation
- **Regex:** `re.sub(r'', '', content, flags=re.DOTALL)`
- **Test evidence:**
  ```
  Raw content: >...response {JSON}
  After stripping: {JSON}
  ```

### Issue 3: MiniMax too slow for complex tasks
- **Symptom:** Agent runs out of max_steps on multi-step tasks
- **Root cause:** MiniMax generates long thinking chains before any action
- **Fix:** Use for simple tasks only; switch to DeepSeek for complex tasks
- **Test evidence:** 天眼查 multi-step task failed; example.com single-step succeeded

### Issue 4: dont_force_structured_output is required
- **Symptom:** Agent returns empty content or `Invalid JSON: EOF while parsing`
- **Root cause:** With `dont_force_structured_output=False` (default), browser-use
  sends `response_format` (JSON schema) to MiniMax. MiniMax ignores the schema
  and returns thinking content instead of valid JSON.
- **Fix:** Always set `dont_force_structured_output=True` when using MiniMax:
  ```python
  llm = openai_chat.ChatOpenAI(
      model='MiniMax-M2.7',
      base_url='https://api.minimaxi.com/v1',
      dont_force_structured_output=True,
  )
  ```

### Issue 5: No closing tag in MiniMax response
- **Symptom:** After stripping, content is empty
- **Root cause:** MiniMax outputs `>` without a closing `>` during
  incomplete thinking chains. The simple regex `re.sub(r'[\s\S]*?', '')`
  fails (requires both tags).
- **Fix:** Use `content.rfind()` to find the LAST occurrence of any tag
  and take everything after it. See SKILL.md Pitfall #7 for code.

## MiniMax Thinking Parameter Test Matrix

We tested 6 variants of the thinking parameter. **Key finding: MiniMax ALWAYS includes thinking tags in content regardless of the thinking parameter setting.**

| thinking value | reasoning_tokens | Content starts with | Tags in content? |
|---|---|---|---|
| `{'type': 'disabled'}` | 0 | re.escape() | Always |
| `{'type': 'false'}` | 130 | re.escape() | Always |
| `{'type': 'off'}` | 0 | re.escape() | Always |
| `{'type': 'auto'}` | 83 | re.escape() | Always |
| `{'type': 'enabled'}` | 28 | re.escape() | Always |
| `{'include_in_output': False}` | 180 | re.escape() | Always |

**Conclusion:** MiniMax's thinking parameter only controls whether reasoning_tokens are counted in usage, NOT whether thinking content appears in the response. The thinking tags are always embedded in content. The only fix is client-side stripping via monkey-patch.

## APU Key Update
Updated in .env:
```
MINIMAX_API_KEY=sk-cp-a_Ybxk8gE3E89LWZu8QVVY3ICrPC7jc6w0fFbolZHqvwJ1ifoOg5Jv-zZct3CqQv2Q7raGbBdbujx6pxw-gFK4_702aqSRPAe6HVdhwcipv7pXqO6XkgcoI
```

## Knowledge Base Update
`~/Documents/Obsidian Vault/知识库/concepts/browser-use-guide.md` updated with:
- Working ChatOpenAI integration code
- Thinking tag stripping monkey-patch
- base_url /v1 requirement
- Chinese language convention