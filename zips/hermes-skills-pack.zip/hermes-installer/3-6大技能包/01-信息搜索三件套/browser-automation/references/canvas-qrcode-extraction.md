# Canvas 二维码提取

## 场景

登录页面（如企查查 `https://www.qcc.com/weblogin`）的动态二维码使用 `<canvas>` 元素渲染，没有可下载的静态图片 URL。需要通过 JavaScript 提取。

## 提取方法

### 用 Hermes `browser_console`

```python
# 1. 打开登录页
browser_navigate("https://www.qcc.com/weblogin")

# 2. 提取 Canvas 二维码
# browser_console(expression="...") 返回 base64 data URL
# 注意：browser_console 的 expression 参数需在 config.yaml 中设置
#   browser.allow_unsafe_evaluate: true
# 或者直接用 terminal 调用 agent-browser eval

# 3. 保存为图片文件
```

### 用 `agent-browser eval`

```bash
SESSION="login-session"
CLOAK_PATH="/Users/jinzhanxiang/.cloakbrowser/chromium-145.0.7632.109.2/Chromium.app/Contents/MacOS/Chromium"

# 打开登录页
npx agent-browser --executable-path "$CLOAK_PATH" \
  open --url "https://www.qcc.com/weblogin" --session "$SESSION"

# 提取 Canvas 二维码
npx agent-browser eval \
  "(()=>{const c=document.querySelector('canvas');if(!c)return'no canvas';return c.toDataURL('image/png')})()" \
  --session "$SESSION"

# 关闭 session
npx agent-browser close --session "$SESSION"
```

### Python 保存为文件

```python
import base64

data_url = "data:image/png;base64,iVBOR..."  # 从 eval 结果复制
b64_data = data_url.split(',')[1]
img_data = base64.b64decode(b64_data)

with open('/tmp/qrcode.png', 'wb') as f:
    f.write(img_data)

print(f"Saved {len(img_data)} bytes")
# → MEDIA:/tmp/qrcode.png 分享给用户
```

## 注意事项

### ⚠️ QR 码过期时间短

企查查的微信二维码有效期约 **2-3 分钟**。过期后页面不会自动刷新，需要主动刷新：

```bash
# 过期后导航重新获取新二维码
npx agent-browser open --url "https://www.qcc.com/weblogin" --session "$SESSION"
```

### ⚠️ `browser_navigate` 丢失登录态

Hermes 内置 `browser_navigate` 工具可能在一个新的页面上下文中打开 URL，导致之前 QR 码扫描设置的 cookies 丢失。因此：

- **提取二维码**可以用 `browser_navigate` 没问题
- **用户扫码后不要用 `browser_navigate` 导航**，否则登录态丢失
- 要用 `--restore` 持久化 session（见 `chrome-login-transfer.md`）

### 二维码来自 Canvas

- 企查查的二维码是动态生成的 Canvas 元素，而不是 `<img>` 标签
- 每次刷新页面都生成新的二维码
- 微信扫码后，微信服务器通知企查查，企查查设置 cookies 到当前浏览器
- 因此**扫码的浏览器和设置 cookies 的必须是同一个浏览器实例**