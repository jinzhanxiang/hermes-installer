# CloakBrowser 安装与集成指南

## 安装

```bash
pip install cloakbrowser
```

首次运行时自动下载 Chromium 二进制（~200MB）。国内网络需要镜像：

### 国内下载（ghproxy）

CloakBrowser 的 CDN 和 GitHub Releases 在境内都可能被阻断。用 ghproxy 镜像下载：

```bash
VERSION="chromium-v145.0.7632.109.2"
PLATFORM="cloakbrowser-darwin-arm64.tar.gz"
URL="https://ghproxy.net/https://github.com/CloakHQ/cloakbrowser/releases/download/${VERSION}/${PLATFORM}"

curl -L --connect-timeout 10 --max-time 300 -o /tmp/cloakbrowser.tar.gz "$URL"

# 解压到 CloakBrowser 期望的缓存目录
CACHE_DIR="$HOME/.cloakbrowser"
mkdir -p "$CACHE_DIR"
tar xzf /tmp/cloakbrowser.tar.gz -C "$CACHE_DIR"

# 注意：解压后的目录名可能不包含版本号，需按 cloakbrowser 预期结构调整
# 预期路径：~/.cloakbrowser/<version>/Chromium.app/Contents/MacOS/Chromium
# 解压后通常是 ~/.cloakbrowser/Chromium.app/... → 需要 mv 到版本目录下
BIN_VERSION="$CACHE_DIR/chromium-$VERSION"
mkdir -p "$BIN_VERSION"
mv "$CACHE_DIR/Chromium.app" "$BIN_VERSION/"
```

二进制缓存路径：`~/.cloakbrowser/chromium-*.*/Chromium.app/Contents/MacOS/Chromium`

## Hermes 集成

在 `~/.hermes/.env` 中添加：

```
AGENT_BROWSER_EXECUTABLE_PATH=/Users/jinzhanxiang/.cloakbrowser/chromium-145.0.7632.109.2/Chromium.app/Contents/MacOS/Chromium
```

**原理：** `agent-browser` CLI（Hermes 的内置浏览器驱动）通过 `AGENT_BROWSER_EXECUTABLE_PATH` 环境变量读取自定义 Chromium 二进制路径。设置后 Hermes 所有浏览器工具（`browser_navigate`、`browser_click`、`browser_snapshot` 等）自动使用 CloakBrowser 内核，零代码改动。无需修改 Hermes 源码或配置文件。

## 反检测验证

```bash
# 通过 agent-browser 测试
npx agent-browser open --url "https://httpbin.org/anything" --session "test"
npx agent-browser eval "navigator.webdriver" --session "test"          # 应返回 false
npx agent-browser eval "navigator.plugins.length" --session "test"     # 应返回 5
npx agent-browser eval "typeof chrome" --session "test"                # 应返回 "object"
npx agent-browser close --session "test"
```

也可直接用 Python 验证：

```python
from cloakbrowser import launch_async
import asyncio

async def test():
    b = await launch_async(headless=True)
    p = await b.new_page()
    print(await p.evaluate("navigator.webdriver"))       # False
    print(await p.evaluate("navigator.plugins.length"))  # 5
    print(await p.evaluate("typeof chrome"))             # "object"
    await b.close()
asyncio.run(test())
```

## 已知问题

1. **macOS Gatekeeper**：CloakBrowser 二进制是 ad-hoc 签名，可能被 macOS 阻止。第一次运行需要右键 → 打开 确认，或运行 `xattr -d com.apple.quarantine /path/to/Chromium`
2. **CloakBrowser 免费版（v146）** vs **Pro 版（v148）**：免费版已通过 30/30 反检测测试，Pro 版有更新补丁但需付费。对于企查查/天眼查场景免费版已足够。
3. **企查查 405 拦截**：CloakBrowser 可通过 Cloudflare 层，但企查查的应用层反爬（405）仍需登录 session。参见 `chrome-login-transfer.md`。

## 实测结果（2026-07-14）

| 网站 | CloakBrowser 结果 | 需要登录？ |
|:----|:-----------------|:---------|
| 天眼查 | ✅ 完全通过，搜索和详情页正常 | 否 |
| 企业预警通 | ✅ 页面加载正常，但搜索/详情全部重定向登录页 | **是** |
| 企查查 | ⚠️ 通过 Cloudflare，但搜索触发登录墙 | **是** |