# 天眼查自动化查询测试 (2026-07-11)

## 目标
使用 browser-use + MiniMax-M2.7 自动查询 晶能光电 的股东信息。

## 测试配置

```python
llm = openai_chat.ChatOpenAI(
    model='MiniMax-M2.7',
    base_url='https://api.minimaxi.com/v1',  # 含 /v1 前缀
    dont_force_structured_output=True,        # 关闭 JSON schema 强制输出
)
# 已经对 ChatOpenAI.ainvoke 做了 monkey-patch 剥离 thinking 标签
# use_vision=False, headless=True
```

## 测试结果：❌ 失败

### 1. 天眼查反爬拦截

天眼查检测到自动化浏览器访问，返回：
```
系统检测到您的操作存在异常
```

MiniMax 的后续步骤反馈：
```
The user is trying to access Tianyancha (天眼查), a Chinese business 
information search website. The page shows a message that says 
"系统检测到您的操作存在异常" (System detected abnormal operation) and is blocking access
```

### 2. MiniMax 推理链过长

对于复杂多步骤任务（打开网站 → 搜索公司名 → 点击结果 → 查找股东信息 → 提取），MiniMax-M2.7 的 thinking 模式输出极长的推理链，甚至不产生实际的 JSON 操作指令。

最终模型输出完全为 thinking 内容（`>` 标签内的思考过程），没有闭合的 `<thinking>` 标签，导致清理器匹配到最后位置时内容为空。

### 3. Agent 6 次重试后失败

```
Result failed 6/6 times: Failed to parse model output
Stopping due to 5 consecutive failures
```

## 结论

| 问题 | 原因 | 当前状态 |
|------|------|----------|
| 天眼查反爬 | 检测到 Playwright 自动化浏览器指纹 | ❌ 不可绕过 |
| MiniMax 复杂任务 | 推理链过长，不产生实际 JSON 操作 | ❌ 不可用 |
| thinking 标签 | MiniMax 始终输出 `>` 内容 | ✅ 已有 monkey-patch |

## 可行方案

| 方案 | 说明 |
|------|------|
| **换模型** | DeepSeek 无 thinking 标签问题，对复杂任务支持更好 |
| **天眼查官方 API** | 最可靠，但需要商业授权 |
| **手动查询** | 人工查后录入知识库 |
| **换平台** | 部分竞品平台（企查查/爱企查）反爬可能较松 |