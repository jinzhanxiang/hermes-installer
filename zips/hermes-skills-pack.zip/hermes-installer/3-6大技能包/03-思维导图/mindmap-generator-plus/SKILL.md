---
name: mindmap-generator
description: 使用 Markmap CLI（基于标准 Markdown 语法）生成分层思维导图 PDF，主公确认的"上次发给我的 Markdown 格式"标准。绝不使用 mermaid mindmap 缩进语法。
metadata:
  category: 可视化
  emoji: 🧠
triggers:
  - 思维导图
  - mindmap
  - 生成导图
---

# MindMap Generator（Markmap 风格 PDF）

使用 **Markmap CLI**（基于 d3.js 辐射布局）从**标准 Markdown**生成分层思维导图。

> 📌 **2026-06-08 主公最新指令（v23 长图模式）**：
> **单张 A4 宽度长图** = 1 张完整图（非分段拼接），viewport 3000×4242（A4 比例 1:1.414，**字号是 1653×2338 viewport 的 1.82 倍**）。所有多分支思维导图一律按此模式输出。

## 🚨 核心规范（最高优先级）

**主公确认的"上次发给我的 Markdown 格式"= 6/5 那版附件F_思维导图源文件.md**

**必须使用：标准 Markdown 语法**
- `# 一级标题` → 根节点/主分支
- `## 二级标题` → 二级
- `### 三级标题` → 三级
- `#### 四级标题` → 四级
- `- 列表项` → 叶子节点
- `**加粗**` `*斜体*` `> 引用` → 文本格式
- `| 表格 | 表格 |` → 表格（markmap 完美支持）
- 空行 → 段落分隔
- emoji ✅ ⚠️ 🔴 → 状态符号

**❌ 绝不使用：Mermaid mindmap 缩进语法**
```
mindmap
  root((标题))      ← 错！这是 mermaid 语法
    分支1            ← 错！markmap 不识别
      子节点         ← 错！
```

**为什么 mermaid 错**：
- 主公 6/5 那版 .md 是标准 Markdown（# 标题 + - 列表）
- mermaid 缩进语法 markmap 不识别
- mermaid 渲染出来是矩形块风格，不是 markmap 辐射风
- 主公已确认"按这个 Markdown 格式"

## 🚨 v23 长图模式（2026-06-08 主公指令 — 最高优先级）

**主公原话**：
> "你需要将上下半场的合并在一起，而且后续你的中间文件不要放在桌面"

**v23 长图模式** = 当前思维导图交付的**唯一标准输出模式**：
- ✅ **1 张完整图**（不是分上下半场 2 张）
- ✅ **A4 宽度**（短边 1653pt @ 200DPI = 595pt 打印）
- ✅ **viewport 3000×4242**（A4 比例 1:1.414，面积是 1653×2338 的 3.30 倍，**字号 1.82x**）
- ✅ **横向多 200-300 像素留白**（防右侧长文本截断）
- ✅ **PIL resize 到 1653 宽**（保持比例，纵向自然延展）
- ✅ **PNG + PDF 双格式**
- ✅ **桌面只放最终交付物**，中间文件全部放 `/tmp/mindmap_<版本>/` 或 `~/.openclaw/workspace-report/`

**v23 输出**：
| 文件 | 尺寸 | 比例 | 字号 |
|------|------|------|------|
| 1653×3860 PNG/PDF | A4 宽度长图 | 1:2.34 | v16 的 1.82x |
| 横向 53.5% 占用 | markmap 中央渲染限制 | （无法突破） | — |
| 纵向 95%+ 占用 | markmap 自动 fit 高度 | — | — |

**为什么不能用 A4 比例 1:1.414 装下 8 大分支**：
- markmap 内容自身比例 1:2.5+（8 大分支纵列延展）
- A4 比例 1:1.414 装不下全部
- **必须用 A4 宽度 + 长图比例**（1653×3860 = 1:2.34）

**为什么不能再分上下 2 张 A4**：
- 主公明确说"**合并在一起**"——1 张图优先
- 分 2 张破坏思维导图的全局连续性
- 用户体验差（"碎片化"）

## 环境要求

- Node.js v18+
- Markmap CLI: `npm install -g markmap-cli` 或 `npm install markmap-cli`
- mmdc 路径: `~/.npm-global/bin/mmdc`（备选，仅当用户明确要 mermaid 风格时）
- Python 3 + PIL（用于 PIL resize 最终长图）
- pdftoppm（用于 PNG 输出）
- pdfinfo（用于 PDF 尺寸核验）

## 完整工作流（v23 长图模式 5 步）

### Step 1：准备标准 Markdown 源文件

```markdown
# 主题（根节点）

## 主分支1

### 二级节点
- 三级节点A
  - 细节1
  - 细节2
- 三级节点B

#### 四级节点
- 叶子节点

| 列1 | 列2 |
|-----|-----|
| A   | B   |
```

**层级规则**：
- 根节点用 `#` 一级标题
- 主分支用 `##` 二级标题
- 主题小标题用 `###` 三级
- 细节用 `####` 四级 + `-` 列表
- 建议控制在 5 层以内（再深 markmap 字号过小）
- **多分支内容**（8 大分支及以上）一律用 `##` 二级标题（markmap 辐射布局，8 个 `##` 平均分配纵向空间）

**8 大分支最佳实践**：
- 不是 1 个根 + 8 个 `##`（markmap 会自动分成左右两侧各 4 个）
- 而是 **1 个根 + 2 个 `##`（大分支组）+ 8 个 `###`（子分支）**——markmap 会画 2 大分支组，每组 4 子分支，更整齐
- 例：根"电化学储能" → "## 一、储能电池技术"（含 1.1-1.4）+ "## 二、储能应用与配套"（含 2.1-2.4）

### Step 2：用 markmap CLI 生成离线 HTML

```bash
cd /tmp/mindmap_pkg  # 装了 markmap-cli 的目录
./node_modules/.bin/markmap --no-open --no-toolbar --offline \
  -o /tmp/mindmap_vXX/output.html \
  /tmp/mindmap_vXX/source.md
```

**关键参数**：
- `--no-open`：生成后不打开浏览器
- `--no-toolbar`：不显示 markmap 工具栏（PDF 干净）
- `--offline`：内联所有 JS/CSS 资源（单文件可离线查看）

**中间文件路径规范**：
- ❌ 禁止放桌面
- ✅ `/tmp/mindmap_v<版本号>/` 或 `~/.openclaw/workspace-report/`
- 例：`/tmp/mindmap_v23/source.md`、`/tmp/mindmap_v23/output.html`

### Step 3：用 puppeteer 渲染大 viewport PDF

**脚本**：`/tmp/mindmap_pkg/markmap_a4_3000.js`

```javascript
// markmap_a4_3000.js - A4 比例 + 大 viewport（字号 1.82x）
const puppeteer = require('puppeteer-core');
const path = require('path');

(async () => {
  const inputHtml = process.argv[2];
  const outputPdf = process.argv[3];
  const W = parseInt(process.argv[4] || '3000');
  const H = parseInt(process.argv[5] || '4242');
  
  const browser = await puppeteer.launch({
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: W, height: H, deviceScaleFactor: 1 });
  await page.goto('file://' + path.resolve(inputHtml), { 
    waitUntil: 'networkidle0', 
    timeout: 60000 
  });
  await new Promise(r => setTimeout(r, 3000));
  await page.pdf({
    path: outputPdf,
    width: W + 'px',
    height: H + 'px',
    printBackground: true,
    margin: { top: 0, right: 0, bottom: 0, left: 0 }
  });
  await browser.close();
  console.log(`PDF: ${outputPdf} (${W}×${H})`);
})();
```

**调用**：
```bash
node /tmp/mindmap_pkg/markmap_a4_3000.js \
  /tmp/mindmap_vXX/output.html \
  /tmp/mindmap_vXX/vXX_a4_big.pdf \
  3000 4242
```

**viewport 选择矩阵**（A4 比例 1:1.414）：
| Viewport | 200DPI 输出 | 字号倍数 | 适用场景 |
|----------|------------|---------|---------|
| 1653×2338 | 3442×4862 | 1.0x | 单页打印（字号小） |
| **3000×4242**（v23 默认） | **6250×8839** | **1.82x** | **多分支长图（推荐）** |
| 4000×5656 | 8334×11783 | 2.20x | 极大字号（10+ 分支） |

### Step 4：转 PNG + PIL 裁切 resize

```bash
# 1) PDF 转 200DPI PNG
pdftoppm -r 200 -png /tmp/mindmap_vXX/vXX_a4_big.pdf /tmp/mindmap_vXX/vXX_a4_big

# 2) PIL 裁切 + resize 到 A4 宽度 1653
python3 <<'PYEOF'
from PIL import Image
import numpy as np

src = Image.open("/tmp/mindmap_vXX/vXX_a4_big-1.png")
W, H = src.size
arr = np.array(src.convert('RGB'))
not_pure_white = arr.min(axis=-1) < 254
rows = np.where(not_pure_white.any(axis=1))[0]
cols = np.where(not_pure_white.any(axis=0))[0]
y0, y1 = rows.min(), rows.max()
x0, x1 = cols.min(), cols.max()

# 横向多 200 像素留白（防右侧长文本截断）
extra_w = 200
left = max(0, x0 - extra_w // 2)
right = min(W, x1 + extra_w // 2 + 50)  # 多 50 防右侧文字切

crop = src.crop((left, y0, right, y1))
cw, ch = crop.size

# resize 到 1653 宽（A4 宽度）
new_w = 1653
ratio = new_w / cw
new_h = int(ch * ratio)
final = crop.resize((new_w, new_h), Image.LANCZOS)

# 保存 PNG + PDF
final.save("/tmp/mindmap_vXX/final.png", "PNG", optimize=True)
final.save("/tmp/mindmap_vXX/final.pdf", "PDF", resolution=200.0)
print(f"最终: {new_w}×{new_h}, 比例 1:{new_h/new_w:.3f}")
PYEOF
```

### Step 5：复制到 final + 桌面

```bash
# final 目录（长期归档）
cp /tmp/mindmap_vXX/final.png \
   ~/Documents/OpenClaw-Workspace-report/final/<项目目录>/<命名>.png
cp /tmp/mindmap_vXX/final.pdf \
   ~/Documents/OpenClaw-Workspace-report/final/<项目目录>/<命名>.pdf

# 桌面只放最终交付物（最多 2-3 个）
cp /tmp/mindmap_vXX/final.png ~/Desktop/<命名>.png
cp /tmp/mindmap_vXX/final.pdf ~/Desktop/<命名>.pdf
```

## 输出规范

| 要素 | 规范值 | 说明 |
|------|--------|------|
| **引擎** | Markmap（d3.js 辐射） | 唯一指定 |
| **viewport** | 3000×4242（A4 比例 1:1.414） | v23 标准，字号 1.82x |
| **PDF/PNG 尺寸** | 1653×3860（按内容高度自然延展） | A4 宽度长图 |
| **页面方向** | 横向（landscape） | 主公认定的样式 |
| **页数** | **单页**（**不要分上下 2 张**） | v23 标准 |
| **工具栏** | 隐藏（--no-toolbar） | PDF 干净 |
| **背景** | 白色 | printBackground: true |
| **字号** | 1.82x v16（用 3000×4242 viewport 实现） | 解决"清晰度不够"诉求 |
| **文件位置** | final 目录 + 桌面（仅最终版） | 中间文件放 /tmp/ |

## 桌面文件管理规范（v23 强制）

**桌面只放最终交付物，最多 2-3 个**：
- 1 张主图 PNG
- 1 张主图 PDF
- 最多 1 个相关源文件

**中间文件**（HTML/调试 PNG/PDF/源文件）**全部移到**：
- `/tmp/mindmap_v<版本>/`（临时）
- `~/.openclaw/workspace-report/mindmap_v<版本>_archive/`（归档）

**清理命令**：
```bash
# 把桌面调试文件归档
for f in ~/Desktop/<项目>*.{html,png,pdf,md}; do
  [ -f "$f" ] && mv "$f" ~/.openclaw/workspace-report/mindmap_vXX_archive/desktop_cleanup/
done
```

## 完整调用脚本（v23 一键式）

```bash
#!/bin/bash
# v23 思维导图一键生成（标准模式）
MD=$1
NAME=$(basename "$MD" .md)
VERSION="v23_$(date +%H%M)"

# 中间目录（不放在桌面）
TMPDIR=/tmp/mindmap_$VERSION
mkdir -p $TMPDIR
cp $MD $TMPDIR/source.md

# 1. markmap → HTML
cd /tmp/mindmap_pkg
./node_modules/.bin/markmap --no-open --no-toolbar --offline \
  -o $TMPDIR/output.html $TMPDIR/source.md 2>&1 | tail -3

# 2. puppeteer → PDF（3000×4242 viewport）
node /tmp/mindmap_pkg/markmap_a4_3000.js \
  $TMPDIR/output.html $TMPDIR/big.pdf 3000 4242 2>&1 | tail -3

# 3. PDF → 200DPI PNG → PIL 裁切 resize
pdftoppm -r 200 -png $TMPDIR/big.pdf $TMPDIR/big
python3 <<PYEOF
from PIL import Image
import numpy as np
src = Image.open("$TMPDIR/big-1.png")
W, H = src.size
arr = np.array(src.convert('RGB'))
mask = arr.min(axis=-1) < 254
rows = np.where(mask.any(axis=1))[0]
cols = np.where(mask.any(axis=0))[0]
y0, y1 = rows.min(), rows.max()
x0, x1 = cols.min(), cols.max()
extra = 200
crop = src.crop((max(0, x0-extra//2), y0, min(W, x1+extra//2+50), y1))
cw, ch = crop.size
new_w = 1653
new_h = int(ch * (new_w/cw))
final = crop.resize((new_w, new_h), Image.LANCZOS)
final.save("$TMPDIR/final.png", "PNG", optimize=True)
final.save("$TMPDIR/final.pdf", "PDF", resolution=200.0)
print(f"✓ {new_w}×{new_h}, 比例 1:{new_h/new_w:.3f}")
PYEOF

# 4. 复制到 final + 桌面
FINAL_DIR=~/Documents/OpenClaw-Workspace-report/final/<项目目录>/
mkdir -p "$FINAL_DIR"
cp $TMPDIR/final.png "$FINAL_DIR/${NAME}_完整长图.png"
cp $TMPDIR/final.pdf "$FINAL_DIR/${NAME}_完整长图.pdf"
cp $TMPDIR/final.png ~/Desktop/${NAME}_完整长图.png
cp $TMPDIR/final.pdf ~/Desktop/${NAME}_完整长图.pdf

# 5. 核验
ls -la "$FINAL_DIR/${NAME}_完整长图."{png,pdf}
pdfinfo "$FINAL_DIR/${NAME}_完整长图.pdf" | grep "Page size"
```

## 常见错误（防跑偏）

### ❌ 错误 1：用 mermaid 缩进语法

```
mindmap
  root((标题))
    分支
      子分支
```

**为什么错**：主公说"按上次发给你的 Markdown 格式"= 标准 Markdown 语法。mermaid 缩进是另一种工具的格式，不是 markmap 输入格式。

**正确写法**：
```markdown
# 标题

## 分支

### 子分支
```

### ❌ 错误 2：用 mermaid mindmap 引擎（mmdc）

**为什么错**：mmdc 渲染出来是矩形块风格，不是 markmap 辐射风。

**正确做法**：用 markmap CLI（`markmap --offline`）。

### ❌ 错误 3：竖向 PDF（A4 595×842）

**为什么错**：markmap 思维导图是横向辐射布局，4:3 比例。竖向 A4 会大量留白。

**正确做法**：v23 长图模式（viewport 3000×4242 = A4 比例但长图）。

### ❌ 错误 4：结构拆错（拆成 6 个并列分支 vs 主公原结构）

**为什么错**：主公 v22 是 6 大分支（核心前提/收购路径/可行性/委托加工/风险/谈判），不是 3 大分支。

**正确做法**：用主公 .md 源文件的原始 H 标题层级，不要二次重组。

### ❌ 错误 5：分上下 2 张 A4 交付（v21 错误模式）

**主公原话**：
> "你需要将上下半场的合并在一起"

**正确做法**：v23 长图模式 = 1 张完整图（1653×3860）。

### ❌ 错误 6：把中间文件放桌面

**主公原话**：
> "后续你的中间文件不要放在桌面，显得太乱"

**正确做法**：中间文件放 `/tmp/mindmap_vXX/` 或 `~/.openclaw/workspace-report/`，桌面只放最终交付物。

### ❌ 错误 7：用 1653×2338 viewport 渲染（字号太小）

**主公诉求**：
> "清晰度不够，需要大幅提升"

**正确做法**：用 3000×4242 viewport（字号 1.82x）。

### ❌ 错误 8：拼接 2 张 markmap 输出（v22 错误模式）

**问题**：上下拼接会出现内容重复（overlap 区域被画 2 次）、左侧裁切等问题。

**正确做法**：用 1 个统一源文件 + 1 次 markmap 渲染 + 1 张 PIL resize 输出。

## 🚨 v24 大内容模式（2026-06-16 主公指令 — 最高优先级）

**主公原话**：
> "你这个内容还是残缺呀，只有一半或者是1/3"

**v24 大内容模式** = 当内容节点超过 50 个时，必须用此模式：
- ✅ **先用 inspect.js 检查 SVG 节点分布区域**（不盲目选 viewport）
- ✅ **viewport 必须覆盖全部节点的实际坐标范围**
- ✅ **用 puppeteer page.evaluate() 强制统一加粗**（CSS 注入对 SVG 不生效）
- ✅ **交付前必须用 vision 模型验证内容完整性**

### v24 完整工作流（6 步）

```bash
# Step 1: markmap → HTML
markmap --no-open --no-toolbar --offline -o $TMPDIR/output.html $TMPDIR/source.md

# Step 2: inspect.js 检查节点分布
node inspect.js $TMPDIR/output.html  # 输出 minX/minY/maxX/maxY/nodeCount

# Step 3: 根据节点分布选择 viewport
# viewport 宽度 = (maxX - minX) * 1.3  # 30% 留白
# viewport 高度 = (maxY - minY) * 1.3
# DSF = 2（大内容用 DSF=2，小内容用 DSF=4）

# Step 4: render.js 渲染（含 page.evaluate 强制加粗）
node render.js $TMPDIR/output.html $TMPDIR/big.png <viewport_w> <viewport_h> <DSF>

# Step 5: PIL 裁切 + 保存
python3 crop_and_save.py $TMPDIR/big.png $TMPDIR/final.png $TMPDIR/final.pdf

# Step 6: vision 模型验证
# 必须确认：所有主要分支、子节点、表格数据完整显示
```

### inspect.js 模板

```javascript
const puppeteer = require('puppeteer');
(async () => {
  const browser = await puppeteer.launch({
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: ['--no-sandbox']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 16000, height: 12000, deviceScaleFactor: 1 });
  await page.goto('file://' + path.resolve(process.argv[2]), { waitUntil: 'networkidle0', timeout: 60000 });
  await new Promise(r => setTimeout(r, 3000));
  const bounds = await page.evaluate(() => {
    const nodes = document.querySelectorAll('svg g.markmap-node');
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    nodes.forEach(node => {
      const rect = node.getBoundingClientRect();
      if (rect.width > 0) {
        minX = Math.min(minX, rect.left); minY = Math.min(minY, rect.top);
        maxX = Math.max(maxX, rect.right); maxY = Math.max(maxY, rect.bottom);
      }
    });
    return { minX, minY, maxX, maxY, nodeCount: nodes.length };
  });
  console.log(JSON.stringify(bounds));
  await browser.close();
})();
```

### render.js 模板（含强制加粗）

```javascript
// ... puppeteer launch ...
await page.setViewport({ width: W, height: H, deviceScaleFactor: DSF });
await page.goto('file://' + path.resolve(inputHtml), { waitUntil: 'networkidle0', timeout: 60000 });
await new Promise(r => setTimeout(r, 3000));

// 强制加粗所有 SVG 文字（CSS 注入对 SVG 不生效，必须用 JS）
await page.evaluate(() => {
  document.querySelectorAll('svg text, svg foreignObject div').forEach(el => {
    el.style.fontWeight = '900';
  });
  document.querySelectorAll('svg .markmap-link').forEach(el => {
    el.style.strokeWidth = '3px';
  });
});

await page.screenshot({ path: outputPng, fullPage: true, type: 'png' });
```

### viewport 选择矩阵（v24 更新）

| 节点数 | 建议 viewport | DSF | 说明 |
|--------|--------------|-----|------|
| < 30 | 3000×4242 | 4 | 小内容，v23 模式 |
| 30-80 | 6000×4000 | 3 | 中等内容 |
| 80-150 | 16000×12000 | 1 | 大内容，先 inspect |
| > 150 | 先 inspect 再定 | 1 | 超大内容 |

**关键原则**：viewport 必须覆盖节点实际分布区域，不能盲目选固定值。

## 验证清单（v24 必查）

- [ ] 源文件是标准 Markdown 格式（# 标题 + - 列表）
- [ ] 引擎是 markmap CLI（不是 mmdc）
- [ ] HTML 用 --offline 内联
- [ ] **inspect.js 检查节点分布，viewport 覆盖全部节点**
- [ ] **page.evaluate() 强制统一加粗（font-weight: 900）**
- [ ] PDF 用 puppeteer 转（不是 mmdc -f 那个老方案）
- [ ] **PNG/PDF 输出是 1 张**（不是分上下 2 张）
- [ ] 工具栏隐藏
- [ ] **vision 模型验证：所有主要分支、子节点、表格数据完整显示**
- [ ] 桌面只放最终 PNG/PDF，无中间文件

## 历史版本演进

| 版本 | 模式 | 问题 | 主公反馈 |
|------|------|------|---------|
| v1-v3 | 3 张 A4 竖向拼接 | 切碎 | 内容错误 |
| v3 横 | 3 张 A4 横向 + 拼长图 | 清晰度不够 + 多标题 | 框架割裂 |
| v4 统一 | 1 张 4:3 大画布 + 切 3 段 | 宽度没占满 + 上下空白 | markmap 限制 |
| v10 | 1 张 A4 比例 (1653×2338) | 字号小 | "清晰度不够" |
| v14-v18 | 4:3 大画布 + 切上下 2 张 A4 | 字号大但分 2 张 | "合并成 1 张图" |
| v23 | 1 张长图 (1653×3860) viewport 3000×4242 | ✅ 小内容全部解决 | 主公认可 |
| **v24** | **inspect → 动态 viewport → 强制加粗 → vision 验证** | **✅ 大内容全部解决** | **主公认可** |

## 参考

- **6/5 那版 .md 源文件**（主公认定的"上次 Markdown 格式"）：
  `~/Documents/OpenClaw-Workspace-report/final/星恒电源项目_思维导图/附件F_思维导图源文件.md`
- **6/5 那版 PDF**（视觉标杆）：
  `~/Documents/OpenClaw-Workspace-report/final/星恒电源项目_思维导图/附件F_星恒电源收并购方案_思维导图.pdf`
- **v23 最终交付**（**当前标准**）：
  `~/Documents/OpenClaw-Workspace-report/final/新型储能技术路线图_思维导图/电化学储能_完整长图.{png,pdf}`
- **v23 源文件**：
  `~/Documents/OpenClaw-Workspace-report/final/新型储能技术路线图_思维导图/电化学储能_源文件_2大分支版.md`
- **Markmap 官方文档**：https://markmap.js.org/

---

**最后更新**：2026-06-16（v24 大内容模式）
**维护者**：Report 代理
